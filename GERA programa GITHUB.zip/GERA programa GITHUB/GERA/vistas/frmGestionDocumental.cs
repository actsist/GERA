﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace document_management
{
    public partial class frmGestionDocumental : Form
    {
        public frmGestionDocumental()
        {
            InitializeComponent();
        }
    }
}
