﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using document_management.entidades;

namespace document_management
{
    public partial class frmDocumentacion : Form
    {
        clsCuenta cuenta;
        public frmDocumentacion(clsCuenta cuenta)
        {
            InitializeComponent();

            this.cuenta = cuenta;
            if (cuenta.Documentacion != null)
            {
                cbxEstadoCuenta.Checked = cuenta.Documentacion.EstadoCuenta;
                //rbtnEstadoCuentaCS.Checked = cuenta.Documentacion.EstadoCuentaCsOrCc;
                //txtDesde.Text = cuenta.Documentacion.EstadoCuentaDesde;
                //txtHasta.Text = cuenta.Documentacion.EstadoCuentaHasta;
                txtEstadosCuentaObs.Text = cuenta.Documentacion.EstadoCuentaObs;
            }
        }


        // Evento - Cerrar
        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Evento - Aceptar
        private void btnAceptar_Click(object sender, EventArgs e)
        {
            clsDocumentacion documentacion = new clsDocumentacion();
            documentacion.EstadoCuenta = cbxEstadoCuenta.Checked;
            //documentacion.EstadoCuentaCsOrCc = rbtnEstadoCuentaCS.Checked;
            //documentacion.EstadoCuentaDesde = txtDesde.Text;
            //documentacion.EstadoCuentaHasta = txtHasta.Text;
            documentacion.EstadoCuentaObs = txtEstadosCuentaObs.Text;

            this.Close();
        }

        
    }
}
