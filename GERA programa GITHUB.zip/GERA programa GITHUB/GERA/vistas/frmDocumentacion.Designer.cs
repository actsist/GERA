﻿namespace document_management
{
    partial class frmDocumentacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDocumentacion));
            this.cbxEstadoCuenta = new System.Windows.Forms.CheckBox();
            this.cbIdentificacionOficial = new System.Windows.Forms.CheckBox();
            this.cbContratoApertura = new System.Windows.Forms.CheckBox();
            this.cbPoderNotarial = new System.Windows.Forms.CheckBox();
            this.rbtnEstadoCuentaCS = new System.Windows.Forms.RadioButton();
            this.rbtnEstadosCuentaCC = new System.Windows.Forms.RadioButton();
            this.rbtnIdentificacionOficialCS = new System.Windows.Forms.RadioButton();
            this.rbtnContratoAperturaCS = new System.Windows.Forms.RadioButton();
            this.rbtnPoderNotarialCS = new System.Windows.Forms.RadioButton();
            this.rbtnIdentificacionOficialCC = new System.Windows.Forms.RadioButton();
            this.rbtnContratoAperturaCC = new System.Windows.Forms.RadioButton();
            this.rbtnPoderNotarialCC = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtDesde = new System.Windows.Forms.TextBox();
            this.txtHasta = new System.Windows.Forms.TextBox();
            this.txtEstadosCuentaObs = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtIdentificacionOficialObs = new System.Windows.Forms.TextBox();
            this.txtContratoAperturaObs = new System.Windows.Forms.TextBox();
            this.txtPoderNotarialObs = new System.Windows.Forms.TextBox();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.btnRegresar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cbxEstadoCuenta
            // 
            this.cbxEstadoCuenta.AutoSize = true;
            this.cbxEstadoCuenta.Location = new System.Drawing.Point(12, 31);
            this.cbxEstadoCuenta.Name = "cbxEstadoCuenta";
            this.cbxEstadoCuenta.Size = new System.Drawing.Size(115, 17);
            this.cbxEstadoCuenta.TabIndex = 0;
            this.cbxEstadoCuenta.Text = "Estados de cuenta";
            this.cbxEstadoCuenta.UseVisualStyleBackColor = true;
            // 
            // cbIdentificacionOficial
            // 
            this.cbIdentificacionOficial.AutoSize = true;
            this.cbIdentificacionOficial.Location = new System.Drawing.Point(12, 82);
            this.cbIdentificacionOficial.Name = "cbIdentificacionOficial";
            this.cbIdentificacionOficial.Size = new System.Drawing.Size(121, 17);
            this.cbIdentificacionOficial.TabIndex = 1;
            this.cbIdentificacionOficial.Text = "Identificación Oficial";
            this.cbIdentificacionOficial.UseVisualStyleBackColor = true;
            // 
            // cbContratoApertura
            // 
            this.cbContratoApertura.AutoSize = true;
            this.cbContratoApertura.Location = new System.Drawing.Point(12, 108);
            this.cbContratoApertura.Name = "cbContratoApertura";
            this.cbContratoApertura.Size = new System.Drawing.Size(123, 17);
            this.cbContratoApertura.TabIndex = 2;
            this.cbContratoApertura.Text = "Contrato de apertura";
            this.cbContratoApertura.UseVisualStyleBackColor = true;
            // 
            // cbPoderNotarial
            // 
            this.cbPoderNotarial.AutoSize = true;
            this.cbPoderNotarial.Location = new System.Drawing.Point(12, 134);
            this.cbPoderNotarial.Name = "cbPoderNotarial";
            this.cbPoderNotarial.Size = new System.Drawing.Size(93, 17);
            this.cbPoderNotarial.TabIndex = 3;
            this.cbPoderNotarial.Text = "Poder Notarial";
            this.cbPoderNotarial.UseVisualStyleBackColor = true;
            // 
            // rbtnEstadoCuentaCS
            // 
            this.rbtnEstadoCuentaCS.AutoSize = true;
            this.rbtnEstadoCuentaCS.Location = new System.Drawing.Point(159, 31);
            this.rbtnEstadoCuentaCS.Name = "rbtnEstadoCuentaCS";
            this.rbtnEstadoCuentaCS.Size = new System.Drawing.Size(84, 17);
            this.rbtnEstadoCuentaCS.TabIndex = 4;
            this.rbtnEstadoCuentaCS.TabStop = true;
            this.rbtnEstadoCuentaCS.Text = "Copia simple";
            this.rbtnEstadoCuentaCS.UseVisualStyleBackColor = true;
            // 
            // rbtnEstadosCuentaCC
            // 
            this.rbtnEstadosCuentaCC.AutoSize = true;
            this.rbtnEstadosCuentaCC.Location = new System.Drawing.Point(260, 31);
            this.rbtnEstadosCuentaCC.Name = "rbtnEstadosCuentaCC";
            this.rbtnEstadosCuentaCC.Size = new System.Drawing.Size(104, 17);
            this.rbtnEstadosCuentaCC.TabIndex = 5;
            this.rbtnEstadosCuentaCC.TabStop = true;
            this.rbtnEstadosCuentaCC.Text = "Copia certificada";
            this.rbtnEstadosCuentaCC.UseVisualStyleBackColor = true;
            // 
            // rbtnIdentificacionOficialCS
            // 
            this.rbtnIdentificacionOficialCS.AutoSize = true;
            this.rbtnIdentificacionOficialCS.Location = new System.Drawing.Point(169, 82);
            this.rbtnIdentificacionOficialCS.Name = "rbtnIdentificacionOficialCS";
            this.rbtnIdentificacionOficialCS.Size = new System.Drawing.Size(84, 17);
            this.rbtnIdentificacionOficialCS.TabIndex = 6;
            this.rbtnIdentificacionOficialCS.TabStop = true;
            this.rbtnIdentificacionOficialCS.Text = "Copia simple";
            this.rbtnIdentificacionOficialCS.UseVisualStyleBackColor = true;
            // 
            // rbtnContratoAperturaCS
            // 
            this.rbtnContratoAperturaCS.AutoSize = true;
            this.rbtnContratoAperturaCS.Location = new System.Drawing.Point(169, 108);
            this.rbtnContratoAperturaCS.Name = "rbtnContratoAperturaCS";
            this.rbtnContratoAperturaCS.Size = new System.Drawing.Size(84, 17);
            this.rbtnContratoAperturaCS.TabIndex = 7;
            this.rbtnContratoAperturaCS.TabStop = true;
            this.rbtnContratoAperturaCS.Text = "Copia simple";
            this.rbtnContratoAperturaCS.UseVisualStyleBackColor = true;
            // 
            // rbtnPoderNotarialCS
            // 
            this.rbtnPoderNotarialCS.AutoSize = true;
            this.rbtnPoderNotarialCS.Location = new System.Drawing.Point(169, 134);
            this.rbtnPoderNotarialCS.Name = "rbtnPoderNotarialCS";
            this.rbtnPoderNotarialCS.Size = new System.Drawing.Size(84, 17);
            this.rbtnPoderNotarialCS.TabIndex = 8;
            this.rbtnPoderNotarialCS.TabStop = true;
            this.rbtnPoderNotarialCS.Text = "Copia simple";
            this.rbtnPoderNotarialCS.UseVisualStyleBackColor = true;
            // 
            // rbtnIdentificacionOficialCC
            // 
            this.rbtnIdentificacionOficialCC.AutoSize = true;
            this.rbtnIdentificacionOficialCC.Location = new System.Drawing.Point(279, 82);
            this.rbtnIdentificacionOficialCC.Name = "rbtnIdentificacionOficialCC";
            this.rbtnIdentificacionOficialCC.Size = new System.Drawing.Size(104, 17);
            this.rbtnIdentificacionOficialCC.TabIndex = 9;
            this.rbtnIdentificacionOficialCC.TabStop = true;
            this.rbtnIdentificacionOficialCC.Text = "Copia certificada";
            this.rbtnIdentificacionOficialCC.UseVisualStyleBackColor = true;
            // 
            // rbtnContratoAperturaCC
            // 
            this.rbtnContratoAperturaCC.AutoSize = true;
            this.rbtnContratoAperturaCC.Location = new System.Drawing.Point(279, 108);
            this.rbtnContratoAperturaCC.Name = "rbtnContratoAperturaCC";
            this.rbtnContratoAperturaCC.Size = new System.Drawing.Size(104, 17);
            this.rbtnContratoAperturaCC.TabIndex = 10;
            this.rbtnContratoAperturaCC.TabStop = true;
            this.rbtnContratoAperturaCC.Text = "Copia certificada";
            this.rbtnContratoAperturaCC.UseVisualStyleBackColor = true;
            // 
            // rbtnPoderNotarialCC
            // 
            this.rbtnPoderNotarialCC.AutoSize = true;
            this.rbtnPoderNotarialCC.Location = new System.Drawing.Point(279, 134);
            this.rbtnPoderNotarialCC.Name = "rbtnPoderNotarialCC";
            this.rbtnPoderNotarialCC.Size = new System.Drawing.Size(104, 17);
            this.rbtnPoderNotarialCC.TabIndex = 11;
            this.rbtnPoderNotarialCC.TabStop = true;
            this.rbtnPoderNotarialCC.Text = "Copia certificada";
            this.rbtnPoderNotarialCC.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(186, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "al:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Del:";
            // 
            // txtDesde
            // 
            this.txtDesde.Location = new System.Drawing.Point(58, 54);
            this.txtDesde.Name = "txtDesde";
            this.txtDesde.Size = new System.Drawing.Size(100, 20);
            this.txtDesde.TabIndex = 14;
            // 
            // txtHasta
            // 
            this.txtHasta.Location = new System.Drawing.Point(210, 54);
            this.txtHasta.Name = "txtHasta";
            this.txtHasta.Size = new System.Drawing.Size(100, 20);
            this.txtHasta.TabIndex = 15;
            // 
            // txtEstadosCuentaObs
            // 
            this.txtEstadosCuentaObs.Location = new System.Drawing.Point(413, 29);
            this.txtEstadosCuentaObs.Name = "txtEstadosCuentaObs";
            this.txtEstadosCuentaObs.Size = new System.Drawing.Size(248, 20);
            this.txtEstadosCuentaObs.TabIndex = 17;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(410, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 13);
            this.label3.TabIndex = 16;
            this.label3.Text = "Observaciones:";
            // 
            // txtIdentificacionOficialObs
            // 
            this.txtIdentificacionOficialObs.Location = new System.Drawing.Point(413, 81);
            this.txtIdentificacionOficialObs.Name = "txtIdentificacionOficialObs";
            this.txtIdentificacionOficialObs.Size = new System.Drawing.Size(248, 20);
            this.txtIdentificacionOficialObs.TabIndex = 18;
            // 
            // txtContratoAperturaObs
            // 
            this.txtContratoAperturaObs.Location = new System.Drawing.Point(413, 107);
            this.txtContratoAperturaObs.Name = "txtContratoAperturaObs";
            this.txtContratoAperturaObs.Size = new System.Drawing.Size(248, 20);
            this.txtContratoAperturaObs.TabIndex = 19;
            // 
            // txtPoderNotarialObs
            // 
            this.txtPoderNotarialObs.Location = new System.Drawing.Point(413, 133);
            this.txtPoderNotarialObs.Name = "txtPoderNotarialObs";
            this.txtPoderNotarialObs.Size = new System.Drawing.Size(248, 20);
            this.txtPoderNotarialObs.TabIndex = 20;
            // 
            // btnAceptar
            // 
            this.btnAceptar.Location = new System.Drawing.Point(505, 159);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(75, 23);
            this.btnAceptar.TabIndex = 22;
            this.btnAceptar.Text = "Aceptar";
            this.btnAceptar.UseVisualStyleBackColor = true;
            this.btnAceptar.Click += new System.EventHandler(this.btnAceptar_Click);
            // 
            // btnRegresar
            // 
            this.btnRegresar.Location = new System.Drawing.Point(586, 159);
            this.btnRegresar.Name = "btnRegresar";
            this.btnRegresar.Size = new System.Drawing.Size(75, 23);
            this.btnRegresar.TabIndex = 21;
            this.btnRegresar.Text = "Regresar";
            this.btnRegresar.UseVisualStyleBackColor = true;
            this.btnRegresar.Click += new System.EventHandler(this.btnRegresar_Click);
            // 
            // frmDocumentacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(676, 193);
            this.Controls.Add(this.btnAceptar);
            this.Controls.Add(this.btnRegresar);
            this.Controls.Add(this.txtPoderNotarialObs);
            this.Controls.Add(this.txtContratoAperturaObs);
            this.Controls.Add(this.txtIdentificacionOficialObs);
            this.Controls.Add(this.txtEstadosCuentaObs);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtHasta);
            this.Controls.Add(this.txtDesde);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rbtnPoderNotarialCC);
            this.Controls.Add(this.rbtnContratoAperturaCC);
            this.Controls.Add(this.rbtnIdentificacionOficialCC);
            this.Controls.Add(this.rbtnPoderNotarialCS);
            this.Controls.Add(this.rbtnContratoAperturaCS);
            this.Controls.Add(this.rbtnIdentificacionOficialCS);
            this.Controls.Add(this.rbtnEstadosCuentaCC);
            this.Controls.Add(this.rbtnEstadoCuentaCS);
            this.Controls.Add(this.cbPoderNotarial);
            this.Controls.Add(this.cbContratoApertura);
            this.Controls.Add(this.cbIdentificacionOficial);
            this.Controls.Add(this.cbxEstadoCuenta);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmDocumentacion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GERA - Documentación";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox cbxEstadoCuenta;
        private System.Windows.Forms.CheckBox cbIdentificacionOficial;
        private System.Windows.Forms.CheckBox cbContratoApertura;
        private System.Windows.Forms.CheckBox cbPoderNotarial;
        private System.Windows.Forms.RadioButton rbtnEstadoCuentaCS;
        private System.Windows.Forms.RadioButton rbtnEstadosCuentaCC;
        private System.Windows.Forms.RadioButton rbtnIdentificacionOficialCS;
        private System.Windows.Forms.RadioButton rbtnContratoAperturaCS;
        private System.Windows.Forms.RadioButton rbtnPoderNotarialCS;
        private System.Windows.Forms.RadioButton rbtnIdentificacionOficialCC;
        private System.Windows.Forms.RadioButton rbtnContratoAperturaCC;
        private System.Windows.Forms.RadioButton rbtnPoderNotarialCC;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtDesde;
        private System.Windows.Forms.TextBox txtHasta;
        private System.Windows.Forms.TextBox txtEstadosCuentaObs;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtIdentificacionOficialObs;
        private System.Windows.Forms.TextBox txtContratoAperturaObs;
        private System.Windows.Forms.TextBox txtPoderNotarialObs;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.Button btnRegresar;
    }
}