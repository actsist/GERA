﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace document_management
{
    public partial class frmInfMovimientoElect : Form
    {
        public frmInfMovimientoElect()
        {
            InitializeComponent();
        }

        // Evento - Cerrar
        private void btnRegreso_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
