﻿namespace document_management
{
    partial class frmInfMovimientoElect
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmInfMovimientoElect));
            this.cbDispersionNomina = new System.Windows.Forms.CheckBox();
            this.cbMovElectronicos = new System.Windows.Forms.CheckBox();
            this.txtMovElectronicosObs = new System.Windows.Forms.TextBox();
            this.txtDispersionNominaObs = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAnexo = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.rbtnInfSolicitadaExc = new System.Windows.Forms.RadioButton();
            this.rbtnInfSolicitada = new System.Windows.Forms.RadioButton();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.btnRegreso = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cbDispersionNomina
            // 
            this.cbDispersionNomina.AutoSize = true;
            this.cbDispersionNomina.Location = new System.Drawing.Point(12, 52);
            this.cbDispersionNomina.Name = "cbDispersionNomina";
            this.cbDispersionNomina.Size = new System.Drawing.Size(127, 17);
            this.cbDispersionNomina.TabIndex = 4;
            this.cbDispersionNomina.Text = "Dispersión de nómina";
            this.cbDispersionNomina.UseVisualStyleBackColor = true;
            // 
            // cbMovElectronicos
            // 
            this.cbMovElectronicos.AutoSize = true;
            this.cbMovElectronicos.Location = new System.Drawing.Point(12, 26);
            this.cbMovElectronicos.Name = "cbMovElectronicos";
            this.cbMovElectronicos.Size = new System.Drawing.Size(145, 17);
            this.cbMovElectronicos.TabIndex = 3;
            this.cbMovElectronicos.Text = "Movimientos electrónicos";
            this.cbMovElectronicos.UseVisualStyleBackColor = true;
            // 
            // txtMovElectronicosObs
            // 
            this.txtMovElectronicosObs.Location = new System.Drawing.Point(162, 24);
            this.txtMovElectronicosObs.Name = "txtMovElectronicosObs";
            this.txtMovElectronicosObs.Size = new System.Drawing.Size(431, 20);
            this.txtMovElectronicosObs.TabIndex = 17;
            // 
            // txtDispersionNominaObs
            // 
            this.txtDispersionNominaObs.Location = new System.Drawing.Point(162, 50);
            this.txtDispersionNominaObs.Name = "txtDispersionNominaObs";
            this.txtDispersionNominaObs.Size = new System.Drawing.Size(431, 20);
            this.txtDispersionNominaObs.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(324, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 13);
            this.label1.TabIndex = 19;
            this.label1.Text = "Observaciones:";
            // 
            // txtAnexo
            // 
            this.txtAnexo.Location = new System.Drawing.Point(95, 137);
            this.txtAnexo.Name = "txtAnexo";
            this.txtAnexo.Size = new System.Drawing.Size(253, 20);
            this.txtAnexo.TabIndex = 26;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(49, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 25;
            this.label3.Text = "Anexo:";
            // 
            // rbtnInfSolicitadaExc
            // 
            this.rbtnInfSolicitadaExc.AutoSize = true;
            this.rbtnInfSolicitadaExc.Location = new System.Drawing.Point(12, 114);
            this.rbtnInfSolicitadaExc.Name = "rbtnInfSolicitadaExc";
            this.rbtnInfSolicitadaExc.Size = new System.Drawing.Size(581, 17);
            this.rbtnInfSolicitadaExc.TabIndex = 24;
            this.rbtnInfSolicitadaExc.TabStop = true;
            this.rbtnInfSolicitadaExc.Text = "Se proporciona la información solicitada por la autoridad excepto lo señalado en " +
    "el siguiente anexo al presente escrito:";
            this.rbtnInfSolicitadaExc.UseVisualStyleBackColor = true;
            // 
            // rbtnInfSolicitada
            // 
            this.rbtnInfSolicitada.AutoSize = true;
            this.rbtnInfSolicitada.Location = new System.Drawing.Point(12, 91);
            this.rbtnInfSolicitada.Name = "rbtnInfSolicitada";
            this.rbtnInfSolicitada.Size = new System.Drawing.Size(318, 17);
            this.rbtnInfSolicitada.TabIndex = 23;
            this.rbtnInfSolicitada.TabStop = true;
            this.rbtnInfSolicitada.Text = "Se proporciona toda  la información solicitada por la autoridad.";
            this.rbtnInfSolicitada.UseVisualStyleBackColor = true;
            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(438, 167);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(75, 23);
            this.btnAgregar.TabIndex = 28;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.UseVisualStyleBackColor = true;
            // 
            // btnRegreso
            // 
            this.btnRegreso.Location = new System.Drawing.Point(519, 167);
            this.btnRegreso.Name = "btnRegreso";
            this.btnRegreso.Size = new System.Drawing.Size(75, 23);
            this.btnRegreso.TabIndex = 27;
            this.btnRegreso.Text = "Regresar";
            this.btnRegreso.UseVisualStyleBackColor = true;
            this.btnRegreso.Click += new System.EventHandler(this.btnRegreso_Click);
            // 
            // frmInfMovimientoElect
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(606, 202);
            this.Controls.Add(this.btnAgregar);
            this.Controls.Add(this.btnRegreso);
            this.Controls.Add(this.txtAnexo);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.rbtnInfSolicitadaExc);
            this.Controls.Add(this.rbtnInfSolicitada);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtDispersionNominaObs);
            this.Controls.Add(this.txtMovElectronicosObs);
            this.Controls.Add(this.cbDispersionNomina);
            this.Controls.Add(this.cbMovElectronicos);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmInfMovimientoElect";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GERA - Información de  movimiento electrónicos";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox cbDispersionNomina;
        private System.Windows.Forms.CheckBox cbMovElectronicos;
        private System.Windows.Forms.TextBox txtMovElectronicosObs;
        private System.Windows.Forms.TextBox txtDispersionNominaObs;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAnexo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton rbtnInfSolicitadaExc;
        private System.Windows.Forms.RadioButton rbtnInfSolicitada;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Button btnRegreso;
    }
}