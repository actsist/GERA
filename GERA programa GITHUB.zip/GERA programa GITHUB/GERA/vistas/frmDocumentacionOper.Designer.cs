﻿namespace document_management
{
    partial class frmDocumentacionOper
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDocumentacionOper));
            this.cbCheques = new System.Windows.Forms.CheckBox();
            this.rbtnChequesCS = new System.Windows.Forms.RadioButton();
            this.cbFichasDeposito = new System.Windows.Forms.CheckBox();
            this.cbFichasRetiro = new System.Windows.Forms.CheckBox();
            this.cbComprobantes = new System.Windows.Forms.CheckBox();
            this.cbOtro = new System.Windows.Forms.CheckBox();
            this.rbtnFichasDepositoCS = new System.Windows.Forms.RadioButton();
            this.rbtnFichasRetiroCS = new System.Windows.Forms.RadioButton();
            this.rbtnComprobantesCS = new System.Windows.Forms.RadioButton();
            this.rbtnOtroCS = new System.Windows.Forms.RadioButton();
            this.rbtnChequesCC = new System.Windows.Forms.RadioButton();
            this.rbtnFichasDepositoCC = new System.Windows.Forms.RadioButton();
            this.rbtnFichasRetiroCC = new System.Windows.Forms.RadioButton();
            this.rbtnComprobantesCC = new System.Windows.Forms.RadioButton();
            this.rbtnOtroCC = new System.Windows.Forms.RadioButton();
            this.txtChequesObs = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtEspecifica = new System.Windows.Forms.TextBox();
            this.rbtnInfSolicitada = new System.Windows.Forms.RadioButton();
            this.rbtnInfSolicitadaExc = new System.Windows.Forms.RadioButton();
            this.txtAnexo = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.btnRegreso = new System.Windows.Forms.Button();
            this.txtFichasDepositoObs = new System.Windows.Forms.TextBox();
            this.txtFichasRetiroObs = new System.Windows.Forms.TextBox();
            this.txtComprobantesObs = new System.Windows.Forms.TextBox();
            this.txtOtroObs = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // cbCheques
            // 
            this.cbCheques.AutoSize = true;
            this.cbCheques.Location = new System.Drawing.Point(12, 27);
            this.cbCheques.Name = "cbCheques";
            this.cbCheques.Size = new System.Drawing.Size(68, 17);
            this.cbCheques.TabIndex = 0;
            this.cbCheques.Text = "Cheques";
            this.cbCheques.UseVisualStyleBackColor = true;
            // 
            // rbtnChequesCS
            // 
            this.rbtnChequesCS.AutoSize = true;
            this.rbtnChequesCS.Location = new System.Drawing.Point(127, 26);
            this.rbtnChequesCS.Name = "rbtnChequesCS";
            this.rbtnChequesCS.Size = new System.Drawing.Size(84, 17);
            this.rbtnChequesCS.TabIndex = 1;
            this.rbtnChequesCS.TabStop = true;
            this.rbtnChequesCS.Text = "Copia simple";
            this.rbtnChequesCS.UseVisualStyleBackColor = true;
            // 
            // cbFichasDeposito
            // 
            this.cbFichasDeposito.AutoSize = true;
            this.cbFichasDeposito.Location = new System.Drawing.Point(12, 53);
            this.cbFichasDeposito.Name = "cbFichasDeposito";
            this.cbFichasDeposito.Size = new System.Drawing.Size(115, 17);
            this.cbFichasDeposito.TabIndex = 2;
            this.cbFichasDeposito.Text = "Fichas de depósito";
            this.cbFichasDeposito.UseVisualStyleBackColor = true;
            // 
            // cbFichasRetiro
            // 
            this.cbFichasRetiro.AutoSize = true;
            this.cbFichasRetiro.Location = new System.Drawing.Point(12, 79);
            this.cbFichasRetiro.Name = "cbFichasRetiro";
            this.cbFichasRetiro.Size = new System.Drawing.Size(98, 17);
            this.cbFichasRetiro.TabIndex = 3;
            this.cbFichasRetiro.Text = "Fichas de retiro";
            this.cbFichasRetiro.UseVisualStyleBackColor = true;
            // 
            // cbComprobantes
            // 
            this.cbComprobantes.AutoSize = true;
            this.cbComprobantes.Location = new System.Drawing.Point(12, 105);
            this.cbComprobantes.Name = "cbComprobantes";
            this.cbComprobantes.Size = new System.Drawing.Size(94, 17);
            this.cbComprobantes.TabIndex = 4;
            this.cbComprobantes.Text = "Comprobantes";
            this.cbComprobantes.UseVisualStyleBackColor = true;
            // 
            // cbOtro
            // 
            this.cbOtro.AutoSize = true;
            this.cbOtro.Location = new System.Drawing.Point(12, 131);
            this.cbOtro.Name = "cbOtro";
            this.cbOtro.Size = new System.Drawing.Size(46, 17);
            this.cbOtro.TabIndex = 5;
            this.cbOtro.Text = "Otro";
            this.cbOtro.UseVisualStyleBackColor = true;
            // 
            // rbtnFichasDepositoCS
            // 
            this.rbtnFichasDepositoCS.AutoSize = true;
            this.rbtnFichasDepositoCS.Location = new System.Drawing.Point(127, 53);
            this.rbtnFichasDepositoCS.Name = "rbtnFichasDepositoCS";
            this.rbtnFichasDepositoCS.Size = new System.Drawing.Size(84, 17);
            this.rbtnFichasDepositoCS.TabIndex = 6;
            this.rbtnFichasDepositoCS.TabStop = true;
            this.rbtnFichasDepositoCS.Text = "Copia simple";
            this.rbtnFichasDepositoCS.UseVisualStyleBackColor = true;
            // 
            // rbtnFichasRetiroCS
            // 
            this.rbtnFichasRetiroCS.AutoSize = true;
            this.rbtnFichasRetiroCS.Location = new System.Drawing.Point(127, 79);
            this.rbtnFichasRetiroCS.Name = "rbtnFichasRetiroCS";
            this.rbtnFichasRetiroCS.Size = new System.Drawing.Size(84, 17);
            this.rbtnFichasRetiroCS.TabIndex = 7;
            this.rbtnFichasRetiroCS.TabStop = true;
            this.rbtnFichasRetiroCS.Text = "Copia simple";
            this.rbtnFichasRetiroCS.UseVisualStyleBackColor = true;
            // 
            // rbtnComprobantesCS
            // 
            this.rbtnComprobantesCS.AutoSize = true;
            this.rbtnComprobantesCS.Location = new System.Drawing.Point(127, 105);
            this.rbtnComprobantesCS.Name = "rbtnComprobantesCS";
            this.rbtnComprobantesCS.Size = new System.Drawing.Size(84, 17);
            this.rbtnComprobantesCS.TabIndex = 8;
            this.rbtnComprobantesCS.TabStop = true;
            this.rbtnComprobantesCS.Text = "Copia simple";
            this.rbtnComprobantesCS.UseVisualStyleBackColor = true;
            // 
            // rbtnOtroCS
            // 
            this.rbtnOtroCS.AutoSize = true;
            this.rbtnOtroCS.Location = new System.Drawing.Point(127, 131);
            this.rbtnOtroCS.Name = "rbtnOtroCS";
            this.rbtnOtroCS.Size = new System.Drawing.Size(84, 17);
            this.rbtnOtroCS.TabIndex = 9;
            this.rbtnOtroCS.TabStop = true;
            this.rbtnOtroCS.Text = "Copia simple";
            this.rbtnOtroCS.UseVisualStyleBackColor = true;
            // 
            // rbtnChequesCC
            // 
            this.rbtnChequesCC.AutoSize = true;
            this.rbtnChequesCC.Location = new System.Drawing.Point(244, 26);
            this.rbtnChequesCC.Name = "rbtnChequesCC";
            this.rbtnChequesCC.Size = new System.Drawing.Size(104, 17);
            this.rbtnChequesCC.TabIndex = 10;
            this.rbtnChequesCC.TabStop = true;
            this.rbtnChequesCC.Text = "Copia certificada";
            this.rbtnChequesCC.UseVisualStyleBackColor = true;
            // 
            // rbtnFichasDepositoCC
            // 
            this.rbtnFichasDepositoCC.AutoSize = true;
            this.rbtnFichasDepositoCC.Location = new System.Drawing.Point(244, 52);
            this.rbtnFichasDepositoCC.Name = "rbtnFichasDepositoCC";
            this.rbtnFichasDepositoCC.Size = new System.Drawing.Size(104, 17);
            this.rbtnFichasDepositoCC.TabIndex = 11;
            this.rbtnFichasDepositoCC.TabStop = true;
            this.rbtnFichasDepositoCC.Text = "Copia certificada";
            this.rbtnFichasDepositoCC.UseVisualStyleBackColor = true;
            // 
            // rbtnFichasRetiroCC
            // 
            this.rbtnFichasRetiroCC.AutoSize = true;
            this.rbtnFichasRetiroCC.Location = new System.Drawing.Point(244, 79);
            this.rbtnFichasRetiroCC.Name = "rbtnFichasRetiroCC";
            this.rbtnFichasRetiroCC.Size = new System.Drawing.Size(104, 17);
            this.rbtnFichasRetiroCC.TabIndex = 12;
            this.rbtnFichasRetiroCC.TabStop = true;
            this.rbtnFichasRetiroCC.Text = "Copia certificada";
            this.rbtnFichasRetiroCC.UseVisualStyleBackColor = true;
            // 
            // rbtnComprobantesCC
            // 
            this.rbtnComprobantesCC.AutoSize = true;
            this.rbtnComprobantesCC.Location = new System.Drawing.Point(244, 105);
            this.rbtnComprobantesCC.Name = "rbtnComprobantesCC";
            this.rbtnComprobantesCC.Size = new System.Drawing.Size(104, 17);
            this.rbtnComprobantesCC.TabIndex = 13;
            this.rbtnComprobantesCC.TabStop = true;
            this.rbtnComprobantesCC.Text = "Copia certificada";
            this.rbtnComprobantesCC.UseVisualStyleBackColor = true;
            // 
            // rbtnOtroCC
            // 
            this.rbtnOtroCC.AutoSize = true;
            this.rbtnOtroCC.Location = new System.Drawing.Point(244, 131);
            this.rbtnOtroCC.Name = "rbtnOtroCC";
            this.rbtnOtroCC.Size = new System.Drawing.Size(104, 17);
            this.rbtnOtroCC.TabIndex = 14;
            this.rbtnOtroCC.TabStop = true;
            this.rbtnOtroCC.Text = "Copia certificada";
            this.rbtnOtroCC.UseVisualStyleBackColor = true;
            // 
            // txtChequesObs
            // 
            this.txtChequesObs.Location = new System.Drawing.Point(379, 25);
            this.txtChequesObs.Name = "txtChequesObs";
            this.txtChequesObs.Size = new System.Drawing.Size(249, 20);
            this.txtChequesObs.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(376, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 13);
            this.label1.TabIndex = 16;
            this.label1.Text = "Observaciones:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 157);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "Especifica:";
            // 
            // txtEspecifica
            // 
            this.txtEspecifica.Location = new System.Drawing.Point(95, 154);
            this.txtEspecifica.Name = "txtEspecifica";
            this.txtEspecifica.Size = new System.Drawing.Size(253, 20);
            this.txtEspecifica.TabIndex = 18;
            // 
            // rbtnInfSolicitada
            // 
            this.rbtnInfSolicitada.AutoSize = true;
            this.rbtnInfSolicitada.Location = new System.Drawing.Point(12, 191);
            this.rbtnInfSolicitada.Name = "rbtnInfSolicitada";
            this.rbtnInfSolicitada.Size = new System.Drawing.Size(318, 17);
            this.rbtnInfSolicitada.TabIndex = 19;
            this.rbtnInfSolicitada.TabStop = true;
            this.rbtnInfSolicitada.Text = "Se proporciona toda  la información solicitada por la autoridad.";
            this.rbtnInfSolicitada.UseVisualStyleBackColor = true;
            // 
            // rbtnInfSolicitadaExc
            // 
            this.rbtnInfSolicitadaExc.AutoSize = true;
            this.rbtnInfSolicitadaExc.Location = new System.Drawing.Point(12, 214);
            this.rbtnInfSolicitadaExc.Name = "rbtnInfSolicitadaExc";
            this.rbtnInfSolicitadaExc.Size = new System.Drawing.Size(581, 17);
            this.rbtnInfSolicitadaExc.TabIndex = 20;
            this.rbtnInfSolicitadaExc.TabStop = true;
            this.rbtnInfSolicitadaExc.Text = "Se proporciona la información solicitada por la autoridad excepto lo señalado en " +
    "el siguiente anexo al presente escrito:";
            this.rbtnInfSolicitadaExc.UseVisualStyleBackColor = true;
            // 
            // txtAnexo
            // 
            this.txtAnexo.Location = new System.Drawing.Point(95, 237);
            this.txtAnexo.Name = "txtAnexo";
            this.txtAnexo.Size = new System.Drawing.Size(253, 20);
            this.txtAnexo.TabIndex = 22;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(49, 240);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 21;
            this.label3.Text = "Anexo:";
            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(476, 263);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(75, 23);
            this.btnAgregar.TabIndex = 24;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.UseVisualStyleBackColor = true;
            // 
            // btnRegreso
            // 
            this.btnRegreso.Location = new System.Drawing.Point(557, 263);
            this.btnRegreso.Name = "btnRegreso";
            this.btnRegreso.Size = new System.Drawing.Size(75, 23);
            this.btnRegreso.TabIndex = 23;
            this.btnRegreso.Text = "Regresar";
            this.btnRegreso.UseVisualStyleBackColor = true;
            this.btnRegreso.Click += new System.EventHandler(this.btnRegreso_Click);
            // 
            // txtFichasDepositoObs
            // 
            this.txtFichasDepositoObs.Location = new System.Drawing.Point(379, 51);
            this.txtFichasDepositoObs.Name = "txtFichasDepositoObs";
            this.txtFichasDepositoObs.Size = new System.Drawing.Size(249, 20);
            this.txtFichasDepositoObs.TabIndex = 25;
            // 
            // txtFichasRetiroObs
            // 
            this.txtFichasRetiroObs.Location = new System.Drawing.Point(379, 77);
            this.txtFichasRetiroObs.Name = "txtFichasRetiroObs";
            this.txtFichasRetiroObs.Size = new System.Drawing.Size(249, 20);
            this.txtFichasRetiroObs.TabIndex = 26;
            // 
            // txtComprobantesObs
            // 
            this.txtComprobantesObs.Location = new System.Drawing.Point(379, 103);
            this.txtComprobantesObs.Name = "txtComprobantesObs";
            this.txtComprobantesObs.Size = new System.Drawing.Size(249, 20);
            this.txtComprobantesObs.TabIndex = 27;
            // 
            // txtOtroObs
            // 
            this.txtOtroObs.Location = new System.Drawing.Point(379, 129);
            this.txtOtroObs.Name = "txtOtroObs";
            this.txtOtroObs.Size = new System.Drawing.Size(249, 20);
            this.txtOtroObs.TabIndex = 28;
            // 
            // frmDocumentacionOper
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(644, 298);
            this.Controls.Add(this.txtOtroObs);
            this.Controls.Add(this.txtComprobantesObs);
            this.Controls.Add(this.txtFichasRetiroObs);
            this.Controls.Add(this.txtFichasDepositoObs);
            this.Controls.Add(this.btnAgregar);
            this.Controls.Add(this.btnRegreso);
            this.Controls.Add(this.txtAnexo);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.rbtnInfSolicitadaExc);
            this.Controls.Add(this.rbtnInfSolicitada);
            this.Controls.Add(this.txtEspecifica);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtChequesObs);
            this.Controls.Add(this.rbtnOtroCC);
            this.Controls.Add(this.rbtnComprobantesCC);
            this.Controls.Add(this.rbtnFichasRetiroCC);
            this.Controls.Add(this.rbtnFichasDepositoCC);
            this.Controls.Add(this.rbtnChequesCC);
            this.Controls.Add(this.rbtnOtroCS);
            this.Controls.Add(this.rbtnComprobantesCS);
            this.Controls.Add(this.rbtnFichasRetiroCS);
            this.Controls.Add(this.rbtnFichasDepositoCS);
            this.Controls.Add(this.cbOtro);
            this.Controls.Add(this.cbComprobantes);
            this.Controls.Add(this.cbFichasRetiro);
            this.Controls.Add(this.cbFichasDeposito);
            this.Controls.Add(this.rbtnChequesCS);
            this.Controls.Add(this.cbCheques);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmDocumentacionOper";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GERA - Documentación de operaciones";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox cbCheques;
        private System.Windows.Forms.RadioButton rbtnChequesCS;
        private System.Windows.Forms.CheckBox cbFichasDeposito;
        private System.Windows.Forms.CheckBox cbFichasRetiro;
        private System.Windows.Forms.CheckBox cbComprobantes;
        private System.Windows.Forms.CheckBox cbOtro;
        private System.Windows.Forms.RadioButton rbtnFichasDepositoCS;
        private System.Windows.Forms.RadioButton rbtnFichasRetiroCS;
        private System.Windows.Forms.RadioButton rbtnComprobantesCS;
        private System.Windows.Forms.RadioButton rbtnOtroCS;
        private System.Windows.Forms.RadioButton rbtnChequesCC;
        private System.Windows.Forms.RadioButton rbtnFichasDepositoCC;
        private System.Windows.Forms.RadioButton rbtnFichasRetiroCC;
        private System.Windows.Forms.RadioButton rbtnComprobantesCC;
        private System.Windows.Forms.RadioButton rbtnOtroCC;
        private System.Windows.Forms.TextBox txtChequesObs;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtEspecifica;
        private System.Windows.Forms.RadioButton rbtnInfSolicitada;
        private System.Windows.Forms.RadioButton rbtnInfSolicitadaExc;
        private System.Windows.Forms.TextBox txtAnexo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Button btnRegreso;
        private System.Windows.Forms.TextBox txtFichasDepositoObs;
        private System.Windows.Forms.TextBox txtFichasRetiroObs;
        private System.Windows.Forms.TextBox txtComprobantesObs;
        private System.Windows.Forms.TextBox txtOtroObs;
    }
}