﻿namespace document_management
{
    partial class frmRespuestaNegativa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRespuestaNegativa));
            this.btnRegreso = new System.Windows.Forms.Button();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtAutoridadSolicitante = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.dtpDocumentoFecha = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.txtFolio = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbtnNegativaAPE = new System.Windows.Forms.RadioButton();
            this.rbtnNegativa = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtExpediente = new System.Windows.Forms.TextBox();
            this.txtOficio = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rbtnSituacionFondos = new System.Windows.Forms.RadioButton();
            this.rbtnAseguramiento = new System.Windows.Forms.RadioButton();
            this.rbtnDesbloqueo = new System.Windows.Forms.RadioButton();
            this.rbtnInformacion = new System.Windows.Forms.RadioButton();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.txtControlInterno = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtFirmante = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPuesto = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.sfd = new System.Windows.Forms.SaveFileDialog();
            this.btnGenerarNuevo = new System.Windows.Forms.Button();
            this.cbAbrirDocumento = new System.Windows.Forms.CheckBox();
            this.btnVistaPrevia = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.taObservaciones = new System.Windows.Forms.RichTextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnRegreso
            // 
            this.btnRegreso.Location = new System.Drawing.Point(791, 491);
            this.btnRegreso.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRegreso.Name = "btnRegreso";
            this.btnRegreso.Size = new System.Drawing.Size(100, 28);
            this.btnRegreso.TabIndex = 14;
            this.btnRegreso.Text = "Salir";
            this.btnRegreso.UseVisualStyleBackColor = true;
            this.btnRegreso.Click += new System.EventHandler(this.btnRegreso_Click);
            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(525, 491);
            this.btnAgregar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(115, 28);
            this.btnAgregar.TabIndex = 12;
            this.btnAgregar.Text = "Guardar";
            this.btnAgregar.UseVisualStyleBackColor = true;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightGray;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label11);
            this.panel2.Location = new System.Drawing.Point(16, 15);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(874, 30);
            this.panel2.TabIndex = 40;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(343, 5);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(174, 20);
            this.label11.TabIndex = 0;
            this.label11.Text = "DATOS GENERALES";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.txtAutoridadSolicitante);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.dtpDocumentoFecha);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.txtFolio);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.txtExpediente);
            this.panel1.Controls.Add(this.txtOficio);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Location = new System.Drawing.Point(16, 44);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(874, 212);
            this.panel1.TabIndex = 39;
            // 
            // txtAutoridadSolicitante
            // 
            this.txtAutoridadSolicitante.Location = new System.Drawing.Point(152, 137);
            this.txtAutoridadSolicitante.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtAutoridadSolicitante.Name = "txtAutoridadSolicitante";
            this.txtAutoridadSolicitante.Size = new System.Drawing.Size(259, 22);
            this.txtAutoridadSolicitante.TabIndex = 4;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(4, 140);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(140, 17);
            this.label9.TabIndex = 14;
            this.label9.Text = "Autoridad solicitante:";
            // 
            // dtpDocumentoFecha
            // 
            this.dtpDocumentoFecha.Location = new System.Drawing.Point(152, 9);
            this.dtpDocumentoFecha.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtpDocumentoFecha.Name = "dtpDocumentoFecha";
            this.dtpDocumentoFecha.Size = new System.Drawing.Size(259, 22);
            this.dtpDocumentoFecha.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(4, 15);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 17);
            this.label4.TabIndex = 1;
            this.label4.Text = "Fecha:";
            // 
            // txtFolio
            // 
            this.txtFolio.Location = new System.Drawing.Point(152, 105);
            this.txtFolio.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtFolio.Name = "txtFolio";
            this.txtFolio.Size = new System.Drawing.Size(259, 22);
            this.txtFolio.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbtnNegativaAPE);
            this.groupBox1.Controls.Add(this.rbtnNegativa);
            this.groupBox1.Location = new System.Drawing.Point(420, 11);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(443, 89);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Respuesta a Requerimiento:";
            // 
            // rbtnNegativaAPE
            // 
            this.rbtnNegativaAPE.AutoSize = true;
            this.rbtnNegativaAPE.Location = new System.Drawing.Point(9, 31);
            this.rbtnNegativaAPE.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnNegativaAPE.Name = "rbtnNegativaAPE";
            this.rbtnNegativaAPE.Size = new System.Drawing.Size(154, 38);
            this.rbtnNegativaAPE.TabIndex = 3;
            this.rbtnNegativaAPE.Text = "Negativa a petición \r\nespecífica";
            this.rbtnNegativaAPE.UseVisualStyleBackColor = true;
            // 
            // rbtnNegativa
            // 
            this.rbtnNegativa.AutoSize = true;
            this.rbtnNegativa.Location = new System.Drawing.Point(207, 39);
            this.rbtnNegativa.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnNegativa.Name = "rbtnNegativa";
            this.rbtnNegativa.Size = new System.Drawing.Size(85, 21);
            this.rbtnNegativa.TabIndex = 1;
            this.rbtnNegativa.Text = "Negativa";
            this.rbtnNegativa.UseVisualStyleBackColor = true;
            this.rbtnNegativa.CheckedChanged += new System.EventHandler(this.rbtnNegativa_CheckedChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(4, 79);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 17);
            this.label5.TabIndex = 9;
            this.label5.Text = "Expediente:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(4, 111);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 17);
            this.label6.TabIndex = 11;
            this.label6.Text = "Folio:";
            // 
            // txtExpediente
            // 
            this.txtExpediente.Location = new System.Drawing.Point(152, 73);
            this.txtExpediente.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtExpediente.Name = "txtExpediente";
            this.txtExpediente.Size = new System.Drawing.Size(259, 22);
            this.txtExpediente.TabIndex = 2;
            // 
            // txtOficio
            // 
            this.txtOficio.Location = new System.Drawing.Point(152, 41);
            this.txtOficio.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtOficio.Name = "txtOficio";
            this.txtOficio.Size = new System.Drawing.Size(259, 22);
            this.txtOficio.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(4, 47);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 17);
            this.label8.TabIndex = 7;
            this.label8.Text = "Oficio:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rbtnSituacionFondos);
            this.groupBox2.Controls.Add(this.rbtnAseguramiento);
            this.groupBox2.Controls.Add(this.rbtnDesbloqueo);
            this.groupBox2.Controls.Add(this.rbtnInformacion);
            this.groupBox2.Location = new System.Drawing.Point(420, 106);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Size = new System.Drawing.Size(443, 89);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Asunto:";
            // 
            // rbtnSituacionFondos
            // 
            this.rbtnSituacionFondos.AutoSize = true;
            this.rbtnSituacionFondos.Location = new System.Drawing.Point(9, 54);
            this.rbtnSituacionFondos.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnSituacionFondos.Name = "rbtnSituacionFondos";
            this.rbtnSituacionFondos.Size = new System.Drawing.Size(256, 21);
            this.rbtnSituacionFondos.TabIndex = 4;
            this.rbtnSituacionFondos.TabStop = true;
            this.rbtnSituacionFondos.Text = "Transferencia o situación de fondos";
            this.rbtnSituacionFondos.UseVisualStyleBackColor = true;
            // 
            // rbtnAseguramiento
            // 
            this.rbtnAseguramiento.AutoSize = true;
            this.rbtnAseguramiento.Location = new System.Drawing.Point(305, 22);
            this.rbtnAseguramiento.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnAseguramiento.Name = "rbtnAseguramiento";
            this.rbtnAseguramiento.Size = new System.Drawing.Size(124, 21);
            this.rbtnAseguramiento.TabIndex = 3;
            this.rbtnAseguramiento.TabStop = true;
            this.rbtnAseguramiento.Text = "Aseguramiento";
            this.rbtnAseguramiento.UseVisualStyleBackColor = true;
            // 
            // rbtnDesbloqueo
            // 
            this.rbtnDesbloqueo.AutoSize = true;
            this.rbtnDesbloqueo.Location = new System.Drawing.Point(167, 23);
            this.rbtnDesbloqueo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnDesbloqueo.Name = "rbtnDesbloqueo";
            this.rbtnDesbloqueo.Size = new System.Drawing.Size(105, 21);
            this.rbtnDesbloqueo.TabIndex = 2;
            this.rbtnDesbloqueo.TabStop = true;
            this.rbtnDesbloqueo.Text = "Desbloqueo";
            this.rbtnDesbloqueo.UseVisualStyleBackColor = true;
            // 
            // rbtnInformacion
            // 
            this.rbtnInformacion.AutoSize = true;
            this.rbtnInformacion.Location = new System.Drawing.Point(8, 23);
            this.rbtnInformacion.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnInformacion.Name = "rbtnInformacion";
            this.rbtnInformacion.Size = new System.Drawing.Size(102, 21);
            this.rbtnInformacion.TabIndex = 1;
            this.rbtnInformacion.TabStop = true;
            this.rbtnInformacion.Text = "Información";
            this.rbtnInformacion.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.label1);
            this.panel6.Controls.Add(this.txtControlInterno);
            this.panel6.Controls.Add(this.label2);
            this.panel6.Controls.Add(this.txtFirmante);
            this.panel6.Controls.Add(this.label3);
            this.panel6.Controls.Add(this.txtPuesto);
            this.panel6.Location = new System.Drawing.Point(15, 412);
            this.panel6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(874, 59);
            this.panel6.TabIndex = 43;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 6);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 17);
            this.label1.TabIndex = 27;
            this.label1.Text = "Firmante:";
            // 
            // txtControlInterno
            // 
            this.txtControlInterno.Location = new System.Drawing.Point(584, 26);
            this.txtControlInterno.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtControlInterno.Name = "txtControlInterno";
            this.txtControlInterno.Size = new System.Drawing.Size(279, 22);
            this.txtControlInterno.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(580, 6);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 17);
            this.label2.TabIndex = 29;
            this.label2.Text = "Control interno:";
            // 
            // txtFirmante
            // 
            this.txtFirmante.Location = new System.Drawing.Point(8, 26);
            this.txtFirmante.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtFirmante.Name = "txtFirmante";
            this.txtFirmante.Size = new System.Drawing.Size(279, 22);
            this.txtFirmante.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(292, 6);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 17);
            this.label3.TabIndex = 28;
            this.label3.Text = "Puesto:";
            // 
            // txtPuesto
            // 
            this.txtPuesto.Location = new System.Drawing.Point(296, 26);
            this.txtPuesto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtPuesto.Name = "txtPuesto";
            this.txtPuesto.Size = new System.Drawing.Size(279, 22);
            this.txtPuesto.TabIndex = 9;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.LightGray;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.label13);
            this.panel5.Location = new System.Drawing.Point(15, 385);
            this.panel5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(874, 30);
            this.panel5.TabIndex = 42;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(393, 4);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 20);
            this.label13.TabIndex = 0;
            this.label13.Text = "FIRMA";
            // 
            // btnGenerarNuevo
            // 
            this.btnGenerarNuevo.Location = new System.Drawing.Point(648, 491);
            this.btnGenerarNuevo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnGenerarNuevo.Name = "btnGenerarNuevo";
            this.btnGenerarNuevo.Size = new System.Drawing.Size(135, 28);
            this.btnGenerarNuevo.TabIndex = 13;
            this.btnGenerarNuevo.Text = "Guardar y nuevo";
            this.btnGenerarNuevo.UseVisualStyleBackColor = true;
            this.btnGenerarNuevo.Click += new System.EventHandler(this.btnGenerarNuevo_Click);
            // 
            // cbAbrirDocumento
            // 
            this.cbAbrirDocumento.AutoSize = true;
            this.cbAbrirDocumento.Location = new System.Drawing.Point(15, 498);
            this.cbAbrirDocumento.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbAbrirDocumento.Name = "cbAbrirDocumento";
            this.cbAbrirDocumento.Size = new System.Drawing.Size(203, 21);
            this.cbAbrirDocumento.TabIndex = 11;
            this.cbAbrirDocumento.Text = "Abrir documento al generar";
            this.cbAbrirDocumento.UseVisualStyleBackColor = true;
            // 
            // btnVistaPrevia
            // 
            this.btnVistaPrevia.Location = new System.Drawing.Point(360, 491);
            this.btnVistaPrevia.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnVistaPrevia.Name = "btnVistaPrevia";
            this.btnVistaPrevia.Size = new System.Drawing.Size(115, 28);
            this.btnVistaPrevia.TabIndex = 46;
            this.btnVistaPrevia.Text = "Vista Previa";
            this.btnVistaPrevia.UseVisualStyleBackColor = true;
            this.btnVistaPrevia.Click += new System.EventHandler(this.btnVistaPrevia_Click);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.taObservaciones);
            this.panel3.Location = new System.Drawing.Point(15, 292);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(874, 86);
            this.panel3.TabIndex = 48;
            // 
            // taObservaciones
            // 
            this.taObservaciones.Location = new System.Drawing.Point(11, 10);
            this.taObservaciones.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.taObservaciones.Name = "taObservaciones";
            this.taObservaciones.Size = new System.Drawing.Size(851, 64);
            this.taObservaciones.TabIndex = 1;
            this.taObservaciones.Text = "";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.LightGray;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label15);
            this.panel4.Location = new System.Drawing.Point(15, 265);
            this.panel4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(874, 30);
            this.panel4.TabIndex = 47;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(355, 4);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(153, 20);
            this.label15.TabIndex = 0;
            this.label15.Text = "OBSERVACIONES";
            // 
            // frmRespuestaNegativa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(909, 530);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.btnVistaPrevia);
            this.Controls.Add(this.cbAbrirDocumento);
            this.Controls.Add(this.btnGenerarNuevo);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnAgregar);
            this.Controls.Add(this.btnRegreso);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmRespuestaNegativa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GERA - Negativa";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmRespuestaNegativa_FormClosing);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRegreso;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DateTimePicker dtpDocumentoFecha;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtFolio;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbtnNegativaAPE;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtExpediente;
        private System.Windows.Forms.TextBox txtOficio;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rbtnSituacionFondos;
        private System.Windows.Forms.RadioButton rbtnAseguramiento;
        private System.Windows.Forms.RadioButton rbtnDesbloqueo;
        private System.Windows.Forms.RadioButton rbtnInformacion;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtControlInterno;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtFirmante;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPuesto;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.SaveFileDialog sfd;
        private System.Windows.Forms.Button btnGenerarNuevo;
        private System.Windows.Forms.CheckBox cbAbrirDocumento;
        private System.Windows.Forms.TextBox txtAutoridadSolicitante;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton rbtnNegativa;
        private System.Windows.Forms.Button btnVistaPrevia;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.RichTextBox taObservaciones;

    }
}