﻿namespace document_management
{
    partial class frmRespuestaNegativa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRespuestaNegativa));
            this.btnRegreso = new System.Windows.Forms.Button();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtAutoridadSolicitante = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.dtpDocumentoFecha = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.txtFolio = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbtnNegativaAPE = new System.Windows.Forms.RadioButton();
            this.rbtnNegativa = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtExpediente = new System.Windows.Forms.TextBox();
            this.txtOficio = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rbtnSituacionFondos = new System.Windows.Forms.RadioButton();
            this.rbtnAseguramiento = new System.Windows.Forms.RadioButton();
            this.rbtnDesbloqueo = new System.Windows.Forms.RadioButton();
            this.rbtnInformacion = new System.Windows.Forms.RadioButton();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.txtControlInterno = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtFirmante = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPuesto = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.sfd = new System.Windows.Forms.SaveFileDialog();
            this.btnGenerarNuevo = new System.Windows.Forms.Button();
            this.cbAbrirDocumento = new System.Windows.Forms.CheckBox();
            this.btnVistaPrevia = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.taObservaciones = new System.Windows.Forms.RichTextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.cbDirigido = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnRegreso
            // 
            this.btnRegreso.Location = new System.Drawing.Point(593, 399);
            this.btnRegreso.Name = "btnRegreso";
            this.btnRegreso.Size = new System.Drawing.Size(75, 23);
            this.btnRegreso.TabIndex = 14;
            this.btnRegreso.Text = "Salir";
            this.btnRegreso.UseVisualStyleBackColor = true;
            this.btnRegreso.Click += new System.EventHandler(this.btnRegreso_Click);
            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(394, 399);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(86, 23);
            this.btnAgregar.TabIndex = 12;
            this.btnAgregar.Text = "Guardar";
            this.btnAgregar.UseVisualStyleBackColor = true;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightGray;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label11);
            this.panel2.Location = new System.Drawing.Point(12, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(656, 25);
            this.panel2.TabIndex = 40;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(257, 4);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(140, 16);
            this.label11.TabIndex = 0;
            this.label11.Text = "DATOS GENERALES";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.cbDirigido);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.txtAutoridadSolicitante);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.dtpDocumentoFecha);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.txtFolio);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.txtExpediente);
            this.panel1.Controls.Add(this.txtOficio);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Location = new System.Drawing.Point(12, 36);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(656, 173);
            this.panel1.TabIndex = 39;
            // 
            // txtAutoridadSolicitante
            // 
            this.txtAutoridadSolicitante.Location = new System.Drawing.Point(114, 111);
            this.txtAutoridadSolicitante.Name = "txtAutoridadSolicitante";
            this.txtAutoridadSolicitante.Size = new System.Drawing.Size(195, 20);
            this.txtAutoridadSolicitante.TabIndex = 4;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 114);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(105, 13);
            this.label9.TabIndex = 14;
            this.label9.Text = "Autoridad solicitante:";
            // 
            // dtpDocumentoFecha
            // 
            this.dtpDocumentoFecha.Location = new System.Drawing.Point(114, 7);
            this.dtpDocumentoFecha.Name = "dtpDocumentoFecha";
            this.dtpDocumentoFecha.Size = new System.Drawing.Size(195, 20);
            this.dtpDocumentoFecha.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Fecha:";
            // 
            // txtFolio
            // 
            this.txtFolio.Location = new System.Drawing.Point(114, 85);
            this.txtFolio.Name = "txtFolio";
            this.txtFolio.Size = new System.Drawing.Size(195, 20);
            this.txtFolio.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbtnNegativaAPE);
            this.groupBox1.Controls.Add(this.rbtnNegativa);
            this.groupBox1.Location = new System.Drawing.Point(315, 9);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(332, 72);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Respuesta a Requerimiento:";
            // 
            // rbtnNegativaAPE
            // 
            this.rbtnNegativaAPE.AutoSize = true;
            this.rbtnNegativaAPE.Location = new System.Drawing.Point(7, 25);
            this.rbtnNegativaAPE.Name = "rbtnNegativaAPE";
            this.rbtnNegativaAPE.Size = new System.Drawing.Size(120, 30);
            this.rbtnNegativaAPE.TabIndex = 3;
            this.rbtnNegativaAPE.Text = "Negativa a petición \r\nespecífica";
            this.rbtnNegativaAPE.UseVisualStyleBackColor = true;
            // 
            // rbtnNegativa
            // 
            this.rbtnNegativa.AutoSize = true;
            this.rbtnNegativa.Location = new System.Drawing.Point(155, 32);
            this.rbtnNegativa.Name = "rbtnNegativa";
            this.rbtnNegativa.Size = new System.Drawing.Size(68, 17);
            this.rbtnNegativa.TabIndex = 1;
            this.rbtnNegativa.Text = "Negativa";
            this.rbtnNegativa.UseVisualStyleBackColor = true;
            this.rbtnNegativa.CheckedChanged += new System.EventHandler(this.rbtnNegativa_CheckedChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 64);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Expediente:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 90);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(32, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Folio:";
            // 
            // txtExpediente
            // 
            this.txtExpediente.Location = new System.Drawing.Point(114, 59);
            this.txtExpediente.Name = "txtExpediente";
            this.txtExpediente.Size = new System.Drawing.Size(195, 20);
            this.txtExpediente.TabIndex = 2;
            // 
            // txtOficio
            // 
            this.txtOficio.Location = new System.Drawing.Point(114, 33);
            this.txtOficio.Name = "txtOficio";
            this.txtOficio.Size = new System.Drawing.Size(195, 20);
            this.txtOficio.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 38);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Oficio:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rbtnSituacionFondos);
            this.groupBox2.Controls.Add(this.rbtnAseguramiento);
            this.groupBox2.Controls.Add(this.rbtnDesbloqueo);
            this.groupBox2.Controls.Add(this.rbtnInformacion);
            this.groupBox2.Location = new System.Drawing.Point(315, 86);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(332, 72);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Asunto:";
            // 
            // rbtnSituacionFondos
            // 
            this.rbtnSituacionFondos.AutoSize = true;
            this.rbtnSituacionFondos.Location = new System.Drawing.Point(7, 44);
            this.rbtnSituacionFondos.Name = "rbtnSituacionFondos";
            this.rbtnSituacionFondos.Size = new System.Drawing.Size(194, 17);
            this.rbtnSituacionFondos.TabIndex = 4;
            this.rbtnSituacionFondos.TabStop = true;
            this.rbtnSituacionFondos.Text = "Transferencia o situación de fondos";
            this.rbtnSituacionFondos.UseVisualStyleBackColor = true;
            // 
            // rbtnAseguramiento
            // 
            this.rbtnAseguramiento.AutoSize = true;
            this.rbtnAseguramiento.Location = new System.Drawing.Point(229, 18);
            this.rbtnAseguramiento.Name = "rbtnAseguramiento";
            this.rbtnAseguramiento.Size = new System.Drawing.Size(95, 17);
            this.rbtnAseguramiento.TabIndex = 3;
            this.rbtnAseguramiento.TabStop = true;
            this.rbtnAseguramiento.Text = "Aseguramiento";
            this.rbtnAseguramiento.UseVisualStyleBackColor = true;
            // 
            // rbtnDesbloqueo
            // 
            this.rbtnDesbloqueo.AutoSize = true;
            this.rbtnDesbloqueo.Location = new System.Drawing.Point(125, 19);
            this.rbtnDesbloqueo.Name = "rbtnDesbloqueo";
            this.rbtnDesbloqueo.Size = new System.Drawing.Size(82, 17);
            this.rbtnDesbloqueo.TabIndex = 2;
            this.rbtnDesbloqueo.TabStop = true;
            this.rbtnDesbloqueo.Text = "Desbloqueo";
            this.rbtnDesbloqueo.UseVisualStyleBackColor = true;
            // 
            // rbtnInformacion
            // 
            this.rbtnInformacion.AutoSize = true;
            this.rbtnInformacion.Location = new System.Drawing.Point(6, 19);
            this.rbtnInformacion.Name = "rbtnInformacion";
            this.rbtnInformacion.Size = new System.Drawing.Size(80, 17);
            this.rbtnInformacion.TabIndex = 1;
            this.rbtnInformacion.TabStop = true;
            this.rbtnInformacion.Text = "Información";
            this.rbtnInformacion.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.label1);
            this.panel6.Controls.Add(this.txtControlInterno);
            this.panel6.Controls.Add(this.label2);
            this.panel6.Controls.Add(this.txtFirmante);
            this.panel6.Controls.Add(this.label3);
            this.panel6.Controls.Add(this.txtPuesto);
            this.panel6.Location = new System.Drawing.Point(11, 335);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(656, 48);
            this.panel6.TabIndex = 43;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 27;
            this.label1.Text = "Firmante:";
            // 
            // txtControlInterno
            // 
            this.txtControlInterno.Location = new System.Drawing.Point(438, 21);
            this.txtControlInterno.Name = "txtControlInterno";
            this.txtControlInterno.Size = new System.Drawing.Size(210, 20);
            this.txtControlInterno.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(435, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 13);
            this.label2.TabIndex = 29;
            this.label2.Text = "Control interno:";
            // 
            // txtFirmante
            // 
            this.txtFirmante.Location = new System.Drawing.Point(6, 21);
            this.txtFirmante.Name = "txtFirmante";
            this.txtFirmante.Size = new System.Drawing.Size(210, 20);
            this.txtFirmante.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(219, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 13);
            this.label3.TabIndex = 28;
            this.label3.Text = "Puesto:";
            // 
            // txtPuesto
            // 
            this.txtPuesto.Location = new System.Drawing.Point(222, 21);
            this.txtPuesto.Name = "txtPuesto";
            this.txtPuesto.Size = new System.Drawing.Size(210, 20);
            this.txtPuesto.TabIndex = 9;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.LightGray;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.label13);
            this.panel5.Location = new System.Drawing.Point(11, 313);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(656, 25);
            this.panel5.TabIndex = 42;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(295, 3);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(49, 16);
            this.label13.TabIndex = 0;
            this.label13.Text = "FIRMA";
            // 
            // btnGenerarNuevo
            // 
            this.btnGenerarNuevo.Location = new System.Drawing.Point(486, 399);
            this.btnGenerarNuevo.Name = "btnGenerarNuevo";
            this.btnGenerarNuevo.Size = new System.Drawing.Size(101, 23);
            this.btnGenerarNuevo.TabIndex = 13;
            this.btnGenerarNuevo.Text = "Guardar y nuevo";
            this.btnGenerarNuevo.UseVisualStyleBackColor = true;
            this.btnGenerarNuevo.Click += new System.EventHandler(this.btnGenerarNuevo_Click);
            // 
            // cbAbrirDocumento
            // 
            this.cbAbrirDocumento.AutoSize = true;
            this.cbAbrirDocumento.Location = new System.Drawing.Point(11, 405);
            this.cbAbrirDocumento.Name = "cbAbrirDocumento";
            this.cbAbrirDocumento.Size = new System.Drawing.Size(153, 17);
            this.cbAbrirDocumento.TabIndex = 11;
            this.cbAbrirDocumento.Text = "Abrir documento al generar";
            this.cbAbrirDocumento.UseVisualStyleBackColor = true;
            // 
            // btnVistaPrevia
            // 
            this.btnVistaPrevia.Location = new System.Drawing.Point(270, 399);
            this.btnVistaPrevia.Name = "btnVistaPrevia";
            this.btnVistaPrevia.Size = new System.Drawing.Size(86, 23);
            this.btnVistaPrevia.TabIndex = 46;
            this.btnVistaPrevia.Text = "Vista Previa";
            this.btnVistaPrevia.UseVisualStyleBackColor = true;
            this.btnVistaPrevia.Click += new System.EventHandler(this.btnVistaPrevia_Click);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.taObservaciones);
            this.panel3.Location = new System.Drawing.Point(11, 237);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(656, 70);
            this.panel3.TabIndex = 48;
            // 
            // taObservaciones
            // 
            this.taObservaciones.Location = new System.Drawing.Point(8, 8);
            this.taObservaciones.Name = "taObservaciones";
            this.taObservaciones.Size = new System.Drawing.Size(639, 53);
            this.taObservaciones.TabIndex = 1;
            this.taObservaciones.Text = "";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.LightGray;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label15);
            this.panel4.Location = new System.Drawing.Point(11, 215);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(656, 25);
            this.panel4.TabIndex = 47;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(266, 3);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(123, 16);
            this.label15.TabIndex = 0;
            this.label15.Text = "OBSERVACIONES";
            // 
            // cbDirigido
            // 
            this.cbDirigido.FormattingEnabled = true;
            this.cbDirigido.Items.AddRange(new object[] {
            "Coordinación A aseguramientos",
            "Coordinación B judiciales",
            "Coordinación C hacendarios",
            "Coordinación D operaciones especiales"});
            this.cbDirigido.Location = new System.Drawing.Point(116, 137);
            this.cbDirigido.Name = "cbDirigido";
            this.cbDirigido.Size = new System.Drawing.Size(193, 21);
            this.cbDirigido.TabIndex = 21;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(4, 141);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 13);
            this.label7.TabIndex = 20;
            this.label7.Text = "Atención DGAA:";
            // 
            // frmRespuestaNegativa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(682, 431);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.btnVistaPrevia);
            this.Controls.Add(this.cbAbrirDocumento);
            this.Controls.Add(this.btnGenerarNuevo);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnAgregar);
            this.Controls.Add(this.btnRegreso);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmRespuestaNegativa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GERA - Negativa";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmRespuestaNegativa_FormClosing);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRegreso;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DateTimePicker dtpDocumentoFecha;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtFolio;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbtnNegativaAPE;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtExpediente;
        private System.Windows.Forms.TextBox txtOficio;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rbtnSituacionFondos;
        private System.Windows.Forms.RadioButton rbtnAseguramiento;
        private System.Windows.Forms.RadioButton rbtnDesbloqueo;
        private System.Windows.Forms.RadioButton rbtnInformacion;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtControlInterno;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtFirmante;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPuesto;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.SaveFileDialog sfd;
        private System.Windows.Forms.Button btnGenerarNuevo;
        private System.Windows.Forms.CheckBox cbAbrirDocumento;
        private System.Windows.Forms.TextBox txtAutoridadSolicitante;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton rbtnNegativa;
        private System.Windows.Forms.Button btnVistaPrevia;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.RichTextBox taObservaciones;
        private System.Windows.Forms.ComboBox cbDirigido;
        private System.Windows.Forms.Label label7;
    }
}