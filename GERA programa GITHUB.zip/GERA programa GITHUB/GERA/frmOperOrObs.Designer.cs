﻿namespace document_management
{
    partial class frmOperOrObs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmOperOrObs));
            this.btnAgregar = new System.Windows.Forms.Button();
            this.btnRegreso = new System.Windows.Forms.Button();
            this.taOperObs = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(468, 245);
            this.btnAgregar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(100, 28);
            this.btnAgregar.TabIndex = 26;
            this.btnAgregar.Text = "Aceptar";
            this.btnAgregar.UseVisualStyleBackColor = true;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // btnRegreso
            // 
            this.btnRegreso.Location = new System.Drawing.Point(576, 245);
            this.btnRegreso.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRegreso.Name = "btnRegreso";
            this.btnRegreso.Size = new System.Drawing.Size(100, 28);
            this.btnRegreso.TabIndex = 25;
            this.btnRegreso.Text = "Salir";
            this.btnRegreso.UseVisualStyleBackColor = true;
            this.btnRegreso.Click += new System.EventHandler(this.btnRegreso_Click);
            // 
            // taOperObs
            // 
            this.taOperObs.Location = new System.Drawing.Point(16, 15);
            this.taOperObs.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.taOperObs.Name = "taOperObs";
            this.taOperObs.Size = new System.Drawing.Size(659, 222);
            this.taOperObs.TabIndex = 27;
            this.taOperObs.Text = "";
            // 
            // frmOperOrObs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(692, 281);
            this.Controls.Add(this.taOperObs);
            this.Controls.Add(this.btnAgregar);
            this.Controls.Add(this.btnRegreso);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmOperOrObs";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GERA - Otras operaciones /  observaciones";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Button btnRegreso;
        private System.Windows.Forms.RichTextBox taOperObs;
    }
}