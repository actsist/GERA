﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace document_management.controller
{
    public class Logs
    {
        public static void LogFile(string exceptionName, string message, string starktrace)
        {
            StreamWriter log;
            if (!File.Exists("LogDocumentManager.txt"))
            {
                log = new StreamWriter("LogDocumentManager.txt");
            }
            else
            {
                log = File.AppendText("LogDocumentManager.txt");
            }

            // Write to the file:
            log.WriteLine("EXCEPTION ------------------------------------->");
            log.WriteLine("Data Time:" + DateTime.Now);
            log.WriteLine("Exception Name:" + exceptionName);
            log.WriteLine("Message:" + message);
            log.WriteLine("Trace:" + starktrace);
            log.WriteLine("");

            // Close the stream:
            log.Close();
        }

    }
}
