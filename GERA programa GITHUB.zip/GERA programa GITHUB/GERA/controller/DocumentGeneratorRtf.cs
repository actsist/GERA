﻿using document_management.entidades;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.rtf;
using System;
using System.IO;

namespace document_management.controller
{
    public class DocumentGeneratorRtf
    {
        public static void CrearDocumentoRespuestaPositiva(clsDocumento documento, string path)
        {
            // Conformando documento
            Document reportDocument = new Document(PageSize.LETTER);
            try
            {
                // Creando objetos de escritura
                RtfWriter2.GetInstance(reportDocument, new FileStream(path, FileMode.Create));
                Color borderColor = Color.LIGHT_GRAY;

                // Declaracion de fuentes
                Font font1 = FontFactory.GetFont(BaseFont.HELVETICA_BOLD, 10, iTextSharp.text.Font.BOLD);
                Font font2 = FontFactory.GetFont(BaseFont.HELVETICA, 10, iTextSharp.text.Font.NORMAL);
                Font font3 = FontFactory.GetFont(BaseFont.HELVETICA, 8, iTextSharp.text.Font.NORMAL);
                Font font4 = FontFactory.GetFont(BaseFont.HELVETICA_BOLD, 8, iTextSharp.text.Font.BOLD);
                Font font5 = FontFactory.GetFont(BaseFont.HELVETICA_BOLD, 10, iTextSharp.text.Font.BOLD, Color.GRAY);

                // Margenes del documento
                reportDocument.SetMargins(40, 40, 100, 50);

                // Abriendo documento para escritura
                reportDocument.Open();

                Table table = new Table(2, 1) { BorderWidth = 0, BorderColor = borderColor };
                float[] headerwidths = new float[] { 300, 600 };
                table.Widths = headerwidths;
                table.WidthPercentage = 100;
                table.Padding = 1;
                Cell cell = new Cell();

                Paragraph paragraph = new Paragraph();
                paragraph = new Paragraph(documento.Fecha, font2) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph);
                reportDocument.Add(new Paragraph(" "));

                // Tabla 0
                Table table0 = new Table(2,4);
                int[] medidaCeldas0 = { 60, 40 };
                table0.Width = 100;
                table0.Locked = true;
                table0.SetWidths(medidaCeldas0);

                cell = new Cell(new Paragraph("Comisión Nacional Bancaria y de Valores", font1) { Alignment = Element.ALIGN_LEFT });
                cell.Border = 0;
                table0.AddCell(cell, new System.Drawing.Point(0, 0));

                cell = new Cell(new Paragraph("Vicepresidencia de Supervisión de Procesos Preventivos", font1) { Alignment = Element.ALIGN_LEFT });
                cell.Border = 0;
                table0.AddCell(cell, new System.Drawing.Point(1, 0));

                cell = new Cell(new Paragraph("Dirección General de Atención a Autoridades", font1) { Alignment = Element.ALIGN_LEFT });
                cell.Border = 0;
                table0.AddCell(cell, new System.Drawing.Point(2, 0));

                cell = new Cell(new Paragraph(documento.DirigidoDGA, font1) { Alignment = Element.ALIGN_LEFT });
                cell.Border = 0;
                table0.AddCell(cell, new System.Drawing.Point(3, 0));

                cell = new Cell(new Phrase("Acuse de recibo CNBV", font5));
                cell.Rowspan = 4;
                cell.HorizontalAlignment = 1;
                cell.VerticalAlignment = 1;
                table0.AddCell(cell, new System.Drawing.Point(0, 1));

                reportDocument.Add(table0);
                reportDocument.Add(new Paragraph(" "));

                // Dirigido a:
                paragraph = new Paragraph("Atención " + documento.DirigidoA, font1) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph);

                // Tabla 1
                Table table1 = new Table(3, 4);
                int[] medidaCeldas = { 6, 13, 40 };
                table1.Width = 100;
                table1.Locked = true;
                table1.SetWidths(medidaCeldas);

                Cell cel1 = new Cell(new Phrase("Asunto: ", font1));
                cel1.Rowspan = 4;

                table1.AddCell(cel1, 0, 0);
                table1.AddCell(new Phrase("Oficio:", font2), new System.Drawing.Point(0, 1));
                table1.AddCell(new Phrase((documento.Oficio != null && documento.Oficio.Trim().Equals("") != true) ? documento.Oficio : " ", font2), new System.Drawing.Point(0, 2));
                table1.AddCell(new Phrase("Expediente:", font2), new System.Drawing.Point(1, 1));
                table1.AddCell(new Phrase((documento.Expediente != null && documento.Expediente.Trim().Equals("") != true) ? documento.Expediente : " ", font2), new System.Drawing.Point(1, 2));
                table1.AddCell(new Phrase("Folio:", font2), new System.Drawing.Point(2, 1));
                table1.AddCell(new Phrase((documento.Folio != null && documento.Folio.Trim().Equals("") != true) ? documento.Folio : " ", font2), new System.Drawing.Point(2, 2));
                table1.AddCell(new Phrase("Autoridad solicitante:", font2), new System.Drawing.Point(3, 1));
                table1.AddCell(new Phrase((documento.AutoridadSolicitante != null && documento.AutoridadSolicitante.Trim().Equals("") != true) ? documento.AutoridadSolicitante : " ", font2), new System.Drawing.Point(3, 2));
                table1.Padding = 0f;
                table1.Cellpadding = 0f;
                table1.Cellspacing = 0f;
                reportDocument.Add(table1);
               

                // Tabla 2
                Table table2 = new Table(2);
                int[] medidaCeldas2 = { 130, 390 };
                table2.Width = 100;
                table2.Locked = true;
                table2.SetWidths(medidaCeldas2);
                table1.Padding = 0f;
                table1.Cellpadding = 0f;
                table1.Cellspacing = 0f;

                table2.AddCell(new Phrase("Tipo de respuesta:", font1));
                table2.AddCell(new Phrase(documento.RespuestaRequerimiento, font2));
                table2.AddCell(new Phrase("Tipo de asunto:", font1));
                table2.AddCell(new Phrase(documento.Asunto, font2));
                reportDocument.Add(table2);
                reportDocument.Add(new Paragraph(" "));

                // Parafo 3
                if (documento.Atencion != null && documento.Atencion.Trim().Equals("") != true)
                {
                    Paragraph paragraph3 = new Paragraph(documento.Atencion, font2) { Alignment = Element.ALIGN_LEFT };
                    reportDocument.Add(paragraph3);
                    //reportDocument.Add(new Paragraph(" "));
                }

                // Tabla 3 - Personas
                foreach (clsPersona persona in documento.ListPersonas)
                {
                    Table table3 = new Table(4);
                    int[] medidaCeldas3 = { 100, 250, 50, 130 };
                    table3.Width = 100;
                    table3.Locked = true;
                    table3.SetWidths(medidaCeldas3);

                    cell = new Cell(new Phrase("Nombre:", font1));
                    cell.BackgroundColor = new Color(166, 166, 166);
                    table3.AddCell(cell);

                    cell = new Cell(new Phrase(persona.Nombre.ToUpper(), font1));
                    cell.BackgroundColor = new Color(166, 166, 166);
                    table3.AddCell(cell);

                    cell = new Cell(new Phrase("RFC:", font1));
                    cell.BackgroundColor = new Color(166, 166, 166);
                    table3.AddCell(cell);

                    cell = new Cell(new Phrase(persona.Rfc.ToUpper(), font1));
                    cell.BackgroundColor = new Color(166, 166, 166);
                    table3.AddCell(cell);
                    reportDocument.Add(table3);

                    // Tabla 4 - Cuenta
                    foreach (clsCuenta cuenta in persona.CuentaList)
                    {
                        Table table4 = new Table(7);
                        int[] medidaCeldas4 = { 60, 60, 45, 60, 90, 60, 45};
                        table4.SetWidths(medidaCeldas4);
                        table4.Width = 100;
                        table4.Alignment = Element.ALIGN_CENTER;
                        table4.Locked = true;

                        cell = new Cell(new Phrase("No. Cuenta", font1));
                        cell.BackgroundColor = new Color(217, 217, 217);
                        cell.HorizontalAlignment = 1;
                        table4.AddCell(cell);

                        cell = new Cell(new Phrase("Tipo", font1));
                        cell.BackgroundColor = new Color(217, 217, 217);
                        cell.HorizontalAlignment = 1;
                        table4.AddCell(cell);

                        cell = new Cell(new Phrase("Estatus", font1));
                        cell.BackgroundColor = new Color(217, 217, 217);
                        cell.HorizontalAlignment = 1;
                        table4.AddCell(cell);

                        cell = new Cell(new Phrase("Carácter", font1));
                        cell.BackgroundColor = new Color(217, 217, 217);
                        cell.HorizontalAlignment = 1;
                        table4.AddCell(cell);

                        cell = new Cell(new Phrase("Ubicación/Sucursal", font1));
                        cell.BackgroundColor = new Color(217, 217, 217);
                        cell.HorizontalAlignment = 1;
                        table4.AddCell(cell);

                        cell = new Cell(new Phrase("Saldo", font1));
                        cell.BackgroundColor = new Color(217, 217, 217);
                        cell.HorizontalAlignment = 1;
                        table4.AddCell(cell);

                        cell = new Cell(new Phrase("Moneda", font1));
                        cell.BackgroundColor = new Color(217, 217, 217);
                        cell.HorizontalAlignment = 1;
                        table4.AddCell(cell);

                        cell = new Cell(new Phrase(cuenta.NoCuenta, font3));
                        cell.HorizontalAlignment = 1;
                        table4.AddCell(cell);
                        cell = new Cell(new Phrase(cuenta.Tipo, font3));
                        cell.HorizontalAlignment = 1;
                        table4.AddCell(cell);
                        cell = new Cell(new Phrase(cuenta.Estatus, font3));
                        cell.HorizontalAlignment = 1;
                        table4.AddCell(cell);
                        cell = new Cell(new Phrase(cuenta.Catacter, font3));
                        cell.HorizontalAlignment = 1;
                        table4.AddCell(cell);
                        cell = new Cell(new Phrase(cuenta.UbicacionSucursal, font3));
                        cell.HorizontalAlignment = 1;
                        table4.AddCell(cell);
                        cell = new Cell(new Phrase(cuenta.Saldo, font3));
                        cell.HorizontalAlignment = 1;
                        table4.AddCell(cell);
                        cell = new Cell(new Phrase(cuenta.Moneda, font3));
                        cell.HorizontalAlignment = 1;
                        table4.AddCell(cell);

                        cell = new Cell(new Phrase("Observaciones", font3));
                        cell.HorizontalAlignment = 1;
                        table4.AddCell(cell);
                        cell = new Cell(new Phrase(" " + cuenta.Observaciones, font3));
                        cell.HorizontalAlignment = 0;
                        cell.Colspan = 6;
                        table4.AddCell(cell);

                        reportDocument.Add(table4);
                        //reportDocument.Add(new Paragraph(" "));

                        // Tabla 5 - Documentacion
                        if (cuenta.Documentacion != null)
                        {
                            Table table5 = new Table(7);
                            int[] medidaCeldas5 = { 80, 37, 56, 26, 46, 26, 46};
                            table5.SetWidths(medidaCeldas5);
                            table5.Width = 100;
                            table5.Locked = true;

                            Cell cell5 = new Cell(new Phrase("Documentación que se proporciona (Cuenta: " + cuenta.NoCuenta + ")", font1));
                            cell5.Colspan = 7;
                            cell5.HorizontalAlignment = 0; //0=Left, 1=Centre, 2=Right
                            table5.AddCell(cell5);

                            table5.AddCell(new Phrase("Documento", font1));
                            table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" ");
                            table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" ");
                            
                            string tipoCopia = " ";
                            if (cuenta.Documentacion.EstadoCuenta)
                            {
                                table5.AddCell(new Phrase("Estados de cuenta", font3));
                                table5.AddCell(new Phrase(cuenta.Documentacion.EstadoCuentaApl, font4));
                                
                                string del = " ";
                                string al = " ";
                                if (cuenta.Documentacion.EstadoCuenta)
                                {
                                    if (cuenta.Documentacion.EstadoCuentaCs) { tipoCopia = "Copia simple"; }
                                    else if (cuenta.Documentacion.EstadoCuentaCc) { tipoCopia = "Copia certificada"; }

                                    del = cuenta.Documentacion.EstadoCuentaDesde.ToShortDateString();
                                    al = cuenta.Documentacion.EstadoCuentaHasta.ToShortDateString();
                                }
                                table5.AddCell(new Phrase(tipoCopia, font3));
                                table5.AddCell(new Phrase("Del:", font4)); table5.AddCell(new Phrase(del, font3));
                                table5.AddCell(new Phrase("Al:", font4)); table5.AddCell(new Phrase(al, font3));
                                cell = new Cell(new Phrase("Observaciones", font3));
                                cell.HorizontalAlignment = 0;
                                table5.AddCell(cell);
                                cell = new Cell(new Phrase(" " + cuenta.Documentacion.EstadoCuentaObs, font3));
                                cell.HorizontalAlignment = 0;
                                cell.Colspan = 6;
                                table5.AddCell(cell);
                            }

                            if (cuenta.Documentacion.IdentificacionOficial)
                            {
                                table5.AddCell(new Phrase("Identificación oficial", font3));
                                table5.AddCell(new Phrase(cuenta.Documentacion.IdentificacionOficialApl, font4));
                                //table5.AddCell(new Phrase(cuenta.Documentacion.IdentificacionOficial == true ? "X" : "", font4));
                                tipoCopia = " ";
                                if (cuenta.Documentacion.IdentificacionOficial)
                                {
                                    if (cuenta.Documentacion.IdentificacionOficialCs) { tipoCopia = "Copia simple"; }
                                    else if (cuenta.Documentacion.IdentificacionOficialCc) { tipoCopia = "Copia certificada"; }
                                }
                                table5.AddCell(new Phrase(tipoCopia, font3));
                                table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" ");
                                cell = new Cell(new Phrase("Observaciones", font3));
                                cell.HorizontalAlignment = 0;
                                table5.AddCell(cell);
                                cell = new Cell(new Phrase(" " + cuenta.Documentacion.IdentificacionOficialObs, font3));
                                cell.HorizontalAlignment = 0;
                                cell.Colspan = 6;
                                table5.AddCell(cell);
                            }

                            if (cuenta.Documentacion.ContratoApertura)
                            {
                                table5.AddCell(new Phrase("Contrato de apertura", font3));
                                table5.AddCell(new Phrase(cuenta.Documentacion.ContratoAperturaApl, font4));
                                //table5.AddCell(new Phrase(cuenta.Documentacion.ContratoApertura == true ? "X" : "", font4));
                                tipoCopia = " ";
                                if (cuenta.Documentacion.ContratoApertura)
                                {
                                    if (cuenta.Documentacion.ContratoAperturaCs) { tipoCopia = "Copia simple"; }
                                    else if (cuenta.Documentacion.ContratoAperturaCc) { tipoCopia = "Copia certificada"; }
                                }
                                table5.AddCell(new Phrase(tipoCopia, font3));
                                table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" ");
                                cell = new Cell(new Phrase("Observaciones", font3));
                                cell.HorizontalAlignment = 0;
                                table5.AddCell(cell);
                                cell = new Cell(new Phrase(" " + cuenta.Documentacion.ContratoAperturaObs, font3));
                                cell.HorizontalAlignment = 0;
                                cell.Colspan = 6;
                                table5.AddCell(cell);
                            }

                            if (cuenta.Documentacion.PoderNotarial)
                            {
                                table5.AddCell(new Phrase("Poder notarial", font3));
                                table5.AddCell(new Phrase(cuenta.Documentacion.PoderNotarialApl, font4));
                                //table5.AddCell(new Phrase(cuenta.Documentacion.PoderNotarial == true ? "X" : "", font4));
                                tipoCopia = " ";
                                if (cuenta.Documentacion.PoderNotarial)
                                {
                                    if (cuenta.Documentacion.PoderNotarialCs) { tipoCopia = "Copia simple"; }
                                    else if (cuenta.Documentacion.PoderNotarialCc) { tipoCopia = "Copia certificada"; }
                                }
                                table5.AddCell(new Phrase(tipoCopia, font3));
                                table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" ");
                                cell = new Cell(new Phrase("Observaciones", font3));
                                cell.HorizontalAlignment = 0;
                                table5.AddCell(cell);
                                cell = new Cell(new Phrase(" " + cuenta.Documentacion.PoderNotarialObs, font3));
                                cell.HorizontalAlignment = 0;
                                cell.Colspan = 6;
                                table5.AddCell(cell);
                            }

                            if (cuenta.Documentacion.ComprobanteDomicilio)
                            {
                                table5.AddCell(new Phrase("Comprobante de domicilio", font3));
                                table5.AddCell(new Phrase(cuenta.Documentacion.ComprobanteDomicilioApl, font4));
                                //table5.AddCell(new Phrase(cuenta.Documentacion.ComprobanteDomicilio == true ? "X" : "", font4));
                                tipoCopia = " ";
                                if (cuenta.Documentacion.ComprobanteDomicilio)
                                {
                                    if (cuenta.Documentacion.ComprobanteDomicilioCs) { tipoCopia = "Copia simple"; }
                                    else if (cuenta.Documentacion.ComprobanteDomicilioCc) { tipoCopia = "Copia certificada"; }
                                }
                                table5.AddCell(new Phrase(tipoCopia, font3));
                                table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" ");
                                cell = new Cell(new Phrase("Observaciones", font3));
                                cell.HorizontalAlignment = 0;
                                table5.AddCell(cell);
                                cell = new Cell(new Phrase(" " + cuenta.Documentacion.ComprobanteDomicilioObs, font3));
                                cell.HorizontalAlignment = 0;
                                cell.Colspan = 6;
                                table5.AddCell(cell);
                            }

                            if (cuenta.Documentacion.TarjetaFirmas)
                            {
                                table5.AddCell(new Phrase("Tarjeta de firmas", font3));
                                table5.AddCell(new Phrase(cuenta.Documentacion.TarjetaFirmasApl, font4));
                                // table5.AddCell(new Phrase(cuenta.Documentacion.TarjetaFirmas == true ? "X" : "", font4));
                                tipoCopia = " ";
                                if (cuenta.Documentacion.TarjetaFirmas)
                                {
                                    if (cuenta.Documentacion.TarjetaFirmasCs) { tipoCopia = "Copia simple"; }
                                    else if (cuenta.Documentacion.TarjetaFirmasCc) { tipoCopia = "Copia certificada"; }
                                }
                                table5.AddCell(new Phrase(tipoCopia, font3));
                                table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" ");
                                cell = new Cell(new Phrase("Observaciones", font3));
                                cell.HorizontalAlignment = 0;
                                table5.AddCell(cell);
                                cell = new Cell(new Phrase(" " + cuenta.Documentacion.TarjetaFirmasObs, font3));
                                cell.HorizontalAlignment = 0;
                                cell.Colspan = 6;
                                table5.AddCell(cell);
                            }

                            reportDocument.Add(table5);
                            //reportDocument.Add(new Paragraph(" "));
                        }

                        // Tabla 6 - Documentacion de operaciones
                        if (cuenta.Operaciones != null)
                        {
                            Table table6 = new Table(3);
                            int[] medidaCeldas6 = { 80, 37, 200 };
                            table6.SetWidths(medidaCeldas6);
                            table6.Width = 100;
                            table6.Locked = true;

                            Cell cell6 = new Cell(new Phrase("Documentación de operaciones (Cuenta: " + cuenta.NoCuenta + ")", font1));
                            cell6.Colspan = 3;
                            cell6.HorizontalAlignment = 0; //0=Left, 1=Centre, 2=Right
                            table6.AddCell(cell6);

                            table6.AddCell(new Phrase("Documento", font1));
                            table6.AddCell(" "); table6.AddCell(" ");

                            string tipoCopia = " ";
                            if (cuenta.Operaciones.Cheques)
                            {
                                table6.AddCell(new Phrase("Cheques", font3));
                                table6.AddCell(new Phrase(cuenta.Operaciones.ChequesApl, font4));
                                if (cuenta.Operaciones.Cheques)
                                {
                                    if (cuenta.Operaciones.ChequesCs) { tipoCopia = "Copia simple"; }
                                    else if (cuenta.Operaciones.ChequesCc) { tipoCopia = "Copia certificada"; }
                                }
                                table6.AddCell(new Phrase(tipoCopia, font3));
                                cell = new Cell(new Phrase("Observaciones", font3));
                                cell.HorizontalAlignment = 0;
                                table6.AddCell(cell);
                                cell = new Cell(new Phrase(" " + cuenta.Operaciones.ChequesObs, font3));
                                cell.HorizontalAlignment = 0;
                                cell.Colspan = 2;
                                table6.AddCell(cell);
                            }

                            if (cuenta.Operaciones.FichaDeposito)
                            {
                                table6.AddCell(new Phrase("Fichas de depósito", font3));
                                table6.AddCell(new Phrase(cuenta.Operaciones.FichaDepositoApl, font4));
                                tipoCopia = " ";
                                if (cuenta.Operaciones.FichaDeposito)
                                {
                                    if (cuenta.Operaciones.FichaDepositoCs) { tipoCopia = "Copia simple"; }
                                    else if (cuenta.Operaciones.FichaDepositoCc) { tipoCopia = "Copia certificada"; }
                                }
                                table6.AddCell(new Phrase(tipoCopia, font3));
                                cell = new Cell(new Phrase("Observaciones", font3));
                                cell.HorizontalAlignment = 0;
                                table6.AddCell(cell);
                                cell = new Cell(new Phrase(" " + cuenta.Operaciones.FichaDepositoObs, font3));
                                cell.HorizontalAlignment = 0;
                                cell.Colspan = 2;
                                table6.AddCell(cell);
                            }

                            if (cuenta.Operaciones.FichaRetiro)
                            {
                                table6.AddCell(new Phrase("Fichas de retiro", font3));
                                table6.AddCell(new Phrase(cuenta.Operaciones.FichaRetiroApl, font4));
                                tipoCopia = " ";
                                if (cuenta.Operaciones.FichaRetiro)
                                {
                                    if (cuenta.Operaciones.FichaRetiroCs) { tipoCopia = "Copia simple"; }
                                    else if (cuenta.Operaciones.FichaRetiroCc) { tipoCopia = "Copia certificada"; }
                                }
                                table6.AddCell(new Phrase(tipoCopia, font3));
                                cell = new Cell(new Phrase("Observaciones", font3));
                                cell.HorizontalAlignment = 0;
                                table6.AddCell(cell);
                                cell = new Cell(new Phrase(" " + cuenta.Operaciones.FichaRetiroObs, font3));
                                cell.HorizontalAlignment = 0;
                                cell.Colspan = 2;
                                table6.AddCell(cell);
                            }

                            if (cuenta.Operaciones.Comprobantes)
                            {
                                table6.AddCell(new Phrase("Comprobantes", font3));
                                table6.AddCell(new Phrase(cuenta.Operaciones.ComprobantesApl, font4));
                                tipoCopia = " ";
                                if (cuenta.Operaciones.Comprobantes)
                                {
                                    if (cuenta.Operaciones.ComprobantesCs) { tipoCopia = "Copia simple"; }
                                    else if (cuenta.Operaciones.ComprobantesCc) { tipoCopia = "Copia certificada"; }
                                }
                                table6.AddCell(new Phrase(tipoCopia, font3));
                                cell = new Cell(new Phrase("Observaciones", font3));
                                cell.HorizontalAlignment = 0;
                                table6.AddCell(cell);
                                cell = new Cell(new Phrase(" " + cuenta.Operaciones.ComprobantesObs, font3));
                                cell.HorizontalAlignment = 0;
                                cell.Colspan = 2;
                                table6.AddCell(cell);
                            }

                            if (cuenta.Operaciones.Otros)
                            {
                                table6.AddCell(new Phrase("Otro (especificar): " + cuenta.Operaciones.OtrosEspecifica, font3));
                                table6.AddCell(new Phrase(cuenta.Operaciones.OtrosApl, font4));
                                tipoCopia = " ";
                                if (cuenta.Operaciones.Otros)
                                {
                                    if (cuenta.Operaciones.OtrosCs) { tipoCopia = "Copia simple"; }
                                    else if (cuenta.Operaciones.OtrosCc) { tipoCopia = "Copia certificada"; }
                                }
                                table6.AddCell(new Phrase(tipoCopia, font3));
                                cell = new Cell(new Phrase("Observaciones", font3));
                                cell.HorizontalAlignment = 0;
                                table6.AddCell(cell);
                                cell = new Cell(new Phrase(" " + cuenta.Operaciones.OtrosObs, font3));
                                cell.HorizontalAlignment = 0;
                                cell.Colspan = 2;
                                table6.AddCell(cell);
                            }

                            reportDocument.Add(table6);
                            reportDocument.Add(new Paragraph(" "));

                            if (cuenta.Operaciones.InfSolicitada != false || cuenta.Operaciones.InfSolicitadaExc != false ||
                                cuenta.Operaciones.InfSolicitadaForPar != false || cuenta.Operaciones.InfSolicitadaAnex != false)
                            {
                                string informacionSolicitada = "";
                                if (cuenta.Operaciones.InfSolicitada)
                                    informacionSolicitada = "Se proporciona toda la documentacion solicitada por la autoridad.";
                                else if (cuenta.Operaciones.InfSolicitadaExc)
                                    informacionSolicitada = "Se proporciona la documentación solicitada por la autoridad excepto " + 
                                        "lo señalado en el/los anexo(s): " + cuenta.Operaciones.InfSolicitadaAnexo;
                                else if (cuenta.Operaciones.InfSolicitadaForPar)
                                    informacionSolicitada = "Se proporciona la documentación de forma parcial según lo " +
                                                            "señalado en el/los anexo(s): " + cuenta.Operaciones.InfSolicitadaAnexo;
                                else if (cuenta.Operaciones.InfSolicitadaAnex)
                                    informacionSolicitada = "Se entrega última parcialidad según lo señalado en el/los anexo(s): " + cuenta.Operaciones.InfSolicitadaAnexo;
                                Paragraph paragraph4 = new Paragraph(informacionSolicitada, font2) { Alignment = Element.ALIGN_LEFT };
                                reportDocument.Add(paragraph4);
                            }
                        }

                        // Tabla 7 - Informacíon de movimientos electronicos
                        if (cuenta.MovimientosElectronicos != null)
                        {
                            Table table7 = new Table(2);
                            int[] medidaCeldas7 = { 80, 237 };
                            table7.SetWidths(medidaCeldas7);
                            table7.Width = 100;
                            table7.Locked = true;

                            Cell cell7 = new Cell(new Phrase("Información de movimientos electrónicos (Cuenta: " + cuenta.NoCuenta + ")", font1));
                            cell7.Colspan = 2;
                            cell7.HorizontalAlignment = 0; //0=Left, 1=Centre, 2=Right
                            table7.AddCell(cell7);

                            table7.AddCell(new Phrase("Documento", font1));
                            table7.AddCell(" ");

                            if (cuenta.MovimientosElectronicos.MovimientosElectronicos)
                            {
                                table7.AddCell(new Phrase("Movimientos electrónicos", font3));
                                table7.AddCell(new Phrase(cuenta.MovimientosElectronicos.MovimientosElectronicosApl, font4));
                                cell = new Cell(new Phrase("Observaciones", font3));
                                cell.HorizontalAlignment = 0;
                                table7.AddCell(cell);
                                cell = new Cell(new Phrase(" " + cuenta.MovimientosElectronicos.MovimientosElectronicosObs, font3));
                                cell.HorizontalAlignment = 0;
                                table7.AddCell(cell);
                            }

                            if (cuenta.MovimientosElectronicos.DispersionNomina)
                            {
                                table7.AddCell(new Phrase("Dispersión de nómina", font3));
                                table7.AddCell(new Phrase(cuenta.MovimientosElectronicos.DispersionNominaApl, font4));
                                cell = new Cell(new Phrase("Observaciones", font3));
                                cell.HorizontalAlignment = 0;
                                table7.AddCell(cell);
                                cell = new Cell(new Phrase(" " + cuenta.MovimientosElectronicos.DispersionNominaObs, font3));
                                cell.HorizontalAlignment = 0;
                                table7.AddCell(cell);
                            }

                            reportDocument.Add(table7);
                            reportDocument.Add(new Paragraph(" "));

                            if (cuenta.MovimientosElectronicos.MovEInfSolicitada != false || cuenta.MovimientosElectronicos.MovEInfSolicitadaExc != false)
                            {
                                string informacionSOlicitadaME = "";
                                if (cuenta.MovimientosElectronicos.MovEInfSolicitada)
                                    informacionSOlicitadaME = "Se proporciona toda la información solicitada por la autoridad.";
                                else if (cuenta.MovimientosElectronicos.MovEInfSolicitadaExc)
                                    informacionSOlicitadaME = "Se proporciona la información solicitada por la autoridad según " 
                                + "lo señalado en el/los anexo(s): " + cuenta.MovimientosElectronicos.MovEAnexo;
                                Paragraph paragraph5 = new Paragraph(informacionSOlicitadaME, font2) { Alignment = Element.ALIGN_LEFT };
                                reportDocument.Add(paragraph5);
                            }
                        }
                    }
                }

                // Tabla 8 - Otras operaciones / observaciones
                if (documento.Observaciones != null && documento.Observaciones != "")
                {
                    Table table8 = new Table(1);
                    table8.Width = 100;
                    table8.Locked = true;

                    table8.AddCell(new Phrase("Otras operaciones/observaciones", font1));
                    table8.AddCell(new Phrase(documento.Observaciones, font2));
                    reportDocument.Add(table8);
                    reportDocument.Add(new Paragraph(" "));
                    //reportDocument.Add(new Paragraph(" "));
                }

                reportDocument.Add(new Paragraph(" "));
                reportDocument.Add(new Paragraph(" "));
                reportDocument.Add(new Paragraph(" "));
                reportDocument.Add(new Paragraph(" "));

                reportDocument.Add(new Paragraph("______________________________________", font2) { Alignment = Element.ALIGN_CENTER });
                reportDocument.Add(new Paragraph(documento.Firmante, font2) { Alignment = Element.ALIGN_CENTER });
                reportDocument.Add(new Paragraph(documento.Puesto, font2) { Alignment = Element.ALIGN_CENTER });
                reportDocument.Add(new Paragraph(documento.ControlInterno, font2) { Alignment = Element.ALIGN_LEFT });

            }
            catch (IOException e)
            {
                Logs.LogFile(e.Message, e.ToString(), e.StackTrace);
                reportDocument.Close();
                throw new Exception("El documento está siendo utilizado por otra aplicación.");
            }
            catch (Exception e)
            {
                Logs.LogFile(e.Message, e.ToString(), e.StackTrace);
                reportDocument.Close();
                throw new Exception("Ha ocurrido un error inesperado al generar el documento.");
            }
            finally
            {
                reportDocument.Close();
            }
        }
        public static void CrearDocumentoRespuestaNegativa(clsDocumento documento, string path)
        {
            // Conformando documento
            Document reportDocument = new Document(PageSize.LETTER);
            try
            {
                // Creando objetos de escritura
                RtfWriter2.GetInstance(reportDocument, new FileStream(path, FileMode.Create));
                Color borderColor = Color.LIGHT_GRAY;

                // Declaracion de fuentes
                Font font1 = FontFactory.GetFont(BaseFont.HELVETICA_BOLD, 10, iTextSharp.text.Font.BOLD);
                Font font2 = FontFactory.GetFont(BaseFont.HELVETICA, 10, iTextSharp.text.Font.NORMAL);
                Font font3 = FontFactory.GetFont(BaseFont.HELVETICA, 8, iTextSharp.text.Font.NORMAL);
                Font font4 = FontFactory.GetFont(BaseFont.HELVETICA_BOLD, 8, iTextSharp.text.Font.BOLD);
                Font font5 = FontFactory.GetFont(BaseFont.HELVETICA_BOLD, 8, iTextSharp.text.Font.BOLD, Color.GRAY);

                // Margenes del documento
                reportDocument.SetMargins(40, 40, 100, 50);

                // Abriendo documento para escritura
                reportDocument.Open();

                Table table = new Table(2, 1) { BorderWidth = 0, BorderColor = borderColor };
                float[] headerwidths = new float[] { 300, 600 };
                table.Widths = headerwidths;
                table.WidthPercentage = 100;
                table.Padding = 1;

                Paragraph paragraph = new Paragraph();
                paragraph = new Paragraph(documento.Fecha, font2) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph);
                reportDocument.Add(new Paragraph(" "));

                // Tabla 0
                Table table0 = new Table(2, 4);
                int[] medidaCeldas0 = { 60, 40 };
                table0.Width = 100;
                table0.Locked = true;
                table0.SetWidths(medidaCeldas0);

                Cell cell = new Cell(new Paragraph("Comisión Nacional Bancaria y de Valores", font1) { Alignment = Element.ALIGN_LEFT });
                cell.Border = 0;
                table0.AddCell(cell, new System.Drawing.Point(0, 0));

                cell = new Cell(new Paragraph("Vicepresidencia de Supervisión de Procesos Preventivos", font1) { Alignment = Element.ALIGN_LEFT });
                cell.Border = 0;
                table0.AddCell(cell, new System.Drawing.Point(1, 0));

                cell = new Cell(new Paragraph("Dirección General de Atención a Autoridades", font1) { Alignment = Element.ALIGN_LEFT });
                cell.Border = 0;
                table0.AddCell(cell, new System.Drawing.Point(2, 0));

                cell = new Cell(new Paragraph(documento.DirigidoDGA, font1) { Alignment = Element.ALIGN_LEFT });
                cell.Border = 0;
                table0.AddCell(cell, new System.Drawing.Point(3, 0));

                cell = new Cell(new Phrase("Acuse de recibo CNBV", font5));
                cell.Rowspan = 4;
                cell.HorizontalAlignment = 1;
                cell.VerticalAlignment = 1;
                table0.AddCell(cell, new System.Drawing.Point(0, 1));

                reportDocument.Add(table0);
                reportDocument.Add(new Paragraph(" "));

                // Dirigido a:
                paragraph = new Paragraph("Atención " + documento.DirigidoA, font1) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph);

                // Tabla 1
                Table table1 = new Table(3, 4);
                int[] medidaCeldas = { 30, 30, 40 };
                table1.Width = 100;
                table1.Locked = true;
                table1.SetWidths(medidaCeldas);

                Cell cel1 = new Cell(new Phrase("Asunto: ", font1));
                cel1.Rowspan = 4;

                table1.AddCell(cel1, 0, 0);
                table1.AddCell(new Phrase("Oficio:", font2), new System.Drawing.Point(0, 1));
                table1.AddCell(new Phrase((documento.Oficio != null && documento.Oficio.Trim().Equals("") != true) ? documento.Oficio : " ", font2), new System.Drawing.Point(0, 2));
                table1.AddCell(new Phrase("Expediente:", font2), new System.Drawing.Point(1, 1));
                table1.AddCell(new Phrase((documento.Expediente != null && documento.Expediente.Trim().Equals("") != true) ? documento.Expediente : " ", font2), new System.Drawing.Point(1, 2));
                table1.AddCell(new Phrase("Folio:", font2), new System.Drawing.Point(2, 1));
                table1.AddCell(new Phrase((documento.Folio != null && documento.Folio.Trim().Equals("") != true) ? documento.Folio : " ", font2), new System.Drawing.Point(2, 2));
                table1.AddCell(new Phrase("Autoridad solicitante:", font2), new System.Drawing.Point(3, 1));
                table1.AddCell(new Phrase((documento.AutoridadSolicitante != null && documento.AutoridadSolicitante.Trim().Equals("") != true) ? documento.AutoridadSolicitante : " ", font2), new System.Drawing.Point(3, 2));
                table1.Padding = 0f;
                table1.Cellpadding = 0f;
                table1.Cellspacing = 0f;
                reportDocument.Add(table1);
                reportDocument.Add(new Paragraph(" "));


                // Tabla 2
                Table table2 = new Table(2);
                int[] medidaCeldas2 = { 130, 390 };
                table2.Width = 100;
                table2.Locked = true;
                table2.SetWidths(medidaCeldas2);

                table2.AddCell(new Phrase("Tipo de respuesta:", font1));
                table2.AddCell(new Phrase(documento.RespuestaRequerimiento, font2));
                table2.AddCell(new Phrase("Tipo de asunto:", font1));
                table2.AddCell(new Phrase(documento.Asunto, font2));
                reportDocument.Add(table2);
                reportDocument.Add(new Paragraph(" "));

                // Tabla 3
                Table table8 = new Table(1);
                table8.Width = 100;
                table8.Locked = true;

                table8.AddCell(new Phrase("Observaciones", font1));
                table8.AddCell(new Phrase(documento.Observaciones, font2));
                reportDocument.Add(table8);
                reportDocument.Add(new Paragraph(" "));
                
                //Paragraph paragraph3 = new Paragraph(documento.Observaciones, font2) { Alignment = Element.ALIGN_LEFT };
                //reportDocument.Add(paragraph3);
                reportDocument.Add(new Paragraph(" "));

                reportDocument.Add(new Paragraph(" "));
                reportDocument.Add(new Paragraph(" "));
                reportDocument.Add(new Paragraph(" "));
                reportDocument.Add(new Paragraph(" "));

                reportDocument.Add(new Paragraph("______________________________________", font2) { Alignment = Element.ALIGN_CENTER });
                reportDocument.Add(new Paragraph(documento.Firmante, font2) { Alignment = Element.ALIGN_CENTER });
                reportDocument.Add(new Paragraph(documento.Puesto, font2) { Alignment = Element.ALIGN_CENTER });
                reportDocument.Add(new Paragraph(documento.ControlInterno, font2) { Alignment = Element.ALIGN_LEFT });

            }
            catch (IOException e)
            {
                Logs.LogFile(e.Message, e.ToString(), e.StackTrace);
                reportDocument.Close();
                throw new Exception("El documento está siendo utilizado por otra aplicación.");
            }
            catch (Exception e)
            {
                Logs.LogFile(e.Message, e.ToString(), e.StackTrace);
                reportDocument.Close();
                throw new Exception("Ha ocurrido un error inesperado al generar el documento.");
            }
            finally
            {
                reportDocument.Close();
            }
        }
        public static void CrearDocumentoRespuestaAmparo(clsDocumento documento, string path)
        {
            // Conformando documento
            Document reportDocument = new Document(PageSize.LETTER);
            try
            {
                // Creando objetos de escritura
                RtfWriter2.GetInstance(reportDocument, new FileStream(path, FileMode.Create));
                Color borderColor = Color.LIGHT_GRAY;

                // Declaracion de fuentes
                Font font1 = FontFactory.GetFont(BaseFont.HELVETICA_BOLD, 10, iTextSharp.text.Font.BOLD);
                Font font2 = FontFactory.GetFont(BaseFont.HELVETICA, 10, iTextSharp.text.Font.NORMAL);
                Font font3 = FontFactory.GetFont(BaseFont.HELVETICA, 8, iTextSharp.text.Font.NORMAL);
                Font font4 = FontFactory.GetFont(BaseFont.HELVETICA_BOLD, 8, iTextSharp.text.Font.BOLD);
                Font font5 = FontFactory.GetFont(BaseFont.HELVETICA_BOLD, 8, iTextSharp.text.Font.BOLD, Color.GRAY);

                // Margenes del documento
                reportDocument.SetMargins(40, 40, 100, 50);

                // Abriendo documento para escritura
                reportDocument.Open();

                Table table = new Table(2, 1) { BorderWidth = 0, BorderColor = borderColor };
                float[] headerwidths = new float[] { 300, 600 };
                table.Widths = headerwidths;
                table.WidthPercentage = 100;
                table.Padding = 1;

                Paragraph paragraph = new Paragraph();
                paragraph = new Paragraph(documento.Fecha, font2) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph);
                reportDocument.Add(new Paragraph(" "));

                // Tabla 0
                Table table0 = new Table(2, 4);
                int[] medidaCeldas0 = { 60, 40 };
                table0.Width = 100;
                table0.Locked = true;
                table0.SetWidths(medidaCeldas0);

                Cell cell = new Cell(new Paragraph("Comisión Nacional Bancaria y de Valores", font1) { Alignment = Element.ALIGN_LEFT });
                cell.Border = 0;
                table0.AddCell(cell, new System.Drawing.Point(0, 0));

                cell = new Cell(new Paragraph("Vicepresidencia de Supervisión de Procesos Preventivos", font1) { Alignment = Element.ALIGN_LEFT });
                cell.Border = 0;
                table0.AddCell(cell, new System.Drawing.Point(1, 0));

                cell = new Cell(new Paragraph("Dirección General de Atención a Autoridades", font1) { Alignment = Element.ALIGN_LEFT });
                cell.Border = 0;
                table0.AddCell(cell, new System.Drawing.Point(2, 0));

                cell = new Cell(new Paragraph(documento.DirigidoDGA, font1) { Alignment = Element.ALIGN_LEFT });
                cell.Border = 0;
                table0.AddCell(cell, new System.Drawing.Point(3, 0));

                cell = new Cell(new Phrase("Acuse de recibo CNBV", font5));
                cell.Rowspan = 4;
                cell.HorizontalAlignment = 1;
                cell.VerticalAlignment = 1;
                table0.AddCell(cell, new System.Drawing.Point(0, 1));

                reportDocument.Add(table0);
                reportDocument.Add(new Paragraph(" "));

                // Dirigido a:
                paragraph = new Paragraph("Atención " + documento.DirigidoA, font1) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph);

                // Tabla 1
                Table table1 = new Table(3, 4);
                int[] medidaCeldas = { 30, 30, 40 };
                table1.Width = 100;
                table1.Locked = true;
                table1.SetWidths(medidaCeldas);

                Cell cel1 = new Cell(new Phrase("Asunto: ", font1));
                cel1.Rowspan = 4;

                table1.AddCell(cel1, 0, 0);
                table1.AddCell(new Phrase("Oficio:", font2), new System.Drawing.Point(0, 1));
                table1.AddCell(new Phrase((documento.Oficio != null && documento.Oficio.Trim().Equals("") != true) ? documento.Oficio : " ", font2), new System.Drawing.Point(0, 2));
                table1.AddCell(new Phrase("Expediente:", font2), new System.Drawing.Point(1, 1));
                table1.AddCell(new Phrase((documento.Expediente != null && documento.Expediente.Trim().Equals("") != true) ? documento.Expediente : " ", font2), new System.Drawing.Point(1, 2));
                table1.AddCell(new Phrase("Folio:", font2), new System.Drawing.Point(2, 1));
                table1.AddCell(new Phrase((documento.Folio != null && documento.Folio.Trim().Equals("") != true) ? documento.Folio : " ", font2), new System.Drawing.Point(2, 2));
                table1.AddCell(new Phrase("Autoridad solicitante:", font2), new System.Drawing.Point(3, 1));
                table1.AddCell(new Phrase((documento.AutoridadSolicitante != null && documento.AutoridadSolicitante.Trim().Equals("") != true) ? documento.AutoridadSolicitante : " ", font2), new System.Drawing.Point(3, 2));
                table1.Padding = 0f;
                table1.Cellpadding = 0f;
                table1.Cellspacing = 0f;
                reportDocument.Add(table1);
                reportDocument.Add(new Paragraph(" "));
                                     
                // Tabla 3
                Table table8 = new Table(1);
                table8.Width = 100;
                table8.Locked = true;

                table8.AddCell(new Phrase("Observaciones", font1));
                table8.AddCell(new Phrase(documento.Observaciones, font2));
                reportDocument.Add(table8);
                reportDocument.Add(new Paragraph(" "));

                //Paragraph paragraph3 = new Paragraph(documento.Observaciones, font2) { Alignment = Element.ALIGN_LEFT };
                //reportDocument.Add(paragraph3);
                //reportDocument.Add(new Paragraph(" "));

                reportDocument.Add(new Paragraph(" "));
                reportDocument.Add(new Paragraph(" "));
                reportDocument.Add(new Paragraph(" "));
                reportDocument.Add(new Paragraph(" "));

                reportDocument.Add(new Paragraph("______________________________________", font2) { Alignment = Element.ALIGN_CENTER });
                reportDocument.Add(new Paragraph(documento.Firmante, font2) { Alignment = Element.ALIGN_CENTER });
                reportDocument.Add(new Paragraph(documento.Puesto, font2) { Alignment = Element.ALIGN_CENTER });
                reportDocument.Add(new Paragraph(documento.ControlInterno, font2) { Alignment = Element.ALIGN_LEFT });

            }
            catch (IOException e)
            {
                Logs.LogFile(e.Message, e.ToString(), e.StackTrace);
                reportDocument.Close();
                throw new Exception("El documento está siendo utilizado por otra aplicación.");
            }
            catch (Exception e)
            {
                Logs.LogFile(e.Message, e.ToString(), e.StackTrace);
                reportDocument.Close();
                throw new Exception("Ha ocurrido un error inesperado al generar el documento.");
            }
            finally
            {
                reportDocument.Close();
            }
        }
    }
}
