﻿using System;
using System.Collections.Generic;
using System.Text;
using iTextSharp.text;
using iTextSharp.text.rtf;
using iTextSharp.text.pdf;
using System.Globalization;
using System.IO;
using System.Reflection;

using document_management.entidades;

namespace document_management.controller
{
    public class DocumentGeneratorPdf
    {
        /// <Generacion de reporte - Respuesta positiva>
        /// 
        /// </Generacion de reporte - Respuesta positiva>
        /// <param name="documento">Datos para generar el documento</param>
        /// <param name="path">Ruta donde se escribira el documento</param>
        public static void CrearDocumentoRespuestaPositiva(clsDocumento documento, string path)
        {
            // Conformando documento
            Document reportDocument = new Document(PageSize.LETTER);
            try
            {
                // Creando objetos de escritura
                PdfWriter.GetInstance(reportDocument, new FileStream(path, FileMode.Create));
                Color borderColor = Color.LIGHT_GRAY;
                
                // Declaracion de funetes
                const string fontType = "Arial";
                Font font1 = FontFactory.GetFont(fontType, 10, iTextSharp.text.Font.BOLD);
                Font font2 = FontFactory.GetFont(fontType, 10, iTextSharp.text.Font.NORMAL);
                Font font3 = FontFactory.GetFont(fontType, 8, iTextSharp.text.Font.NORMAL);
                Font font4 = FontFactory.GetFont(fontType, 8, iTextSharp.text.Font.BOLD);
                Font font5 = FontFactory.GetFont(BaseFont.HELVETICA_BOLD, 8, iTextSharp.text.Font.BOLD, Color.GRAY);

                // Margenes del documento
                reportDocument.SetMargins(40, 40, 100, 50);
                                
                // Abriendo documento para escritura
                reportDocument.Open();


                Table table = new Table(2, 1) { BorderWidth = 0, BorderColor = borderColor };
                float[] headerwidths = new float[] { 300, 600 };
                table.Widths = headerwidths;
                table.WidthPercentage = 100;
                table.Padding = 1;
                PdfPCell cell = new PdfPCell();

                Paragraph paragraph = new Paragraph();
                paragraph = new Paragraph(documento.Fecha, font2) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph);
                reportDocument.Add(new Paragraph(" "));
                reportDocument.Add(new Paragraph(" "));

                // Tabla 0
                PdfPTable table0 = new PdfPTable(2);
                float[] medidaCeldas0 = { 300f, 230f};
                table0.TotalWidth = 530f;
                table0.LockedWidth = true;
                table0.SetWidths(medidaCeldas0);
                              

                PdfPTable nested0 = new PdfPTable(1);
                cell = new PdfPCell(new Paragraph("Comisión Nacional Bancaria y de Valores", font1) { Alignment = Element.ALIGN_LEFT });
                cell.Border = 0;
                nested0.AddCell(cell);
                cell = new PdfPCell(new Paragraph("Vicepresidencia de Supervisión de Procesos Preventivos", font1) { Alignment = Element.ALIGN_LEFT });
                cell.Border = 0;
                nested0.AddCell(cell);
                cell = new PdfPCell(new Paragraph("Dirección General de Atención a Autoridades", font1) { Alignment = Element.ALIGN_LEFT });
                cell.Border = 0;
                nested0.AddCell(cell);
                // cell = new PdfPCell(new Paragraph("Dirección General Adjunta de Atención a Autoridades " + documento.DirigidoDGA, font1) { Alignment = Element.ALIGN_LEFT });
                cell = new PdfPCell(new Paragraph("", font1) { Alignment = Element.ALIGN_LEFT });
                cell.Border = 0;
                nested0.AddCell(cell);
                PdfPCell nesthousing0 = new PdfPCell(nested0);
                nesthousing0.Padding = 0f;
                nesthousing0.Border = 0;
                table0.AddCell(nesthousing0);

                PdfPCell cel0 = new PdfPCell(new Phrase("Acuse de recibo CNBV", font5));
                cel0.HorizontalAlignment = 1;
                cel0.VerticalAlignment = 1;
                table0.AddCell(cel0);

                reportDocument.Add(table0);
                reportDocument.Add(new Paragraph(" "));

                //paragraph = new Paragraph("Comisión Nacional Bancaria y de Valores", font1) { Alignment = Element.ALIGN_LEFT };
                //reportDocument.Add(paragraph);
                //paragraph = new Paragraph("Vicepresidencia de Supervisión de Procesos Preventivos", font1) { Alignment = Element.ALIGN_LEFT };
                //reportDocument.Add(paragraph);
                //paragraph = new Paragraph("Dirección General de Atención a Autoridades", font1) { Alignment = Element.ALIGN_LEFT };
                //reportDocument.Add(paragraph);
                //paragraph = new Paragraph("Dirección General Adjunta de Atención a Autoridades " + documento.DirigidoDGA, font1) { Alignment = Element.ALIGN_LEFT };
                //reportDocument.Add(paragraph);
                //reportDocument.Add(new Paragraph(" "));

                // Dirigido a:
                string dirigidoA = "Lic. Luz María Villafuerte García";
                paragraph = new Paragraph("Atención " + dirigidoA, font2) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph);
                reportDocument.Add(new Paragraph(" "));

                            
                // Tabla 1
                PdfPTable table1 = new PdfPTable(3);
                float[] medidaCeldas = { 40f, 80f, 250f };
                table1.TotalWidth = 530f; 
                table1.LockedWidth = true;
                table1.SetWidths(medidaCeldas);

                PdfPCell cel1 = new PdfPCell(new Phrase("Asunto: ", font1));               
                table1.AddCell(cel1);

                PdfPTable nested1 = new PdfPTable(1);
                nested1.AddCell(new Phrase("Oficio:", font2));
                nested1.AddCell(new Phrase("Expediente:", font2));
                nested1.AddCell(new Phrase("Folio:", font2));
                nested1.AddCell(new Phrase("Autoridad solicitante:", font2));
                PdfPCell nesthousing1 = new PdfPCell(nested1);
                nesthousing1.Padding = 0f;
                table1.AddCell(nesthousing1);

                PdfPTable nested2 = new PdfPTable(1);
                nested2.AddCell(new Phrase((documento.Oficio != null && documento.Oficio.Trim().Equals("") != true) ? documento.Oficio : " ", FontFactory.GetFont(fontType, 10, iTextSharp.text.Font.NORMAL)));
                nested2.AddCell(new Phrase((documento.Expediente != null && documento.Expediente.Trim().Equals("") != true) ? documento.Expediente : " ", FontFactory.GetFont(fontType, 10, iTextSharp.text.Font.NORMAL)));
                nested2.AddCell(new Phrase((documento.Folio != null && documento.Folio.Trim().Equals("") != true) ? documento.Folio : " ", FontFactory.GetFont(fontType, 10, iTextSharp.text.Font.NORMAL)));
                nested2.AddCell(new Phrase((documento.AutoridadSolicitante != null && documento.AutoridadSolicitante.Trim().Equals("") != true) ? documento.AutoridadSolicitante : " ", FontFactory.GetFont(fontType, 10, iTextSharp.text.Font.NORMAL)));
                PdfPCell nesthousing2 = new PdfPCell(nested2);
                nesthousing2.Padding = 0f;
                table1.AddCell(nesthousing2);

                reportDocument.Add(table1);
                reportDocument.Add(new Paragraph(" "));


                // Tabla 2
                PdfPTable table2 = new PdfPTable(2);
                float[] medidaCeldas2 = { 130f, 390f };
                table2.TotalWidth = 530f;
                table2.LockedWidth = true;
                table2.SetWidths(medidaCeldas2);

                table2.AddCell(new Phrase("Tipo de respuesta:", font1));
                table2.AddCell(new Phrase(documento.RespuestaRequerimiento, font2));
                table2.AddCell(new Phrase("Tipo de asunto:", font1));
                table2.AddCell(new Phrase(documento.Asunto, font2));
                reportDocument.Add(table2);
                reportDocument.Add(new Paragraph(" "));

                // Parafo 3
                if (documento.Atencion != null && documento.Atencion.Trim().Equals("") != true)
                {
                    Paragraph paragraph3 = new Paragraph(documento.Atencion, font2) { Alignment = Element.ALIGN_LEFT };
                    reportDocument.Add(paragraph3);
                    reportDocument.Add(new Paragraph(" "));
                }

                // Tabla 3 - Personas
                foreach (clsPersona persona in documento.ListPersonas)
                {
                    PdfPTable table3 = new PdfPTable(4);
                    float[] medidaCeldas3 = { 100f, 250f, 50f, 130f };
                    table3.TotalWidth = 530f;
                    table3.LockedWidth = true;
                    table3.SetWidths(medidaCeldas3);

                    cell = new PdfPCell(new Phrase("Nombre:", font1));
                    cell.BackgroundColor = new Color(166, 166, 166);
                    table3.AddCell(cell);

                    cell.Phrase = new Phrase(persona.Nombre.ToUpper(), font2);
                    table3.AddCell(cell);

                    cell.Phrase = new Phrase("RFC:", font1);
                    table3.AddCell(cell);

                    cell.Phrase = new Phrase(persona.Rfc.ToUpper(), font2);
                    table3.AddCell(cell);
                    reportDocument.Add(table3);
                    reportDocument.Add(new Paragraph(" "));

                    // Tabla 4 - Cuenta
                    foreach (clsCuenta cuenta in persona.CuentaList)
                    {

                        PdfPTable tblCuenta = new PdfPTable(1);
                        tblCuenta.TotalWidth = 530f;
                        tblCuenta.HorizontalAlignment = Element.ALIGN_CENTER;
                        tblCuenta.LockedWidth = true;

                        PdfPTable tblCuenta1 = new PdfPTable(7);
                        float[] medidaCeldas4 = { 60f, 60f, 45f, 60f, 90f, 60f, 45f};
                        tblCuenta1.SetWidths(medidaCeldas4);
                        tblCuenta1.HorizontalAlignment = Element.ALIGN_CENTER;
                                 
                        cell = new PdfPCell(new Phrase("No. Cuenta", font1));
                        cell.BackgroundColor = new Color(217, 217, 217);
                        tblCuenta1.AddCell(cell);

                        cell.Phrase = new Phrase("Tipo", font1);
                        tblCuenta1.AddCell(cell);

                        cell.Phrase = new Phrase("Estatus", font1);
                        tblCuenta1.AddCell(cell);

                        cell.Phrase = new Phrase("Carácter", font1);
                        tblCuenta1.AddCell(cell);

                        cell.Phrase = new Phrase("Ubicación/Sucursal", font1);
                        tblCuenta1.AddCell(cell);

                        cell.Phrase = new Phrase("Saldo", font1);
                        tblCuenta1.AddCell(cell);

                        cell.Phrase = new Phrase("Moneda", font1);
                        tblCuenta1.AddCell(cell);

                        tblCuenta1.AddCell(new Phrase(cuenta.NoCuenta, font3));
                        tblCuenta1.AddCell(new Phrase(cuenta.Tipo, font3));
                        tblCuenta1.AddCell(new Phrase(cuenta.Estatus, font3));
                        tblCuenta1.AddCell(new Phrase(cuenta.Catacter, font3));
                        tblCuenta1.AddCell(new Phrase(cuenta.UbicacionSucursal, font3));
                        tblCuenta1.AddCell(new Phrase(cuenta.Saldo, font3));
                        tblCuenta1.AddCell(new Phrase(cuenta.Moneda, font3));
                        
                        // Adicionando tblCuenta1 - Primera y Segunda fila de la tabla Cuenta
                        PdfPCell tblCuentaCel = new PdfPCell(tblCuenta1);
                        tblCuentaCel.Padding = 0f;
                        tblCuenta.AddCell(tblCuentaCel);

                        PdfPTable tblCuenta2 = new PdfPTable(2);
                        tblCuenta2.TotalWidth = 530f;
                        float[] medidaCeldasCuentaObs = { 60f, 360f };
                        tblCuenta2.SetWidths(medidaCeldasCuentaObs);
                        tblCuenta2.HorizontalAlignment = Element.ALIGN_CENTER;
                        tblCuenta2.AddCell(new Phrase("Observaciones", font3));
                        tblCuenta2.AddCell(new Phrase(cuenta.Observaciones, font3));

                        // Adicionando tblCuenta2 - Tercera fijla de la tabla Cuenta
                        tblCuentaCel = new PdfPCell(tblCuenta2);
                        tblCuentaCel.Padding = 0f;
                        tblCuenta.AddCell(tblCuentaCel);

                        reportDocument.Add(tblCuenta);
                        reportDocument.Add(new Paragraph(" "));

                        // Tabla 5 - Documentacion
                        if (cuenta.Documentacion != null)
                        {
                            PdfPTable table5 = new PdfPTable(7);
                            float[] medidaCeldas5 = { 80f, 37f, 56f, 26f, 46f, 26f, 46f};
                            // float[] medidaCeldas5 = { 80f, 37f, 56f, 26f, 46f, 26f, 46f, 109f };
                            table5.SetWidths(medidaCeldas5);
                            table5.TotalWidth = 530f;
                            table5.LockedWidth = true;

                            PdfPCell cell5 = new PdfPCell(new Phrase("Documentación que se proporciona (Cuenta: " + cuenta.NoCuenta + ")", font1));
                            cell5.Colspan = 8;
                            cell5.HorizontalAlignment = 0; //0=Left, 1=Centre, 2=Right
                            table5.AddCell(cell5);

                            table5.AddCell(new Phrase("Documento", font1));
                            table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" ");
                            table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" ");
                            
                            string tipoCopia = " ";
                            if (cuenta.Documentacion.EstadoCuenta)
                            {
                                table5.AddCell(new Phrase("Estados de cuenta", font3));
                                table5.AddCell(new Phrase(cuenta.Documentacion.EstadoCuentaApl, font4));
                                //table5.AddCell(new Phrase(cuenta.Documentacion.EstadoCuenta == true ? "X" : "", font4));

                                string del = " ";
                                string al = " ";
                                if (cuenta.Documentacion.EstadoCuenta)
                                {
                                    if (cuenta.Documentacion.EstadoCuentaCs) { tipoCopia = "Copia simple"; }
                                    else if (cuenta.Documentacion.EstadoCuentaCc) { tipoCopia = "Copia certificada"; }

                                    del = cuenta.Documentacion.EstadoCuentaDesde.ToShortDateString();
                                    al = cuenta.Documentacion.EstadoCuentaHasta.ToShortDateString();
                                }
                                table5.AddCell(new Phrase(tipoCopia, font3));
                                table5.AddCell(new Phrase("Del:", font4)); table5.AddCell(new Phrase(del, font3));
                                table5.AddCell(new Phrase("Al:", font4)); table5.AddCell(new Phrase(al, font3));
                                table5.AddCell(new Phrase("Observaciones", font3));
                                PdfPCell cellEdcObs = new PdfPCell(new Phrase(cuenta.Documentacion.EstadoCuentaObs, font3));
                                cellEdcObs.Colspan = 7;
                                cellEdcObs.HorizontalAlignment = 0; //0=Left, 1=Centre, 2=Right
                                table5.AddCell(cellEdcObs);
                            }

                            if (cuenta.Documentacion.IdentificacionOficial)
                            {
                                table5.AddCell(new Phrase("Identificación oficial", font3));
                                table5.AddCell(new Phrase(cuenta.Documentacion.IdentificacionOficialApl, font4));
                                // table5.AddCell(new Phrase(cuenta.Documentacion.IdentificacionOficial == true ? "X" : "", font4));
                                tipoCopia = " ";
                                if (cuenta.Documentacion.IdentificacionOficial)
                                {
                                    if (cuenta.Documentacion.IdentificacionOficialCs) { tipoCopia = "Copia simple"; }
                                    else if (cuenta.Documentacion.IdentificacionOficialCc) { tipoCopia = "Copia certificada"; }
                                }
                                table5.AddCell(new Phrase(tipoCopia, font3));
                                table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" ");
                                table5.AddCell(new Phrase("Observaciones", font3));
                                PdfPCell cellIdOfObs = new PdfPCell(new Phrase(cuenta.Documentacion.IdentificacionOficialObs, font3));
                                cellIdOfObs.Colspan = 7;
                                cellIdOfObs.HorizontalAlignment = 0; //0=Left, 1=Centre, 2=Right
                                table5.AddCell(cellIdOfObs);
                            }

                            if (cuenta.Documentacion.ContratoApertura)
                            {
                                table5.AddCell(new Phrase("Contrato de apertura", font3));
                                table5.AddCell(new Phrase(cuenta.Documentacion.ContratoAperturaApl, font4));
                                //table5.AddCell(new Phrase(cuenta.Documentacion.ContratoApertura == true ? "X" : "", font4));
                                tipoCopia = " ";
                                if (cuenta.Documentacion.ContratoApertura)
                                {
                                    if (cuenta.Documentacion.ContratoAperturaCs) { tipoCopia = "Copia simple"; }
                                    else if (cuenta.Documentacion.ContratoAperturaCc) { tipoCopia = "Copia certificada"; }
                                }
                                table5.AddCell(new Phrase(tipoCopia, font3));
                                table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" ");
                                table5.AddCell(new Phrase("Observaciones", font3));
                                PdfPCell cellContAperObs = new PdfPCell(new Phrase(cuenta.Documentacion.ContratoAperturaObs, font3));
                                cellContAperObs.Colspan = 7;
                                cellContAperObs.HorizontalAlignment = 0; //0=Left, 1=Centre, 2=Right
                                table5.AddCell(cellContAperObs);
                            }

                            if (cuenta.Documentacion.PoderNotarial)
                            {
                                table5.AddCell(new Phrase("Poder notarial", font3));
                                table5.AddCell(new Phrase(cuenta.Documentacion.PoderNotarialApl, font4));
                                // table5.AddCell(new Phrase(cuenta.Documentacion.PoderNotarial == true ? "X" : "", font4));
                                tipoCopia = " ";
                                if (cuenta.Documentacion.PoderNotarial)
                                {
                                    if (cuenta.Documentacion.PoderNotarialCs) { tipoCopia = "Copia simple"; }
                                    else if (cuenta.Documentacion.PoderNotarialCc) { tipoCopia = "Copia certificada"; }
                                }
                                table5.AddCell(new Phrase(tipoCopia, font3));
                                table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" ");
                                table5.AddCell(new Phrase("Observaciones", font3));
                                PdfPCell cellPNotObs = new PdfPCell(new Phrase(cuenta.Documentacion.PoderNotarialObs, font3));
                                cellPNotObs.Colspan = 7;
                                cellPNotObs.HorizontalAlignment = 0; //0=Left, 1=Centre, 2=Right
                                table5.AddCell(cellPNotObs);
                            }


                            if (cuenta.Documentacion.ComprobanteDomicilio)
                            {
                                table5.AddCell(new Phrase("Comprobante de domicilio", font3));
                                table5.AddCell(new Phrase(cuenta.Documentacion.ComprobanteDomicilioApl, font4));
                                // table5.AddCell(new Phrase(cuenta.Documentacion.ComprobanteDomicilio == true ? "X" : "", font4));
                                tipoCopia = " ";
                                if (cuenta.Documentacion.ComprobanteDomicilio)
                                {
                                    if (cuenta.Documentacion.ComprobanteDomicilioCs) { tipoCopia = "Copia simple"; }
                                    else if (cuenta.Documentacion.ComprobanteDomicilioCc) { tipoCopia = "Copia certificada"; }
                                }
                                table5.AddCell(new Phrase(tipoCopia, font3));
                                table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" ");
                                table5.AddCell(new Phrase("Observaciones", font3));
                                PdfPCell cellComprobanteDomicilioObs = new PdfPCell(new Phrase(cuenta.Documentacion.ComprobanteDomicilioObs, font3));
                                cellComprobanteDomicilioObs.Colspan = 7;
                                cellComprobanteDomicilioObs.HorizontalAlignment = 0; //0=Left, 1=Centre, 2=Right
                                table5.AddCell(cellComprobanteDomicilioObs);
                            }

                            if (cuenta.Documentacion.TarjetaFirmas)
                            {
                                table5.AddCell(new Phrase("Tarjeta de firmas", font3));
                                table5.AddCell(new Phrase(cuenta.Documentacion.TarjetaFirmasApl, font4));
                                // table5.AddCell(new Phrase(cuenta.Documentacion.TarjetaFirmas == true ? "X" : "", font4));
                                tipoCopia = " ";
                                if (cuenta.Documentacion.TarjetaFirmas)
                                {
                                    if (cuenta.Documentacion.TarjetaFirmasCs) { tipoCopia = "Copia simple"; }
                                    else if (cuenta.Documentacion.TarjetaFirmasCc) { tipoCopia = "Copia certificada"; }
                                }
                                table5.AddCell(new Phrase(tipoCopia, font3));
                                table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" ");
                                table5.AddCell(new Phrase("Observaciones", font3));
                                PdfPCell cellTarjetaFirmasObs = new PdfPCell(new Phrase(cuenta.Documentacion.TarjetaFirmasObs, font3));
                                cellTarjetaFirmasObs.Colspan = 7;
                                cellTarjetaFirmasObs.HorizontalAlignment = 0; //0=Left, 1=Centre, 2=Right
                                table5.AddCell(cellTarjetaFirmasObs);
                            }

                            reportDocument.Add(table5);
                            reportDocument.Add(new Paragraph(" "));
                        }

                        // Tabla 6 - Documentacion de operaciones
                        if (cuenta.Operaciones != null)
                        {
                            PdfPTable table6 = new PdfPTable(3);
                            float[] medidaCeldas6 = { 132f, 37f, 132f};
                            table6.SetWidths(medidaCeldas6);
                            table6.TotalWidth = 530f;
                            table6.LockedWidth = true;

                            PdfPCell cell6 = new PdfPCell(new Phrase("Documentación de operaciones (Cuenta: " + cuenta.NoCuenta + ")", font1));
                            cell6.Colspan = 4;
                            cell6.HorizontalAlignment = 0; //0=Left, 1=Centre, 2=Right
                            table6.AddCell(cell6);

                            table6.AddCell(new Phrase("Documento", font1));
                            table6.AddCell(" "); table6.AddCell(" "); 

                            string tipoCopia = " ";
                            if (cuenta.Operaciones.Cheques)
                            {
                                table6.AddCell(new Phrase("Cheques", font3));
                                table6.AddCell(new Phrase(cuenta.Operaciones.ChequesApl, font4));
                                if (cuenta.Operaciones.Cheques)
                                {
                                    if (cuenta.Operaciones.ChequesCs) { tipoCopia = "Copia simple"; }
                                    else if (cuenta.Operaciones.ChequesCc) { tipoCopia = "Copia certificada"; }
                                }
                                table6.AddCell(new Phrase(tipoCopia, font3));
                                table6.AddCell(new Phrase("Observaciones", font3));
                                PdfPCell cellCopiaCertificadaObs = new PdfPCell(new Phrase(cuenta.Operaciones.ChequesObs, font3));
                                cellCopiaCertificadaObs.Colspan = 2;
                                cellCopiaCertificadaObs.HorizontalAlignment = 0; //0=Left, 1=Centre, 2=Right
                                table6.AddCell(cellCopiaCertificadaObs);
                            }

                            if (cuenta.Operaciones.FichaDeposito)
                            {
                                table6.AddCell(new Phrase("Fichas de depósito", font3));
                                table6.AddCell(new Phrase(cuenta.Operaciones.FichaDepositoApl, font4));
                                // table6.AddCell(new Phrase(cuenta.Operaciones.FichaDeposito ? "X" : "", font4));
                                tipoCopia = " ";
                                if (cuenta.Operaciones.FichaDeposito)
                                {
                                    if (cuenta.Operaciones.FichaDepositoCs) { tipoCopia = "Copia simple"; }
                                    else if (cuenta.Operaciones.FichaDepositoCc) { tipoCopia = "Copia certificada"; }
                                }
                                table6.AddCell(new Phrase(tipoCopia, font3));
                                table6.AddCell(new Phrase("Observaciones", font3));
                                PdfPCell cellFichaDepositoObs = new PdfPCell(new Phrase(cuenta.Operaciones.FichaDepositoObs, font3));
                                cellFichaDepositoObs.Colspan = 2;
                                cellFichaDepositoObs.HorizontalAlignment = 0; //0=Left, 1=Centre, 2=Right
                                table6.AddCell(cellFichaDepositoObs);
                            }

                            if (cuenta.Operaciones.FichaRetiro)
                            {
                                table6.AddCell(new Phrase("Fichas de retiro", font3));
                                table6.AddCell(new Phrase(cuenta.Operaciones.FichaRetiroApl, font4));
                                // table6.AddCell(new Phrase(cuenta.Operaciones.FichaRetiro ? "X" : "", font4));
                                tipoCopia = " ";
                                if (cuenta.Operaciones.FichaRetiro)
                                {
                                    if (cuenta.Operaciones.FichaRetiroCs) { tipoCopia = "Copia simple"; }
                                    else if (cuenta.Operaciones.FichaRetiroCc) { tipoCopia = "Copia certificada"; }
                                }
                                table6.AddCell(new Phrase(tipoCopia, font3));
                                table6.AddCell(new Phrase("Observaciones", font3));
                                PdfPCell cellFichaRetiroObs = new PdfPCell(new Phrase(cuenta.Operaciones.FichaRetiroObs, font3));
                                cellFichaRetiroObs.Colspan = 2;
                                cellFichaRetiroObs.HorizontalAlignment = 0; //0=Left, 1=Centre, 2=Right
                                table6.AddCell(cellFichaRetiroObs);
                            }

                            if (cuenta.Operaciones.Comprobantes)
                            {
                                table6.AddCell(new Phrase("Comprobantes", font3));
                                table6.AddCell(new Phrase(cuenta.Operaciones.ComprobantesApl, font4));
                                //table6.AddCell(new Phrase(cuenta.Operaciones.Comprobantes ? "X" : "", font4));
                                tipoCopia = " ";
                                if (cuenta.Operaciones.Comprobantes)
                                {
                                    if (cuenta.Operaciones.ComprobantesCs) { tipoCopia = "Copia simple"; }
                                    else if (cuenta.Operaciones.ComprobantesCc) { tipoCopia = "Copia certificada"; }
                                }
                                table6.AddCell(new Phrase(tipoCopia, font3));
                                table6.AddCell(new Phrase("Observaciones", font3));
                                PdfPCell cellComprobantesObs = new PdfPCell(new Phrase(cuenta.Operaciones.ComprobantesObs, font3));
                                cellComprobantesObs.Colspan = 2;
                                cellComprobantesObs.HorizontalAlignment = 0; //0=Left, 1=Centre, 2=Right
                                table6.AddCell(cellComprobantesObs);
                            }

                            if (cuenta.Operaciones.Otros)
                            {
                                table6.AddCell(new Phrase("Otro (especificar): " + cuenta.Operaciones.OtrosEspecifica, font3));
                                table6.AddCell(new Phrase(cuenta.Operaciones.OtrosApl, font4));
                                //table6.AddCell(new Phrase(cuenta.Operaciones.Otros ? "X" : "", font4));
                                tipoCopia = " ";
                                if (cuenta.Operaciones.Otros)
                                {
                                    if (cuenta.Operaciones.OtrosCs) { tipoCopia = "Copia simple"; }
                                    else if (cuenta.Operaciones.OtrosCc) { tipoCopia = "Copia certificada"; }
                                }
                                table6.AddCell(new Phrase(tipoCopia, font3));
                                table6.AddCell(new Phrase("Observaciones", font3));
                                PdfPCell cellOtroObs = new PdfPCell(new Phrase(cuenta.Operaciones.OtrosObs, font3));
                                cellOtroObs.Colspan = 2;
                                cellOtroObs.HorizontalAlignment = 0; //0=Left, 1=Centre, 2=Right
                                table6.AddCell(cellOtroObs);
                            }

                            reportDocument.Add(table6);
                            reportDocument.Add(new Paragraph(" "));

                            if (cuenta.Operaciones.InfSolicitada != false || cuenta.Operaciones.InfSolicitadaExc != false ||
                                cuenta.Operaciones.InfSolicitadaForPar != false || cuenta.Operaciones.InfSolicitadaAnex != false)
                            {
                                string informacionSolicitada = "";
                                if (cuenta.Operaciones.InfSolicitada)
                                    informacionSolicitada = "Se proporciona toda la documentacion solicitada por la autoridad.";
                                else if (cuenta.Operaciones.InfSolicitadaExc)
                                    informacionSolicitada = "Se proporciona la documentación solicitada por la autoridad excepto " +
                                        "lo señalado en el/los anexo(s): " + cuenta.Operaciones.InfSolicitadaAnexo;
                                else if (cuenta.Operaciones.InfSolicitadaForPar)
                                    informacionSolicitada = "Se proporciona la documentación de forma parcial según lo " +
                                                            "señalado en el/los anexo(s): " + cuenta.Operaciones.InfSolicitadaAnexo;
                                else if (cuenta.Operaciones.InfSolicitadaAnex)
                                    informacionSolicitada = "Se entrega última parcialidad según lo señalado en el/los anexo(s): " + cuenta.Operaciones.InfSolicitadaAnexo;
                                Paragraph paragraph4 = new Paragraph(informacionSolicitada, font2) { Alignment = Element.ALIGN_LEFT };
                                reportDocument.Add(paragraph4);
                                reportDocument.Add(new Paragraph(" "));
                            }
                        }

                        // Tabla 7 - Informacíon de movimientos electronicos
                        if (cuenta.MovimientosElectronicos != null)
                        {
                            PdfPTable table7 = new PdfPTable(2);
                            float[] medidaCeldas7 = { 100f, 430f};
                            table7.SetWidths(medidaCeldas7);
                            table7.TotalWidth = 530f;
                            table7.LockedWidth = true;

                            PdfPCell cell7 = new PdfPCell(new Phrase("Información de movimientos electrónicos (Cuenta: " + cuenta.NoCuenta + ")", font1));
                            cell7.Colspan = 3;
                            cell7.HorizontalAlignment = 0; //0=Left, 1=Centre, 2=Right
                            table7.AddCell(cell7);

                            table7.AddCell(new Phrase("Documento", font1));
                            table7.AddCell(" ");

                            if (cuenta.MovimientosElectronicos.MovimientosElectronicos)
                            {
                                table7.AddCell(new Phrase("Movimientos electrónicos", font3));
                                table7.AddCell(new Phrase(cuenta.MovimientosElectronicos.MovimientosElectronicosApl, font4));
                                table7.AddCell(new Phrase("Observaciones", font3));
                                PdfPCell cellMOvimientosElectricosObs = new PdfPCell(new Phrase(cuenta.MovimientosElectronicos.MovimientosElectronicosObs, font3));
                                cellMOvimientosElectricosObs.Colspan = 2;
                                cellMOvimientosElectricosObs.HorizontalAlignment = 0; //0=Left, 1=Centre, 2=Right
                                table7.AddCell(cellMOvimientosElectricosObs);
                            }

                            if (cuenta.MovimientosElectronicos.DispersionNomina)
                            {
                                table7.AddCell(new Phrase("Dispersión de nómina", font3));
                                table7.AddCell(new Phrase(cuenta.MovimientosElectronicos.DispersionNominaApl, font4));
                                table7.AddCell(new Phrase("Observaciones", font3));
                                PdfPCell cellDispersionNominaObs = new PdfPCell(new Phrase(cuenta.MovimientosElectronicos.DispersionNominaObs, font3));
                                cellDispersionNominaObs.Colspan = 2;
                                cellDispersionNominaObs.HorizontalAlignment = 0; //0=Left, 1=Centre, 2=Right
                                table7.AddCell(cellDispersionNominaObs);
                            }

                            reportDocument.Add(table7);
                            reportDocument.Add(new Paragraph(" "));

                            if (cuenta.MovimientosElectronicos.MovEInfSolicitada != false || cuenta.MovimientosElectronicos.MovEInfSolicitadaExc != false)
                            {
                                string informacionSOlicitadaME = "";
                                if (cuenta.MovimientosElectronicos.MovEInfSolicitada)
                                    informacionSOlicitadaME = "Se proporciona toda  la información solicitada por la autoridad.";
                                else if (cuenta.MovimientosElectronicos.MovEInfSolicitadaExc)
                                    informacionSOlicitadaME = "Se proporciona la información solicitada por la autoridad según lo señalado en el/los anexo(s): " + cuenta.MovimientosElectronicos.MovEAnexo;
                                Paragraph paragraph5 = new Paragraph(informacionSOlicitadaME, font2) { Alignment = Element.ALIGN_LEFT };
                                reportDocument.Add(paragraph5);
                                reportDocument.Add(new Paragraph(" "));
                            }
                        }
                    }
                    
                }

                // Tabla 8 - Otras operaciones / observaciones
                if (documento.Observaciones != null && documento.Observaciones != "")
                {
                    PdfPTable table8 = new PdfPTable(1);
                    table8.TotalWidth = 530f;
                    table8.LockedWidth = true;

                    table8.AddCell(new Phrase("Otras operaciones/observaciones", font1));
                    table8.AddCell(new Phrase(documento.Observaciones, font2));
                    reportDocument.Add(table8);
                    reportDocument.Add(new Paragraph(" "));
                    reportDocument.Add(new Paragraph(" "));
                }

                reportDocument.Add(new Paragraph(" "));
                reportDocument.Add(new Paragraph(" "));
                reportDocument.Add(new Paragraph(" "));
                reportDocument.Add(new Paragraph(" "));

                reportDocument.Add(new Paragraph("______________________________________", font2) { Alignment = Element.ALIGN_CENTER });
                reportDocument.Add(new Paragraph(documento.Firmante, font2) { Alignment = Element.ALIGN_CENTER });
                reportDocument.Add(new Paragraph(documento.Puesto, font2) { Alignment = Element.ALIGN_CENTER });
                reportDocument.Add(new Paragraph(documento.ControlInterno, font2) { Alignment = Element.ALIGN_LEFT });

            }
            catch (IOException e)
            {
                Logs.LogFile(e.Message, e.ToString(), e.StackTrace);
                reportDocument.Close();
                throw new Exception("El documento está siendo utilizado por otra aplicación.");
            }
            catch (Exception e)
            {
                Logs.LogFile(e.Message, e.ToString(), e.StackTrace);
                reportDocument.Close();
                throw new Exception("Ha ocurrido un error inesperado al generar el documento.");
            }
            finally
            {
                reportDocument.Close();
            }
        }

        /// <Generacion de reporte - Respuesta negatia>
        /// 
        /// </Generacion de reporte - Respuesta negatia>
        /// <param name="documento">Datos para generar el documento</param>
        /// <param name="path">Ruta donde se escribira el documento</param>
        public static void CrearDocumentoRespuestaNegativa(clsDocumento documento, string path)
        {
            // Conformando documento
            Document reportDocument = new Document(PageSize.LETTER);
            try
            {
                // Creando objetos de escritura
                PdfWriter.GetInstance(reportDocument, new FileStream(path, FileMode.Create));
                Color borderColor = Color.LIGHT_GRAY;

                // Declaracion de funetes
                const string fontType = "Arial";
                Font font1 = FontFactory.GetFont(fontType, 10, iTextSharp.text.Font.BOLD);
                Font font2 = FontFactory.GetFont(fontType, 10, iTextSharp.text.Font.NORMAL);
                Font font3 = FontFactory.GetFont(fontType, 8, iTextSharp.text.Font.NORMAL);
                Font font4 = FontFactory.GetFont(fontType, 8, iTextSharp.text.Font.BOLD);

                // Margenes del documento
                reportDocument.SetMargins(40, 40, 100, 50);

                // Abriendo documento para escritura
                reportDocument.Open();


                Table table = new Table(2, 1) { BorderWidth = 0, BorderColor = borderColor };
                float[] headerwidths = new float[] { 300, 600 };
                table.Widths = headerwidths;
                table.WidthPercentage = 100;
                table.Padding = 1;

                Paragraph paragraph = new Paragraph();
                paragraph = new Paragraph(documento.Fecha, font2) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph);
                reportDocument.Add(new Paragraph(" "));
                reportDocument.Add(new Paragraph(" "));

                paragraph = new Paragraph("Comisión Nacional Bancaria y de Valores", font1) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph);
                paragraph = new Paragraph("Vicepresidencia de Supervisión de Procesos Preventivos", font1) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph);
                paragraph = new Paragraph("Dirección General de Atención a Autoridades", font1) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph);
                //paragraph = new Paragraph("Dirección General Adjunta de Atención a Autoridades " + documento.DirigidoDGA, font1) { Alignment = Element.ALIGN_LEFT };
                paragraph = new Paragraph("", font1) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph);
                reportDocument.Add(new Paragraph(" "));

                // Dirigido a:
                string dirigidoA = "Lic. Luz María Villafuerte García";
                paragraph = new Paragraph("Atención " + dirigidoA, font2) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph);
                reportDocument.Add(new Paragraph(" "));

                // Tabla 1
                PdfPTable table1 = new PdfPTable(3);
                float[] medidaCeldas = { 130f, 140f, 250f };
                table1.TotalWidth = 530f;
                table1.LockedWidth = true;
                table1.SetWidths(medidaCeldas);

                PdfPCell cel1 = new PdfPCell(new Phrase("Asunto: ", font1));
                table1.AddCell(cel1);

                PdfPTable nested1 = new PdfPTable(1);
                nested1.AddCell(new Phrase("Oficio:", font2));
                nested1.AddCell(new Phrase("Expediente:", font2));
                nested1.AddCell(new Phrase("Folio:", font2));
                nested1.AddCell(new Phrase("Autoridad solicitante:", font2));
                PdfPCell nesthousing1 = new PdfPCell(nested1);
                nesthousing1.Padding = 0f;
                table1.AddCell(nesthousing1);

                PdfPTable nested2 = new PdfPTable(1);
                nested2.AddCell(new Phrase((documento.Oficio != null && documento.Oficio.Trim().Equals("") != true) ? documento.Oficio : " ", FontFactory.GetFont(fontType, 10, iTextSharp.text.Font.NORMAL)));
                nested2.AddCell(new Phrase((documento.Expediente != null && documento.Expediente.Trim().Equals("") != true) ? documento.Expediente : " ", FontFactory.GetFont(fontType, 10, iTextSharp.text.Font.NORMAL)));
                nested2.AddCell(new Phrase((documento.Folio != null && documento.Folio.Trim().Equals("") != true) ? documento.Folio : " ", FontFactory.GetFont(fontType, 10, iTextSharp.text.Font.NORMAL)));
                nested2.AddCell(new Phrase((documento.AutoridadSolicitante != null && documento.AutoridadSolicitante.Trim().Equals("") != true) ? documento.AutoridadSolicitante : " ", FontFactory.GetFont(fontType, 10, iTextSharp.text.Font.NORMAL)));
                PdfPCell nesthousing2 = new PdfPCell(nested2);
                nesthousing2.Padding = 0f;
                table1.AddCell(nesthousing2);

                reportDocument.Add(table1);
                reportDocument.Add(new Paragraph(" "));


                // Tabla 2
                PdfPTable table2 = new PdfPTable(2);
                float[] medidaCeldas2 = { 130f, 390f };
                table2.TotalWidth = 530f;
                table2.LockedWidth = true;
                table2.SetWidths(medidaCeldas2);

                table2.AddCell(new Phrase("Tipo de respuesta:", font1));
                table2.AddCell(new Phrase(documento.RespuestaRequerimiento, font2));
                table2.AddCell(new Phrase("Tipo de asunto:", font1));
                table2.AddCell(new Phrase(documento.Asunto, font2));
                reportDocument.Add(table2);
                reportDocument.Add(new Paragraph(" "));

                // Tabla 3
                PdfPTable table8 = new PdfPTable(1);
                table8.TotalWidth = 530f;
                table8.LockedWidth = true;

                table8.AddCell(new Phrase("Otras operaciones/observaciones", font1));
                table8.AddCell(new Phrase(documento.Observaciones, font2));
                reportDocument.Add(table8);
                reportDocument.Add(new Paragraph(" "));
                reportDocument.Add(new Paragraph(" "));

                //Paragraph paragraph3 = new Paragraph(documento.Observaciones, font2) { Alignment = Element.ALIGN_LEFT };
                //reportDocument.Add(paragraph3);
                reportDocument.Add(new Paragraph(" "));

                reportDocument.Add(new Paragraph(" "));
                reportDocument.Add(new Paragraph(" "));
                reportDocument.Add(new Paragraph(" "));
                reportDocument.Add(new Paragraph(" "));

                reportDocument.Add(new Paragraph("______________________________________", font2) { Alignment = Element.ALIGN_CENTER });
                reportDocument.Add(new Paragraph(documento.Firmante, font2) { Alignment = Element.ALIGN_CENTER });
                reportDocument.Add(new Paragraph(documento.Puesto, font2) { Alignment = Element.ALIGN_CENTER });
                reportDocument.Add(new Paragraph(documento.ControlInterno, font2) { Alignment = Element.ALIGN_LEFT });

            }
            catch (IOException e)
            {
                Logs.LogFile(e.Message, e.ToString(), e.StackTrace);
                reportDocument.Close();
                throw new Exception("El documento está siendo utilizado por otra aplicación.");
            }
            catch (Exception e)
            {
                Logs.LogFile(e.Message, e.ToString(), e.StackTrace);
                reportDocument.Close();
                throw new Exception("Ha ocurrido un error inesperado al generar el documento.");
            }
            finally
            {
                reportDocument.Close();
            }
        }

        /// <Generacion de reporte - Respuesta amparo>
        /// 
        /// </Generacion de reporte - Respuesta amparo>
        /// <param name="documento">Datos para generar el documento</param>
        /// <param name="path">Ruta donde se escribira el documento</param>
        public static void CrearDocumentoRespuestaAmparo(clsDocumento documento, string path)
        {
            // Conformando documento
            Document reportDocument = new Document(PageSize.LETTER);
            try
            {
                // Creando objetos de escritura
                PdfWriter.GetInstance(reportDocument, new FileStream(path, FileMode.Create));
                Color borderColor = Color.LIGHT_GRAY;

                // Declaracion de funetes
                const string fontType = "Arial";
                Font font1 = FontFactory.GetFont(fontType, 10, iTextSharp.text.Font.BOLD);
                Font font2 = FontFactory.GetFont(fontType, 10, iTextSharp.text.Font.NORMAL);
                Font font3 = FontFactory.GetFont(fontType, 8, iTextSharp.text.Font.NORMAL);
                Font font4 = FontFactory.GetFont(fontType, 8, iTextSharp.text.Font.BOLD);

                // Margenes del documento
                reportDocument.SetMargins(40, 40, 100, 50);

                // Abriendo documento para escritura
                reportDocument.Open();


                Table table = new Table(2, 1) { BorderWidth = 0, BorderColor = borderColor };
                float[] headerwidths = new float[] { 300, 600 };
                table.Widths = headerwidths;
                table.WidthPercentage = 100;
                table.Padding = 1;

                Paragraph paragraph = new Paragraph();
                paragraph = new Paragraph(documento.Fecha, font2) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph);
                reportDocument.Add(new Paragraph(" "));
                reportDocument.Add(new Paragraph(" "));

                paragraph = new Paragraph("Comisión Nacional Bancaria y de Valores", font1) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph);
                paragraph = new Paragraph("Vicepresidencia de Supervisión de Procesos Preventivos", font1) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph);
                paragraph = new Paragraph("Dirección General de Atención a Autoridades", font1) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph);
                // paragraph = new Paragraph("Dirección General Adjunta de Atención a Autoridades " + documento.DirigidoDGA, font1) { Alignment = Element.ALIGN_LEFT };
                paragraph = new Paragraph("", font1) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph);
                reportDocument.Add(new Paragraph(" "));

                // Dirigido a:
                string dirigidoA = "Lic. Luz María Villafuerte García";
                paragraph = new Paragraph("Atención " + dirigidoA, font2) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph);
                reportDocument.Add(new Paragraph(" "));

                // Tabla 1
                PdfPTable table1 = new PdfPTable(3);
                float[] medidaCeldas = { 130f, 140f, 250f };
                table1.TotalWidth = 530f;
                table1.LockedWidth = true;
                table1.SetWidths(medidaCeldas);

                PdfPCell cel1 = new PdfPCell(new Phrase("Asunto: ", font1));
                table1.AddCell(cel1);

                PdfPTable nested1 = new PdfPTable(1);
                nested1.AddCell(new Phrase("Oficio:", font2));
                nested1.AddCell(new Phrase("Expediente:", font2));
                nested1.AddCell(new Phrase("Folio:", font2));
                nested1.AddCell(new Phrase("Autoridad solicitante:", font2));
                PdfPCell nesthousing1 = new PdfPCell(nested1);
                nesthousing1.Padding = 0f;
                table1.AddCell(nesthousing1);

                PdfPTable nested2 = new PdfPTable(1);
                nested2.AddCell(new Phrase((documento.Oficio != null && documento.Oficio.Trim().Equals("") != true) ? documento.Oficio : " ", FontFactory.GetFont(fontType, 10, iTextSharp.text.Font.NORMAL)));
                nested2.AddCell(new Phrase((documento.Expediente != null && documento.Expediente.Trim().Equals("") != true) ? documento.Expediente : " ", FontFactory.GetFont(fontType, 10, iTextSharp.text.Font.NORMAL)));
                nested2.AddCell(new Phrase((documento.Folio != null && documento.Folio.Trim().Equals("") != true) ? documento.Folio : " ", FontFactory.GetFont(fontType, 10, iTextSharp.text.Font.NORMAL)));
                nested2.AddCell(new Phrase((documento.AutoridadSolicitante != null && documento.AutoridadSolicitante.Trim().Equals("") != true) ? documento.AutoridadSolicitante : " ", FontFactory.GetFont(fontType, 10, iTextSharp.text.Font.NORMAL)));
                PdfPCell nesthousing2 = new PdfPCell(nested2);
                nesthousing2.Padding = 0f;
                table1.AddCell(nesthousing2);

                reportDocument.Add(table1);
                reportDocument.Add(new Paragraph(" "));
                                
                // Tabla 3
                PdfPTable table8 = new PdfPTable(1);
                table8.TotalWidth = 530f;
                table8.LockedWidth = true;

                table8.AddCell(new Phrase("Otras operaciones/observaciones", font1));
                table8.AddCell(new Phrase(documento.Observaciones, font2));
                reportDocument.Add(table8);
                reportDocument.Add(new Paragraph(" "));
                reportDocument.Add(new Paragraph(" "));

                //Paragraph paragraph3 = new Paragraph(documento.Observaciones, font2) { Alignment = Element.ALIGN_LEFT };
                //reportDocument.Add(paragraph3);
                reportDocument.Add(new Paragraph(" "));

                reportDocument.Add(new Paragraph(" "));
                reportDocument.Add(new Paragraph(" "));
                reportDocument.Add(new Paragraph(" "));
                reportDocument.Add(new Paragraph(" "));

                reportDocument.Add(new Paragraph("______________________________________", font2) { Alignment = Element.ALIGN_CENTER });
                reportDocument.Add(new Paragraph(documento.Firmante, font2) { Alignment = Element.ALIGN_CENTER });
                reportDocument.Add(new Paragraph(documento.Puesto, font2) { Alignment = Element.ALIGN_CENTER });
                reportDocument.Add(new Paragraph(documento.ControlInterno, font2) { Alignment = Element.ALIGN_LEFT });

            }
            catch (IOException e)
            {
                Logs.LogFile(e.Message, e.ToString(), e.StackTrace);
                reportDocument.Close();
                throw new Exception("El documento está siendo utilizado por otra aplicación.");
            }
            catch (Exception e)
            {
                Logs.LogFile(e.Message, e.ToString(), e.StackTrace);
                reportDocument.Close();
                throw new Exception("Ha ocurrido un error inesperado al generar el documento.");
            }
            finally
            {
                reportDocument.Close();
            }
        }

        /// <Generacion de reporte - Respuesta positiva>
        /// 
        /// </Generacion de reporte - Respuesta positiva>
        /// <param name="documento">Datos para generar el documento</param>
        /// <param name="path">Ruta donde se escribira el documento</param>
        public static void SavePdfNaturalPerson_Test(clsDocumento documento, string path)
        {
            // Conformando documento
            Document reportDocument = new Document(PageSize.LETTER);
            try
            {
                // Creando objetos de escritura
                PdfWriter.GetInstance(reportDocument, new FileStream(path, FileMode.Create));
                Color borderColor = Color.LIGHT_GRAY;

                // Declaracion de funetes
                const string fontType = "Arial";
                Font font1 = FontFactory.GetFont(fontType, 10, iTextSharp.text.Font.BOLD);
                Font font2 = FontFactory.GetFont(fontType, 10, iTextSharp.text.Font.NORMAL);
                Font font3 = FontFactory.GetFont(fontType, 8, iTextSharp.text.Font.NORMAL);
                Font font4 = FontFactory.GetFont(fontType, 8, iTextSharp.text.Font.BOLD);

                // Margenes del documento
                reportDocument.SetMargins(40, 40, 100, 50);

                // Abriendo documento para escritura
                reportDocument.Open();


                Table table = new Table(2, 1) { BorderWidth = 0, BorderColor = borderColor };
                float[] headerwidths = new float[] { 300, 600 };
                table.Widths = headerwidths;
                table.WidthPercentage = 100;
                table.Padding = 1;

                Paragraph paragraph = new Paragraph();
                paragraph = new Paragraph("Comisión Nacional Bancaria y de Valores", font1) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph);
                paragraph = new Paragraph("Vicepresidencia de Supervisión de Procesos Preventivos", font1) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph);
                paragraph = new Paragraph("Dirección General de Atención a Autoridades", font1) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph);
                //paragraph = new Paragraph("Dirección General Adjunta de Atención a Autoridades " + "D", font1) { Alignment = Element.ALIGN_LEFT };
                paragraph = new Paragraph("", font1) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph);
                reportDocument.Add(new Paragraph(" "));

                // paragraph = new Paragraph("Atención " + "Alfonso del Castillo González", font2) { Alignment = Element.ALIGN_LEFT };
                paragraph = new Paragraph("", font2) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph);
                reportDocument.Add(new Paragraph(" "));

                // Tabla 1
                PdfPTable table1 = new PdfPTable(3);
                float[] medidaCeldas = { 130f, 140f, 250f };
                table1.TotalWidth = 530f;
                table1.LockedWidth = true;
                table1.SetWidths(medidaCeldas);

                PdfPCell cel1 = new PdfPCell(new Phrase("Asunto: ", font1));
                table1.AddCell(cel1);

                PdfPTable nested1 = new PdfPTable(1);
                nested1.AddCell(new Phrase("Oficio:", font2));
                nested1.AddCell(new Phrase("Expediente:", font2));
                nested1.AddCell(new Phrase("Folio:", font2));
                PdfPCell nesthousing1 = new PdfPCell(nested1);
                nesthousing1.Padding = 0f;
                table1.AddCell(nesthousing1);

                PdfPTable nested2 = new PdfPTable(1);
                nested2.AddCell(new Phrase(" ", FontFactory.GetFont(fontType, 10, iTextSharp.text.Font.NORMAL)));
                nested2.AddCell(new Phrase(" ", FontFactory.GetFont(fontType, 10, iTextSharp.text.Font.NORMAL)));
                nested2.AddCell(new Phrase(" ", FontFactory.GetFont(fontType, 10, iTextSharp.text.Font.NORMAL)));
                PdfPCell nesthousing2 = new PdfPCell(nested2);
                nesthousing2.Padding = 0f;
                table1.AddCell(nesthousing2);

                reportDocument.Add(table1);
                reportDocument.Add(new Paragraph(" "));


                // Tabla 2
                PdfPTable table2 = new PdfPTable(2);
                float[] medidaCeldas2 = { 130f, 390f };
                table2.TotalWidth = 530f;
                table2.LockedWidth = true;
                table2.SetWidths(medidaCeldas2);

                table2.AddCell(new Phrase("Tipo de respuesta:", font1));
                table2.AddCell(new Phrase("Total", font2));
                table2.AddCell(new Phrase("Tipo de asunto:", font1));
                table2.AddCell(new Phrase("Información", font2));
                reportDocument.Add(table2);
                reportDocument.Add(new Paragraph(" "));

                // Parafo 3
                Paragraph paragraph3 = new Paragraph("En atención al oficio señalado al rubro, nos permitimos hacer " +
                                                     "de su conocimiento que se ha procedido a ejecutar la instrucción " +
                                                     "de la autoridad requirente respecto a la(s) persona(s) que abajo " +
                                                     "se indica(n):", font2) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph3);
                reportDocument.Add(new Paragraph(" "));

                // Tabla 3
                PdfPTable table3 = new PdfPTable(4);
                float[] medidaCeldas3 = { 100f, 250f, 50f, 130f };
                table3.TotalWidth = 530f;
                table3.LockedWidth = true;
                table3.SetWidths(medidaCeldas3);

                table3.AddCell(new Phrase("Nombre:", font1));
                table3.AddCell(new Phrase(" ", font2));
                table3.AddCell(new Phrase("RFC:", font1));
                table3.AddCell(new Phrase("Información", font2));
                reportDocument.Add(table3);
                reportDocument.Add(new Paragraph(" "));

                // Tabla 4
                PdfPTable table4 = new PdfPTable(8);
                float[] medidaCeldas4 = { 60f, 60f, 60f, 60f, 60f, 60f, 60f, 70f };
                table4.SetWidths(medidaCeldas4);
                table4.TotalWidth = 530f;
                table4.HorizontalAlignment = Element.ALIGN_CENTER;
                table4.LockedWidth = true;

                table4.AddCell(new Phrase("No. Cuenta", font1));
                table4.AddCell(new Phrase("Tipo", font1));
                table4.AddCell(new Phrase("Estatus", font1));
                table4.AddCell(new Phrase("Carácter", font1));
                table4.AddCell(new Phrase("Ubicación/Sucursal", font1));
                table4.AddCell(new Phrase("Saldo", font1));
                table4.AddCell(new Phrase("Moneda", font1));
                table4.AddCell(new Phrase("Observaciones", font1));

                table4.AddCell(new Phrase("123456789", font3));
                table4.AddCell(new Phrase("Cuenta de ahorro", font3));
                table4.AddCell(new Phrase("Activa", font3));
                table4.AddCell(new Phrase("Titular", font3));
                table4.AddCell(new Phrase("Este campo es nuevo", font3));
                table4.AddCell(new Phrase("25000", font3));
                table4.AddCell(new Phrase("MXN", font3));
                table4.AddCell(new Phrase("obdservaenioasnfoa  nonofanoinaiofnoiN OIA OIAWN ", font3));

                reportDocument.Add(table4);
                reportDocument.Add(new Paragraph(" "));

                // Tabla 5
                PdfPTable table5 = new PdfPTable(8);
                float[] medidaCeldas5 = { 80f, 26f, 56f, 26f, 46f, 26f, 46f, 120f };
                table5.SetWidths(medidaCeldas5);
                table5.TotalWidth = 530f;
                table5.LockedWidth = true;

                PdfPCell cell5 = new PdfPCell(new Phrase("Documentación que se anexa (Cuenta: 123456789)", font1));
                cell5.Colspan = 8;
                cell5.HorizontalAlignment = 0; //0=Left, 1=Centre, 2=Right
                table5.AddCell(cell5);

                table5.AddCell(new Phrase("Documento", font1));
                table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" ");
                table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" ");
                table5.AddCell(new Phrase("Observaciones", font1));

                table5.AddCell(new Phrase("Estados de cuenta", font3));
                table5.AddCell(new Phrase("X", font4));
                table5.AddCell(new Phrase("Copia simple", font3));
                table5.AddCell(new Phrase("Del:", font4)); table5.AddCell(new Phrase("01/01/2015", font3));
                table5.AddCell(new Phrase("Al:", font4)); table5.AddCell(new Phrase("31/01/2015", font3));
                table5.AddCell(new Phrase("OBAOIFNAOISOANF ASDNFO", font3));

                table5.AddCell(new Phrase("Identificación oficial", font3)); table5.AddCell(new Phrase("X", font4)); table5.AddCell(new Phrase("Copia Simple", font3));
                table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" ");
                table5.AddCell(new Phrase("ID", font3));

                table5.AddCell(new Phrase("Contrato de apertura", font3)); table5.AddCell(new Phrase("X", font4)); table5.AddCell(new Phrase("Copia certificada", font3));
                table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" ");
                table5.AddCell(new Phrase("APER", font3));

                table5.AddCell(new Phrase("Poder notarial", font3)); table5.AddCell(new Phrase("X", font4)); table5.AddCell(new Phrase("Copia certificada", font3));
                table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" "); table5.AddCell(" ");
                table5.AddCell(new Phrase("PODER", font3));

                reportDocument.Add(table5);
                reportDocument.Add(new Paragraph(" "));

                // Tabla 6
                PdfPTable table6 = new PdfPTable(4);
                float[] medidaCeldas6 = { 132f, 26f, 132f, 240f };
                table6.SetWidths(medidaCeldas6);
                table6.TotalWidth = 530f;
                table6.LockedWidth = true;

                PdfPCell cell6 = new PdfPCell(new Phrase("Documentación de operaciones (Cuenta: 123456789)", font1));
                cell6.Colspan = 4;
                cell6.HorizontalAlignment = 0; //0=Left, 1=Centre, 2=Right
                table6.AddCell(cell6);

                table6.AddCell(new Phrase("Documento", font1));
                table6.AddCell(" "); table6.AddCell(" ");
                table6.AddCell(new Phrase("Observaciones", font1));

                table6.AddCell(new Phrase("Cheques", font3));
                table6.AddCell(new Phrase("X", font4));
                table6.AddCell(new Phrase("Copia certificada", font3));
                table6.AddCell(new Phrase("oservaciones movs elec", font3));

                table6.AddCell(new Phrase("Fichas de depósito", font3));
                table6.AddCell(new Phrase("X", font4));
                table6.AddCell(new Phrase("Copia certificada", font3));
                table6.AddCell(new Phrase("observaciones dispersión de nómia", font3));

                table6.AddCell(new Phrase("Fichas de retiro", font3));
                table6.AddCell(new Phrase("X", font4));
                table6.AddCell(new Phrase("Copia certificada", font3));
                table6.AddCell(new Phrase(" ", font3));

                table6.AddCell(new Phrase("Comprobantes", font3));
                table6.AddCell(new Phrase("X", font4));
                table6.AddCell(new Phrase("Copia simple", font3));
                table6.AddCell(new Phrase(" ", font3));

                table6.AddCell(new Phrase("Otro (especificar):  ", font3));
                table6.AddCell(new Phrase("X", font4));
                table6.AddCell(new Phrase("Copia simple", font3));
                table6.AddCell(new Phrase(" ", font3));

                reportDocument.Add(table6);
                reportDocument.Add(new Paragraph(" "));

                // Parafo 4
                Paragraph paragraph4 = new Paragraph("Se proporciona la documentación solicitada por la autoridad " +
                                                     "excepto lo señalado en el siguiente anexo al presente escrito: ", font2) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph4);
                reportDocument.Add(new Paragraph(" "));

                // Tabla 7
                PdfPTable table7 = new PdfPTable(3);
                float[] medidaCeldas7 = { 176f, 26f, 326f };
                table7.SetWidths(medidaCeldas7);
                table7.TotalWidth = 530f;
                table7.LockedWidth = true;

                PdfPCell cell7 = new PdfPCell(new Phrase("Documentación de operaciones (Cuenta: 123456789)", font1));
                cell7.Colspan = 3;
                cell7.HorizontalAlignment = 0; //0=Left, 1=Centre, 2=Right
                table7.AddCell(cell7);

                table7.AddCell(new Phrase("Documento", font1));
                table7.AddCell(" ");
                table7.AddCell(new Phrase("Observaciones", font1));

                table7.AddCell(new Phrase("Movimientos electrónicos", font3));
                table7.AddCell(new Phrase("X", font4));
                table7.AddCell(new Phrase("movimientos sadfasfa sf a", font3));

                table7.AddCell(new Phrase("Dispersión de nómina", font3));
                table7.AddCell(new Phrase("X", font4));
                table7.AddCell(new Phrase("onfonfioqn fiq fiqn fioqwn foiqwnfoqw n", font3));

                reportDocument.Add(table7);
                reportDocument.Add(new Paragraph(" "));

                // Parafo 5
                Paragraph paragraph5 = new Paragraph("Se proporciona la información solicitada por la autoridad que" +
                                                     "se señala en el siguiente anexo que acompaña al presente escrito: 1,2,3,4,5", font2) { Alignment = Element.ALIGN_LEFT };
                reportDocument.Add(paragraph5);
                reportDocument.Add(new Paragraph(" "));

                // Tabla 8
                PdfPTable table8 = new PdfPTable(1);
                table8.TotalWidth = 530f;
                table8.LockedWidth = true;

                table8.AddCell(new Phrase("Otras operaciones/observaciones", font1));
                table8.AddCell(new Phrase("Las observaciones doe pdad awfnaw0f nw´f nwq09n0wnf0wq nf09qw nf0qwnfqwnf", font2));

                reportDocument.Add(table8);
                reportDocument.Add(new Paragraph(" "));
                reportDocument.Add(new Paragraph(" "));
                reportDocument.Add(new Paragraph(" "));
                reportDocument.Add(new Paragraph(" "));

                reportDocument.Add(new Paragraph("______________________________________", font2) { Alignment = Element.ALIGN_CENTER });
                reportDocument.Add(new Paragraph("Carlos carsorio carrasco", font2) { Alignment = Element.ALIGN_CENTER });
                reportDocument.Add(new Paragraph("director de cumplimiento", font2) { Alignment = Element.ALIGN_CENTER });
                reportDocument.Add(new Paragraph("dsdasd1233", font2) { Alignment = Element.ALIGN_LEFT });

            }
            catch
            {
                reportDocument.Close();
                throw;
            }
            finally
            {
                reportDocument.Close();
            }
        }
        
    }
}
