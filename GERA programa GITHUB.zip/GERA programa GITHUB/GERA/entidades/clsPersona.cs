﻿using System;
using System.Collections.Generic;
using System.Text;

namespace document_management.entidades
{
    public class clsPersona
    {
        private String rfc, nombre;
        private List<clsCuenta> cuentaList;

        public clsPersona()
        {
            cuentaList = new List<clsCuenta>();
        }


        public List<clsCuenta> CuentaList
        {
            get { return cuentaList; }
            set { cuentaList = value; }
        }
        public String Rfc
        {
            get { return rfc; }
            set { rfc = value; }
        }
        public String Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }
    }


}
