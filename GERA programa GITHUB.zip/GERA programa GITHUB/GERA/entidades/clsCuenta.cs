﻿using System;
using System.Collections.Generic;
using System.Text;

namespace document_management.entidades
{
    public class clsCuenta
    {
        private string noCuenta, tipo, estatus, catacter, ubicacionSucursal, moneda,
            observaciones, otrasObservaciones, saldo;

        

        private clsAnexo anexo;
        private clsMovimientosElectronicos movimientosElectronicos;
        private clsOperaciones operaciones;
        private clsOperacionesOrObservaciones operacionesOrObservaciones;
        private clsDocumentacion documentacion;

        public clsCuenta()
        {

        }

        public String Observaciones
        {
            get { return observaciones; }
            set { observaciones = value; }
        }

        public String Moneda
        {
            get { return moneda; }
            set { moneda = value; }
        }

        public String UbicacionSucursal
        {
            get { return ubicacionSucursal; }
            set { ubicacionSucursal = value; }
        }

        public String Catacter
        {
            get { return catacter; }
            set { catacter = value; }
        }

        public String Tipo
        {
            get { return tipo; }
            set { tipo = value; }
        }

        public String Estatus
        {
            get { return estatus; }
            set { estatus = value; }
        }

        public String NoCuenta
        {
            get { return noCuenta; }
            set { noCuenta = value; }
        }

        public string Saldo
        {
            get { return saldo; }
            set { saldo = value; }
        }

        public clsAnexo Anexo
        {
            get { return anexo; }
            set { anexo = value; }
        }

        public clsMovimientosElectronicos MovimientosElectronicos
        {
            get { return movimientosElectronicos; }
            set { movimientosElectronicos = value; }
        }

        public clsOperacionesOrObservaciones OperacionesOrObservaciones
        {
            get { return operacionesOrObservaciones; }
            set { operacionesOrObservaciones = value; }
        }

        public clsOperaciones Operaciones
        {
            get { return operaciones; }
            set { operaciones = value; }
        }

        public clsDocumentacion Documentacion
        {
            get { return documentacion; }
            set { documentacion = value; }
        }


        public string OtrasObservaciones
        {
            get { return otrasObservaciones; }
            set { otrasObservaciones = value; }
        }
    }
}
