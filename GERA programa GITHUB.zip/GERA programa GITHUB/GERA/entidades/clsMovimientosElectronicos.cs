﻿using System;
using System.Collections.Generic;
using System.Text;

namespace document_management.entidades
{
    public class clsMovimientosElectronicos
    {

        bool movimientosElectronicos;
        string movimientosElectronicosApl;
        string movimientosElectronicosObs;

        bool dispersionNomina;
        string dispersionNominaApl;
        string dispersionNominaObs;

        bool movEInfSolicitada;
        bool movEInfSolicitadaExc;
        string movEAnexo;

        public clsMovimientosElectronicos()
        {

        }

        public bool MovimientosElectronicos
        {
            get { return movimientosElectronicos; }
            set { movimientosElectronicos = value; }
        }
        public string MovimientosElectronicosObs
        {
            get { return movimientosElectronicosObs; }
            set { movimientosElectronicosObs = value; }
        }
        public bool DispersionNomina
        {
            get { return dispersionNomina; }
            set { dispersionNomina = value; }
        }
        public string DispersionNominaObs
        {
            get { return dispersionNominaObs; }
            set { dispersionNominaObs = value; }
        }
        public bool MovEInfSolicitada
        {
            get { return movEInfSolicitada; }
            set { movEInfSolicitada = value; }
        }
        public bool MovEInfSolicitadaExc
        {
            get { return movEInfSolicitadaExc; }
            set { movEInfSolicitadaExc = value; }
        }
        public string MovEAnexo
        {
            get { return movEAnexo; }
            set { movEAnexo = value; }
        }
        public string MovimientosElectronicosApl
        {
            get { return movimientosElectronicosApl; }
            set { movimientosElectronicosApl = value; }
        }
        public string DispersionNominaApl
        {
            get { return dispersionNominaApl; }
            set { dispersionNominaApl = value; }
        }
    }
}
