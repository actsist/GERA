﻿using System;
using System.Collections.Generic;
using System.Text;

namespace document_management.entidades
{
    public class clsDocumentacion
    {
        bool estadoCuenta;
        string estadoCuentaApl;
        bool estadoCuentaCs;
        bool estadoCuentaCc;
        string estadoCuentaObs;
        DateTime estadoCuentaDesde;
        DateTime estadoCuentaHasta;

        bool identificacionOficial;
        string identificacionOficialApl;
        bool identificacionOficialCs;
        bool identificacionOficialCc;
        string identificacionOficialObs;

        bool contratoApertura;
        string contratoAperturaApl;
        bool contratoAperturaCs;
        bool contratoAperturaCc;
        string contratoAperturaObs;

        bool poderNotarial;
        string poderNotarialApl;
        bool poderNotarialCs;
        bool poderNotarialCc;
        string poderNotarialObs;

        bool comprobanteDomicilio;
        string comprobanteDomicilioApl;
        bool comprobanteDomicilioCs;
        bool comprobanteDomicilioCc;
        string comprobanteDomicilioObs;

        bool tarjetaFirmas;
        string tarjetaFirmasApl;
        bool tarjetaFirmasCs;
        bool tarjetaFirmasCc;
        string tarjetaFirmasObs;

        public clsDocumentacion()
        {
                
        }


        public bool TarjetaFirmas
        {
            get { return tarjetaFirmas; }
            set { tarjetaFirmas = value; }
        }
        public string TarjetaFirmasObs
        {
            get { return tarjetaFirmasObs; }
            set { tarjetaFirmasObs = value; }
        }
        public bool ComprobanteDomicilio
        {
            get { return comprobanteDomicilio; }
            set { comprobanteDomicilio = value; }
        }
        public string ComprobanteDomicilioObs
        {
            get { return comprobanteDomicilioObs; }
            set { comprobanteDomicilioObs = value; }
        }
        public bool EstadoCuenta
        {
            get { return estadoCuenta; }
            set { estadoCuenta = value; }
        }
        public string EstadoCuentaObs
        {
            get { return estadoCuentaObs; }
            set { estadoCuentaObs = value; }
        }
        public DateTime EstadoCuentaHasta
        {
            get { return estadoCuentaHasta; }
            set { estadoCuentaHasta = value; }
        }
        public DateTime EstadoCuentaDesde
        {
            get { return estadoCuentaDesde; }
            set { estadoCuentaDesde = value; }
        }
        public string IdentificacionOficialObs
        {
            get { return identificacionOficialObs; }
            set { identificacionOficialObs = value; }
        }
        public bool IdentificacionOficial
        {
            get { return identificacionOficial; }
            set { identificacionOficial = value; }
        }
        public bool ContratoApertura
        {
            get { return contratoApertura; }
            set { contratoApertura = value; }
        }
        public string PoderNotarialObs
        {
            get { return poderNotarialObs; }
            set { poderNotarialObs = value; }
        }
        public bool PoderNotarial
        {
            get { return poderNotarial; }
            set { poderNotarial = value; }
        }
        public string ContratoAperturaObs
        {
            get { return contratoAperturaObs; }
            set { contratoAperturaObs = value; }
        }
        public string EstadoCuentaApl
        {
            get { return estadoCuentaApl; }
            set { estadoCuentaApl = value; }
        }
        public string IdentificacionOficialApl
        {
            get { return identificacionOficialApl; }
            set { identificacionOficialApl = value; }
        }
        public string ContratoAperturaApl
        {
            get { return contratoAperturaApl; }
            set { contratoAperturaApl = value; }
        }
        public string PoderNotarialApl
        {
            get { return poderNotarialApl; }
            set { poderNotarialApl = value; }
        }
        public string ComprobanteDomicilioApl
        {
            get { return comprobanteDomicilioApl; }
            set { comprobanteDomicilioApl = value; }
        }
        public string TarjetaFirmasApl
        {
            get { return tarjetaFirmasApl; }
            set { tarjetaFirmasApl = value; }
        }
        public bool IdentificacionOficialCs
        {
            get { return identificacionOficialCs; }
            set { identificacionOficialCs = value; }
        }
        public bool IdentificacionOficialCc
        {
            get { return identificacionOficialCc; }
            set { identificacionOficialCc = value; }
        }
        public bool EstadoCuentaCs
        {
            get { return estadoCuentaCs; }
            set { estadoCuentaCs = value; }
        }
        public bool EstadoCuentaCc
        {
            get { return estadoCuentaCc; }
            set { estadoCuentaCc = value; }
        }
        public bool ContratoAperturaCs
        {
            get { return contratoAperturaCs; }
            set { contratoAperturaCs = value; }
        }
        public bool ContratoAperturaCc
        {
            get { return contratoAperturaCc; }
            set { contratoAperturaCc = value; }
        }
        public bool PoderNotarialCs
        {
            get { return poderNotarialCs; }
            set { poderNotarialCs = value; }
        }
        public bool PoderNotarialCc
        {
            get { return poderNotarialCc; }
            set { poderNotarialCc = value; }
        }
        public bool ComprobanteDomicilioCs
        {
            get { return comprobanteDomicilioCs; }
            set { comprobanteDomicilioCs = value; }
        }
        public bool ComprobanteDomicilioCc
        {
            get { return comprobanteDomicilioCc; }
            set { comprobanteDomicilioCc = value; }
        }
        public bool TarjetaFirmasCs
        {
            get { return tarjetaFirmasCs; }
            set { tarjetaFirmasCs = value; }
        }
        public bool TarjetaFirmasCc
        {
            get { return tarjetaFirmasCc; }
            set { tarjetaFirmasCc = value; }
        }
    }
}
