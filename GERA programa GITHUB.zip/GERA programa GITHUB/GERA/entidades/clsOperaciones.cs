﻿using System;
using System.Collections.Generic;
using System.Text;

namespace document_management.entidades
{
    public class clsOperaciones
    {

        private bool cheques;
        private string chequesApl;
        private bool chequesCs;
        private bool chequesCc;
        private string chequesObs;

        private bool fichaDeposito;
        private string fichaDepositoApl;
        private bool fichaDepositoCs;
        private bool fichaDepositoCc;
        private string fichaDepositoObs;
        
        private bool fichaRetiro;
        private string fichaRetiroApl;
        private bool fichaRetiroCs;
        private bool fichaRetiroCc;
        private string fichaRetiroObs;

        private bool comprobantes;
        private string comprobantesApl;
        private bool comprobantesCs;
        private bool comprobantesCc;
        private string comprobantesObs;

        private bool otros;
        private string otrosApl;
        private bool otrosCs;
        private bool otrosCc;
        private string otrosObs;
        private string otrosEspecifica;

        private bool infSolicitada; 
        private string infSolicitadaApl;
        private bool infSolicitadaExc;
        private bool infSolicitadaForPar;      
        private bool infSolicitadaAnex;        
        private string infSolicitadaAnexo;

        public clsOperaciones()
        {

        }


        public bool Cheques
        {
            get { return cheques; }
            set { cheques = value; }
        }
        public bool ChequesCs
        {
            get { return chequesCs; }
            set { chequesCs = value; }
        }
        public string ChequesObs
        {
            get { return chequesObs; }
            set { chequesObs = value; }
        }
        public string FichaDepositoObs
        {
            get { return fichaDepositoObs; }
            set { fichaDepositoObs = value; }
        }
        public bool FichaDepositoCs
        {
            get { return fichaDepositoCs; }
            set { fichaDepositoCs = value; }
        }
        public bool FichaDeposito
        {
            get { return fichaDeposito; }
            set { fichaDeposito = value; }
        }
        public bool FichaRetiro
        {
            get { return fichaRetiro; }
            set { fichaRetiro = value; }
        }
        public bool FichaRetiroCs
        {
            get { return fichaRetiroCs; }
            set { fichaRetiroCs = value; }
        }
        public string FichaRetiroObs
        {
            get { return fichaRetiroObs; }
            set { fichaRetiroObs = value; }
        }
        public bool Comprobantes
        {
            get { return comprobantes; }
            set { comprobantes = value; }
        }
        public bool ComprobantesCs
        {
            get { return comprobantesCs; }
            set { comprobantesCs = value; }
        }
        public string ComprobantesObs
        {
            get { return comprobantesObs; }
            set { comprobantesObs = value; }
        }
        public bool Otros
        {
            get { return otros; }
            set { otros = value; }
        }
        public bool OtrosCs
        {
            get { return otrosCs; }
            set { otrosCs = value; }
        }
        public string OtrosObs
        {
            get { return otrosObs; }
            set { otrosObs = value; }
        }
        public string OtrosEspecifica
        {
            get { return otrosEspecifica; }
            set { otrosEspecifica = value; }
        }
        public bool InfSolicitada
        {
            get { return infSolicitada; }
            set { infSolicitada = value; }
        }
        public bool InfSolicitadaExc
        {
            get { return infSolicitadaExc; }
            set { infSolicitadaExc = value; }
        }
        public string InfSolicitadaAnexo
        {
            get { return infSolicitadaAnexo; }
            set { infSolicitadaAnexo = value; }
        }
        public string ChequesApl
        {
            get { return chequesApl; }
            set { chequesApl = value; }
        }
        public string FichaDepositoApl
        {
            get { return fichaDepositoApl; }
            set { fichaDepositoApl = value; }
        }
        public string FichaRetiroApl
        {
            get { return fichaRetiroApl; }
            set { fichaRetiroApl = value; }
        }
        public string ComprobantesApl
        {
            get { return comprobantesApl; }
            set { comprobantesApl = value; }
        }
        public string OtrosApl
        {
            get { return otrosApl; }
            set { otrosApl = value; }
        }
        public string InfSolicitadaApl
        {
            get { return infSolicitadaApl; }
            set { infSolicitadaApl = value; }
        }
        public bool ChequesCc
        {
            get { return chequesCc; }
            set { chequesCc = value; }
        }
        public bool FichaDepositoCc
        {
            get { return fichaDepositoCc; }
            set { fichaDepositoCc = value; }
        }
        public bool FichaRetiroCc
        {
            get { return fichaRetiroCc; }
            set { fichaRetiroCc = value; }
        }
        public bool ComprobantesCc
        {
            get { return comprobantesCc; }
            set { comprobantesCc = value; }
        }
        public bool OtrosCc
        {
            get { return otrosCc; }
            set { otrosCc = value; }
        }

        public bool InfSolicitadaAnex
        {
            get { return infSolicitadaAnex; }
            set { infSolicitadaAnex = value; }
        }

        public bool InfSolicitadaForPar
        {
            get { return infSolicitadaForPar; }
            set { infSolicitadaForPar = value; }
        }
    }
}
