﻿using System;
using System.Collections.Generic;
using System.Text;

namespace document_management
{
    public class clsOperacionesOrObservaciones
    {
        private String operacionOrObservacion;
        
        public clsOperacionesOrObservaciones(String operacionOrObservacion)
        {
            this.operacionOrObservacion = operacionOrObservacion;
        }
        
        // PROPIEDADES ----------------------------------------------------
        public String OperacionOrObservacion
        {
            get { return operacionOrObservacion; }
            set { operacionOrObservacion = value; }
        }
    }
}
