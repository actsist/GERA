﻿using System;
using System.Collections.Generic;
using System.Text;

namespace document_management.entidades
{
    public class clsDocumento
    {
        List<clsPersona> listPersonas;

        private string fecha, oficio, expediente, folio, autoridadSolicitante , dirigidoDGA;
        private string respuestaRequerimiento, asunto;
        private string atencion;
        private string firmante, controlInterno, puesto;
        private string observaciones;

        public string Observaciones
        {
            get { return observaciones; }
            set { observaciones = value; }
        }

        public clsDocumento()
        {
            observaciones = "";
        }

        public string Puesto
        {
            get { return puesto; }
            set { puesto = value; }
        }

        public string ControlInterno
        {
            get { return controlInterno; }
            set { controlInterno = value; }
        }

        public string Firmante
        {
            get { return firmante; }
            set { firmante = value; }
        }

        public string Atencion
        {
            get { return atencion; }
            set { atencion = value; }
        }

        public string Asunto
        {
            get { return asunto; }
            set { asunto = value; }
        }

        public string RespuestaRequerimiento
        {
            get { return respuestaRequerimiento; }
            set { respuestaRequerimiento = value; }
        }
        public string DirigidoDGA
        {
            get {
                if (dirigidoDGA == "Coordinación A aseguramientos")
                    return "Coordinación de Atención a Autoridades \"A\"";
                else if (dirigidoDGA == "Coordinación B judiciales")
                    return "Coordinación de Atención a Autoridades \"B\"";
                else if (dirigidoDGA == "Coordinación C hacendarios")
                    return "Coordinación de Atención a Autoridades \"C\"";
                else if (dirigidoDGA == "Coordinación D operaciones especiales")
                    return "Coordinación de Atención a Autoridades \"D\"";
                return "";
            }
            set { dirigidoDGA = value; }
        }
        public string DirigidoA
        {
            get
            {
                if (dirigidoDGA == "Coordinación A aseguramientos")
                    return "Dr. Jorge Alfredo Ramírez Talamantes";
                else if (dirigidoDGA == "Coordinación B judiciales")
                    return "Mtro. Humberto Rios Ruíz";
                else if (dirigidoDGA == "Coordinación C hacendarios")
                    return "Lic. Lucila Saúl Hernández";
                else if (dirigidoDGA == "Coordinación D operaciones especiales")
                    return "Lic. Ana Lilia Chávez Maldonado";
                return "";
            }
            set { DirigidoA = value; }
        }
        public string Folio
        {
            get { return folio; }
            set { folio = value; }
        }

        public string Expediente
        {
            get { return expediente; }
            set { expediente = value; }
        }

        public string Oficio
        {
            get { return oficio; }
            set { oficio = value; }
        }

        public string Fecha
        {
            get { return fecha; }
            set { fecha = value; }
        }

        public string AutoridadSolicitante
        {
            get { return autoridadSolicitante; }
            set { autoridadSolicitante = value; }
        }

        public List<clsPersona> ListPersonas
        {
            get { return listPersonas; }
            set { listPersonas = value; }
        }

    }
}
