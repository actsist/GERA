﻿using System;
using System.Collections.Generic;
using System.Text;

namespace document_management.entidades
{
    public class clsAnexo
    {
        private String documento, copia, observacion, desde, hasta;

        public clsAnexo(String documento, String copia, String observacion, String desde, String hasta)
        {
            this.documento = documento;
            this.copia = copia;
            this.observacion = observacion;
            this.desde = desde;
            this.hasta = hasta;
        }

        // PROPIEDADES -----------------------------------
        public String Observacion
        {
            get { return observacion; }
            set { observacion = value; }
        }

        public String Copia
        {
            get { return copia; }
            set { copia = value; }
        }

        public String Documento
        {
            get { return documento; }
            set { documento = value; }
        }

        public String Hasta
        {
            get { return hasta; }
            set { hasta = value; }
        }

        public String Desde
        {
            get { return desde; }
            set { desde = value; }
        }
    }
}
