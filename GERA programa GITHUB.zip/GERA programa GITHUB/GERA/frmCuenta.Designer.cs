﻿namespace document_management
{
    partial class frmCuenta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCuenta));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCuenta = new System.Windows.Forms.TextBox();
            this.txtSaldo = new System.Windows.Forms.TextBox();
            this.cbxTipo = new System.Windows.Forms.ComboBox();
            this.cbxCaracter = new System.Windows.Forms.ComboBox();
            this.cbxEstatus = new System.Windows.Forms.ComboBox();
            this.cbxMoneda = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.btnRegresar = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.pnlDocumentacion = new System.Windows.Forms.Panel();
            this.cbTarjetaFirmas = new System.Windows.Forms.CheckBox();
            this.cbComprobanteDomicilio = new System.Windows.Forms.CheckBox();
            this.pnlDocumentacion6 = new System.Windows.Forms.Panel();
            this.txtTarjetaFirmasObs = new System.Windows.Forms.RichTextBox();
            this.cbTarjetaFirmasApl = new System.Windows.Forms.ComboBox();
            this.rbtnTarjetaFirmasCc = new System.Windows.Forms.RadioButton();
            this.rbtnTarjetaFirmasCs = new System.Windows.Forms.RadioButton();
            this.pnlDocumentacion5 = new System.Windows.Forms.Panel();
            this.cbComprobanteDomicilioApl = new System.Windows.Forms.ComboBox();
            this.txtComprobanteDomicilioObs = new System.Windows.Forms.RichTextBox();
            this.rbtnComprobanteDomicilioCc = new System.Windows.Forms.RadioButton();
            this.rbtnComprobanteDomicilioCs = new System.Windows.Forms.RadioButton();
            this.dtpEDCHasta = new System.Windows.Forms.DateTimePicker();
            this.cbPoderNotarial = new System.Windows.Forms.CheckBox();
            this.dtpEDCDesde = new System.Windows.Forms.DateTimePicker();
            this.cbContratoApertura = new System.Windows.Forms.CheckBox();
            this.cbIdentificacionOficial = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.pnlDocumentacion4 = new System.Windows.Forms.Panel();
            this.cbPoderNotarialApl = new System.Windows.Forms.ComboBox();
            this.rbtnPoderNotarialCC = new System.Windows.Forms.RadioButton();
            this.txtPoderNotarialObs = new System.Windows.Forms.RichTextBox();
            this.rbtnPoderNotarialCS = new System.Windows.Forms.RadioButton();
            this.label10 = new System.Windows.Forms.Label();
            this.cbxEstadoCuenta = new System.Windows.Forms.CheckBox();
            this.pnlDocumentacion1 = new System.Windows.Forms.Panel();
            this.cbxEstadoCuentaApl = new System.Windows.Forms.ComboBox();
            this.rbtnEstadosCuentaCC = new System.Windows.Forms.RadioButton();
            this.rbtnEstadoCuentaCS = new System.Windows.Forms.RadioButton();
            this.txtEstadosCuentaObs = new System.Windows.Forms.RichTextBox();
            this.pnlDocumentacion3 = new System.Windows.Forms.Panel();
            this.cbContratoAperturaApl = new System.Windows.Forms.ComboBox();
            this.rbtnContratoAperturaCS = new System.Windows.Forms.RadioButton();
            this.rbtnContratoAperturaCC = new System.Windows.Forms.RadioButton();
            this.txtContratoAperturaObs = new System.Windows.Forms.RichTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.pnlDocumentacion2 = new System.Windows.Forms.Panel();
            this.cbIdentificacionOficialApl = new System.Windows.Forms.ComboBox();
            this.rbtnIdentificacionOficialCS = new System.Windows.Forms.RadioButton();
            this.rbtnIdentificacionOficialCC = new System.Windows.Forms.RadioButton();
            this.txtIdentificacionOficialObs = new System.Windows.Forms.RichTextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cbDocumentacion = new System.Windows.Forms.CheckBox();
            this.label16 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.pnlDocumentacionOper = new System.Windows.Forms.Panel();
            this.rbtnInfSolicitadaForPar = new System.Windows.Forms.RadioButton();
            this.rbtnInfSolicitadaAnex = new System.Windows.Forms.RadioButton();
            this.txtEspecifica = new System.Windows.Forms.TextBox();
            this.cbOtro = new System.Windows.Forms.CheckBox();
            this.cbFichasRetiro = new System.Windows.Forms.CheckBox();
            this.label13 = new System.Windows.Forms.Label();
            this.cbFichasDeposito = new System.Windows.Forms.CheckBox();
            this.cbComprobantes = new System.Windows.Forms.CheckBox();
            this.cbCheques = new System.Windows.Forms.CheckBox();
            this.pnlDocumentacionOper5 = new System.Windows.Forms.Panel();
            this.txtOtroObs = new System.Windows.Forms.RichTextBox();
            this.cbOtroApl = new System.Windows.Forms.ComboBox();
            this.rbtnOtroCS = new System.Windows.Forms.RadioButton();
            this.rbtnOtroCC = new System.Windows.Forms.RadioButton();
            this.pnlDocumentacionOper1 = new System.Windows.Forms.Panel();
            this.txtChequesObs = new System.Windows.Forms.RichTextBox();
            this.cbChequesApl = new System.Windows.Forms.ComboBox();
            this.rbtnChequesCC = new System.Windows.Forms.RadioButton();
            this.rbtnChequesCS = new System.Windows.Forms.RadioButton();
            this.pnlDocumentacionOper4 = new System.Windows.Forms.Panel();
            this.cbComprobantesApl = new System.Windows.Forms.ComboBox();
            this.txtComprobantesObs = new System.Windows.Forms.RichTextBox();
            this.rbtnComprobantesCC = new System.Windows.Forms.RadioButton();
            this.rbtnComprobantesCS = new System.Windows.Forms.RadioButton();
            this.label12 = new System.Windows.Forms.Label();
            this.pnlDocumentacionOper3 = new System.Windows.Forms.Panel();
            this.cbFichasRetiroApl = new System.Windows.Forms.ComboBox();
            this.rbtnFichasRetiroCC = new System.Windows.Forms.RadioButton();
            this.txtFichasRetiroObs = new System.Windows.Forms.RichTextBox();
            this.rbtnFichasRetiroCS = new System.Windows.Forms.RadioButton();
            this.pnlDocumentacionOper2 = new System.Windows.Forms.Panel();
            this.cbFichasDepositoApl = new System.Windows.Forms.ComboBox();
            this.rbtnFichasDepositoCC = new System.Windows.Forms.RadioButton();
            this.rbtnFichasDepositoCS = new System.Windows.Forms.RadioButton();
            this.txtFichasDepositoObs = new System.Windows.Forms.RichTextBox();
            this.rbtnInfSolicitada = new System.Windows.Forms.RadioButton();
            this.rbtnInfSolicitadaExc = new System.Windows.Forms.RadioButton();
            this.label11 = new System.Windows.Forms.Label();
            this.txtAnexo = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cbDocumentacionOper = new System.Windows.Forms.CheckBox();
            this.label17 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.pnlMovimientoElec = new System.Windows.Forms.Panel();
            this.txtDispersionNominaObs = new System.Windows.Forms.RichTextBox();
            this.txtMovElectronicosObs = new System.Windows.Forms.RichTextBox();
            this.cbDispersionNominaApl = new System.Windows.Forms.ComboBox();
            this.cbMovElectronicosApl = new System.Windows.Forms.ComboBox();
            this.cbMovElectronicos = new System.Windows.Forms.CheckBox();
            this.txtMovEAnexo = new System.Windows.Forms.TextBox();
            this.cbDispersionNomina = new System.Windows.Forms.CheckBox();
            this.label15 = new System.Windows.Forms.Label();
            this.rbtnMovEInfSolicitada = new System.Windows.Forms.RadioButton();
            this.label14 = new System.Windows.Forms.Label();
            this.rbtnMovEInfSolicitadaExc = new System.Windows.Forms.RadioButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.cbMovimientosElec = new System.Windows.Forms.CheckBox();
            this.label18 = new System.Windows.Forms.Label();
            this.cbxPersona = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txtUbicacionOrSucursal = new System.Windows.Forms.TextBox();
            this.taObservaciones = new System.Windows.Forms.RichTextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.pnlDocumentacion.SuspendLayout();
            this.pnlDocumentacion6.SuspendLayout();
            this.pnlDocumentacion5.SuspendLayout();
            this.pnlDocumentacion4.SuspendLayout();
            this.pnlDocumentacion1.SuspendLayout();
            this.pnlDocumentacion3.SuspendLayout();
            this.pnlDocumentacion2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.pnlDocumentacionOper.SuspendLayout();
            this.pnlDocumentacionOper5.SuspendLayout();
            this.pnlDocumentacionOper1.SuspendLayout();
            this.pnlDocumentacionOper4.SuspendLayout();
            this.pnlDocumentacionOper3.SuspendLayout();
            this.pnlDocumentacionOper2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.pnlMovimientoElec.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cuenta:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tipo:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Estatus:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 141);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Carácter:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(340, 60);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Saldo:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(340, 87);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Moneda:";
            // 
            // txtCuenta
            // 
            this.txtCuenta.Location = new System.Drawing.Point(124, 58);
            this.txtCuenta.Name = "txtCuenta";
            this.txtCuenta.Size = new System.Drawing.Size(196, 20);
            this.txtCuenta.TabIndex = 1;
            // 
            // txtSaldo
            // 
            this.txtSaldo.Location = new System.Drawing.Point(453, 57);
            this.txtSaldo.Name = "txtSaldo";
            this.txtSaldo.Size = new System.Drawing.Size(196, 20);
            this.txtSaldo.TabIndex = 5;
            this.txtSaldo.Leave += new System.EventHandler(this.txtSaldo_Leave);
            // 
            // cbxTipo
            // 
            this.cbxTipo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxTipo.FormattingEnabled = true;
            this.cbxTipo.Items.AddRange(new object[] {
            "<Seleccione>",
            "Cuenta de ahorro",
            "Cuenta de cheques",
            "Cuenta de nómina",
            "Tarjeta de crédito",
            "Inversión",
            "Crédito",
            "Contrato de afiliación",
            "Contrato de intermediación bursátil",
            "Deals",
            "Otros"});
            this.cbxTipo.Location = new System.Drawing.Point(124, 84);
            this.cbxTipo.Name = "cbxTipo";
            this.cbxTipo.Size = new System.Drawing.Size(196, 21);
            this.cbxTipo.TabIndex = 2;
            // 
            // cbxCaracter
            // 
            this.cbxCaracter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxCaracter.FormattingEnabled = true;
            this.cbxCaracter.Items.AddRange(new object[] {
            "<Seleccione>",
            "Titular",
            "Cotitular",
            "Beneficiario",
            "Autorizado",
            "Firmante",
            "Representante",
            "Usuario",
            "Cliente",
            "Fideicomitente",
            "Fideicomisario",
            "Socio"});
            this.cbxCaracter.Location = new System.Drawing.Point(124, 138);
            this.cbxCaracter.Name = "cbxCaracter";
            this.cbxCaracter.Size = new System.Drawing.Size(196, 21);
            this.cbxCaracter.TabIndex = 4;
            // 
            // cbxEstatus
            // 
            this.cbxEstatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxEstatus.FormattingEnabled = true;
            this.cbxEstatus.Items.AddRange(new object[] {
            "<Seleccione>",
            "Activa",
            "Cancelada",
            "Cerrada",
            "Bloqueada"});
            this.cbxEstatus.Location = new System.Drawing.Point(124, 111);
            this.cbxEstatus.Name = "cbxEstatus";
            this.cbxEstatus.Size = new System.Drawing.Size(196, 21);
            this.cbxEstatus.TabIndex = 3;
            // 
            // cbxMoneda
            // 
            this.cbxMoneda.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxMoneda.FormattingEnabled = true;
            this.cbxMoneda.Items.AddRange(new object[] {
            "<Seleccione>",
            "MXN",
            "USD",
            "EUR"});
            this.cbxMoneda.Location = new System.Drawing.Point(453, 84);
            this.cbxMoneda.Name = "cbxMoneda";
            this.cbxMoneda.Size = new System.Drawing.Size(196, 21);
            this.cbxMoneda.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(11, 168);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Observaciones:";
            // 
            // btnAceptar
            // 
            this.btnAceptar.Location = new System.Drawing.Point(535, 669);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(75, 23);
            this.btnAceptar.TabIndex = 9;
            this.btnAceptar.Text = "Aceptar";
            this.btnAceptar.UseVisualStyleBackColor = true;
            this.btnAceptar.Click += new System.EventHandler(this.btnAceptar_Click);
            // 
            // btnRegresar
            // 
            this.btnRegresar.Location = new System.Drawing.Point(616, 669);
            this.btnRegresar.Name = "btnRegresar";
            this.btnRegresar.Size = new System.Drawing.Size(75, 23);
            this.btnRegresar.TabIndex = 10;
            this.btnRegresar.Text = "Salir";
            this.btnRegresar.UseVisualStyleBackColor = true;
            this.btnRegresar.Click += new System.EventHandler(this.btnRegresar_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(10, 228);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(681, 435);
            this.tabControl1.TabIndex = 8;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.pnlDocumentacion);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(673, 409);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Documentacion";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // pnlDocumentacion
            // 
            this.pnlDocumentacion.BackColor = System.Drawing.Color.Transparent;
            this.pnlDocumentacion.Controls.Add(this.cbTarjetaFirmas);
            this.pnlDocumentacion.Controls.Add(this.cbComprobanteDomicilio);
            this.pnlDocumentacion.Controls.Add(this.pnlDocumentacion6);
            this.pnlDocumentacion.Controls.Add(this.pnlDocumentacion5);
            this.pnlDocumentacion.Controls.Add(this.dtpEDCHasta);
            this.pnlDocumentacion.Controls.Add(this.cbPoderNotarial);
            this.pnlDocumentacion.Controls.Add(this.dtpEDCDesde);
            this.pnlDocumentacion.Controls.Add(this.cbContratoApertura);
            this.pnlDocumentacion.Controls.Add(this.cbIdentificacionOficial);
            this.pnlDocumentacion.Controls.Add(this.label9);
            this.pnlDocumentacion.Controls.Add(this.pnlDocumentacion4);
            this.pnlDocumentacion.Controls.Add(this.label10);
            this.pnlDocumentacion.Controls.Add(this.cbxEstadoCuenta);
            this.pnlDocumentacion.Controls.Add(this.pnlDocumentacion1);
            this.pnlDocumentacion.Controls.Add(this.pnlDocumentacion3);
            this.pnlDocumentacion.Controls.Add(this.label8);
            this.pnlDocumentacion.Controls.Add(this.pnlDocumentacion2);
            this.pnlDocumentacion.Enabled = false;
            this.pnlDocumentacion.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pnlDocumentacion.Location = new System.Drawing.Point(6, 36);
            this.pnlDocumentacion.Name = "pnlDocumentacion";
            this.pnlDocumentacion.Size = new System.Drawing.Size(667, 342);
            this.pnlDocumentacion.TabIndex = 22;
            this.pnlDocumentacion.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlDocumentacion_Paint);
            // 
            // cbTarjetaFirmas
            // 
            this.cbTarjetaFirmas.AutoSize = true;
            this.cbTarjetaFirmas.Location = new System.Drawing.Point(6, 297);
            this.cbTarjetaFirmas.Name = "cbTarjetaFirmas";
            this.cbTarjetaFirmas.Size = new System.Drawing.Size(104, 17);
            this.cbTarjetaFirmas.TabIndex = 49;
            this.cbTarjetaFirmas.Text = "Tarjeta de firmas";
            this.cbTarjetaFirmas.UseVisualStyleBackColor = true;
            this.cbTarjetaFirmas.CheckedChanged += new System.EventHandler(this.cbTarjetaFirmas_CheckedChanged);
            // 
            // cbComprobanteDomicilio
            // 
            this.cbComprobanteDomicilio.AutoSize = true;
            this.cbComprobanteDomicilio.Location = new System.Drawing.Point(6, 243);
            this.cbComprobanteDomicilio.Name = "cbComprobanteDomicilio";
            this.cbComprobanteDomicilio.Size = new System.Drawing.Size(147, 17);
            this.cbComprobanteDomicilio.TabIndex = 47;
            this.cbComprobanteDomicilio.Text = "Comprobante de domicilio";
            this.cbComprobanteDomicilio.UseVisualStyleBackColor = true;
            this.cbComprobanteDomicilio.CheckedChanged += new System.EventHandler(this.cbComprobanteDomicilio_CheckedChanged);
            // 
            // pnlDocumentacion6
            // 
            this.pnlDocumentacion6.Controls.Add(this.txtTarjetaFirmasObs);
            this.pnlDocumentacion6.Controls.Add(this.cbTarjetaFirmasApl);
            this.pnlDocumentacion6.Controls.Add(this.rbtnTarjetaFirmasCc);
            this.pnlDocumentacion6.Controls.Add(this.rbtnTarjetaFirmasCs);
            this.pnlDocumentacion6.Enabled = false;
            this.pnlDocumentacion6.Location = new System.Drawing.Point(150, 292);
            this.pnlDocumentacion6.Name = "pnlDocumentacion6";
            this.pnlDocumentacion6.Size = new System.Drawing.Size(514, 51);
            this.pnlDocumentacion6.TabIndex = 50;
            // 
            // txtTarjetaFirmasObs
            // 
            this.txtTarjetaFirmasObs.Location = new System.Drawing.Point(278, 3);
            this.txtTarjetaFirmasObs.Name = "txtTarjetaFirmasObs";
            this.txtTarjetaFirmasObs.Size = new System.Drawing.Size(231, 45);
            this.txtTarjetaFirmasObs.TabIndex = 33;
            this.txtTarjetaFirmasObs.Text = "";
            // 
            // cbTarjetaFirmasApl
            // 
            this.cbTarjetaFirmasApl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTarjetaFirmasApl.FormattingEnabled = true;
            this.cbTarjetaFirmasApl.Items.AddRange(new object[] {
            "Si",
            "No"});
            this.cbTarjetaFirmasApl.Location = new System.Drawing.Point(3, 3);
            this.cbTarjetaFirmasApl.Name = "cbTarjetaFirmasApl";
            this.cbTarjetaFirmasApl.Size = new System.Drawing.Size(68, 21);
            this.cbTarjetaFirmasApl.TabIndex = 56;
            this.cbTarjetaFirmasApl.SelectedIndexChanged += new System.EventHandler(this.cbTarjetaFirmasApl_SelectedIndexChanged);
            // 
            // rbtnTarjetaFirmasCc
            // 
            this.rbtnTarjetaFirmasCc.AutoSize = true;
            this.rbtnTarjetaFirmasCc.Location = new System.Drawing.Point(168, 4);
            this.rbtnTarjetaFirmasCc.Name = "rbtnTarjetaFirmasCc";
            this.rbtnTarjetaFirmasCc.Size = new System.Drawing.Size(104, 17);
            this.rbtnTarjetaFirmasCc.TabIndex = 18;
            this.rbtnTarjetaFirmasCc.Text = "Copia certificada";
            this.rbtnTarjetaFirmasCc.UseVisualStyleBackColor = true;
            // 
            // rbtnTarjetaFirmasCs
            // 
            this.rbtnTarjetaFirmasCs.AutoSize = true;
            this.rbtnTarjetaFirmasCs.Location = new System.Drawing.Point(81, 4);
            this.rbtnTarjetaFirmasCs.Name = "rbtnTarjetaFirmasCs";
            this.rbtnTarjetaFirmasCs.Size = new System.Drawing.Size(84, 17);
            this.rbtnTarjetaFirmasCs.TabIndex = 17;
            this.rbtnTarjetaFirmasCs.Text = "Copia simple";
            this.rbtnTarjetaFirmasCs.UseVisualStyleBackColor = true;
            // 
            // pnlDocumentacion5
            // 
            this.pnlDocumentacion5.Controls.Add(this.cbComprobanteDomicilioApl);
            this.pnlDocumentacion5.Controls.Add(this.txtComprobanteDomicilioObs);
            this.pnlDocumentacion5.Controls.Add(this.rbtnComprobanteDomicilioCc);
            this.pnlDocumentacion5.Controls.Add(this.rbtnComprobanteDomicilioCs);
            this.pnlDocumentacion5.Enabled = false;
            this.pnlDocumentacion5.Location = new System.Drawing.Point(150, 238);
            this.pnlDocumentacion5.Name = "pnlDocumentacion5";
            this.pnlDocumentacion5.Size = new System.Drawing.Size(514, 51);
            this.pnlDocumentacion5.TabIndex = 48;
            // 
            // cbComprobanteDomicilioApl
            // 
            this.cbComprobanteDomicilioApl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbComprobanteDomicilioApl.FormattingEnabled = true;
            this.cbComprobanteDomicilioApl.Items.AddRange(new object[] {
            "Si",
            "No"});
            this.cbComprobanteDomicilioApl.Location = new System.Drawing.Point(3, 3);
            this.cbComprobanteDomicilioApl.Name = "cbComprobanteDomicilioApl";
            this.cbComprobanteDomicilioApl.Size = new System.Drawing.Size(68, 21);
            this.cbComprobanteDomicilioApl.TabIndex = 55;
            this.cbComprobanteDomicilioApl.SelectedIndexChanged += new System.EventHandler(this.cbComprobanteDomicilioApl_SelectedIndexChanged);
            // 
            // txtComprobanteDomicilioObs
            // 
            this.txtComprobanteDomicilioObs.Location = new System.Drawing.Point(278, 3);
            this.txtComprobanteDomicilioObs.Name = "txtComprobanteDomicilioObs";
            this.txtComprobanteDomicilioObs.Size = new System.Drawing.Size(231, 45);
            this.txtComprobanteDomicilioObs.TabIndex = 32;
            this.txtComprobanteDomicilioObs.Text = "";
            // 
            // rbtnComprobanteDomicilioCc
            // 
            this.rbtnComprobanteDomicilioCc.AutoSize = true;
            this.rbtnComprobanteDomicilioCc.Location = new System.Drawing.Point(168, 4);
            this.rbtnComprobanteDomicilioCc.Name = "rbtnComprobanteDomicilioCc";
            this.rbtnComprobanteDomicilioCc.Size = new System.Drawing.Size(104, 17);
            this.rbtnComprobanteDomicilioCc.TabIndex = 18;
            this.rbtnComprobanteDomicilioCc.Text = "Copia certificada";
            this.rbtnComprobanteDomicilioCc.UseVisualStyleBackColor = true;
            // 
            // rbtnComprobanteDomicilioCs
            // 
            this.rbtnComprobanteDomicilioCs.AutoSize = true;
            this.rbtnComprobanteDomicilioCs.Location = new System.Drawing.Point(81, 4);
            this.rbtnComprobanteDomicilioCs.Name = "rbtnComprobanteDomicilioCs";
            this.rbtnComprobanteDomicilioCs.Size = new System.Drawing.Size(84, 17);
            this.rbtnComprobanteDomicilioCs.TabIndex = 17;
            this.rbtnComprobanteDomicilioCs.Text = "Copia simple";
            this.rbtnComprobanteDomicilioCs.UseVisualStyleBackColor = true;
            // 
            // dtpEDCHasta
            // 
            this.dtpEDCHasta.Enabled = false;
            this.dtpEDCHasta.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpEDCHasta.Location = new System.Drawing.Point(249, 50);
            this.dtpEDCHasta.Name = "dtpEDCHasta";
            this.dtpEDCHasta.Size = new System.Drawing.Size(108, 20);
            this.dtpEDCHasta.TabIndex = 7;
            // 
            // cbPoderNotarial
            // 
            this.cbPoderNotarial.AutoSize = true;
            this.cbPoderNotarial.Location = new System.Drawing.Point(6, 189);
            this.cbPoderNotarial.Name = "cbPoderNotarial";
            this.cbPoderNotarial.Size = new System.Drawing.Size(93, 17);
            this.cbPoderNotarial.TabIndex = 16;
            this.cbPoderNotarial.Text = "Poder Notarial";
            this.cbPoderNotarial.UseVisualStyleBackColor = true;
            this.cbPoderNotarial.CheckedChanged += new System.EventHandler(this.cbPoderNotarial_CheckedChanged);
            // 
            // dtpEDCDesde
            // 
            this.dtpEDCDesde.Enabled = false;
            this.dtpEDCDesde.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpEDCDesde.Location = new System.Drawing.Point(80, 50);
            this.dtpEDCDesde.Name = "dtpEDCDesde";
            this.dtpEDCDesde.Size = new System.Drawing.Size(108, 20);
            this.dtpEDCDesde.TabIndex = 6;
            // 
            // cbContratoApertura
            // 
            this.cbContratoApertura.AutoSize = true;
            this.cbContratoApertura.Location = new System.Drawing.Point(6, 131);
            this.cbContratoApertura.Name = "cbContratoApertura";
            this.cbContratoApertura.Size = new System.Drawing.Size(123, 17);
            this.cbContratoApertura.TabIndex = 12;
            this.cbContratoApertura.Text = "Contrato de apertura";
            this.cbContratoApertura.UseVisualStyleBackColor = true;
            this.cbContratoApertura.CheckedChanged += new System.EventHandler(this.cbContratoApertura_CheckedChanged);
            // 
            // cbIdentificacionOficial
            // 
            this.cbIdentificacionOficial.AutoSize = true;
            this.cbIdentificacionOficial.Location = new System.Drawing.Point(6, 81);
            this.cbIdentificacionOficial.Name = "cbIdentificacionOficial";
            this.cbIdentificacionOficial.Size = new System.Drawing.Size(121, 17);
            this.cbIdentificacionOficial.TabIndex = 8;
            this.cbIdentificacionOficial.Text = "Identificación Oficial";
            this.cbIdentificacionOficial.UseVisualStyleBackColor = true;
            this.cbIdentificacionOficial.CheckedChanged += new System.EventHandler(this.cbIdentificacionOficial_CheckedChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(33, 53);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 13);
            this.label9.TabIndex = 34;
            this.label9.Text = "Desde:";
            // 
            // pnlDocumentacion4
            // 
            this.pnlDocumentacion4.Controls.Add(this.cbPoderNotarialApl);
            this.pnlDocumentacion4.Controls.Add(this.rbtnPoderNotarialCC);
            this.pnlDocumentacion4.Controls.Add(this.txtPoderNotarialObs);
            this.pnlDocumentacion4.Controls.Add(this.rbtnPoderNotarialCS);
            this.pnlDocumentacion4.Enabled = false;
            this.pnlDocumentacion4.Location = new System.Drawing.Point(150, 184);
            this.pnlDocumentacion4.Name = "pnlDocumentacion4";
            this.pnlDocumentacion4.Size = new System.Drawing.Size(514, 51);
            this.pnlDocumentacion4.TabIndex = 46;
            // 
            // cbPoderNotarialApl
            // 
            this.cbPoderNotarialApl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbPoderNotarialApl.FormattingEnabled = true;
            this.cbPoderNotarialApl.Items.AddRange(new object[] {
            "Si",
            "No"});
            this.cbPoderNotarialApl.Location = new System.Drawing.Point(3, 3);
            this.cbPoderNotarialApl.Name = "cbPoderNotarialApl";
            this.cbPoderNotarialApl.Size = new System.Drawing.Size(68, 21);
            this.cbPoderNotarialApl.TabIndex = 54;
            this.cbPoderNotarialApl.SelectedIndexChanged += new System.EventHandler(this.cbPoderNotarialApl_SelectedIndexChanged);
            // 
            // rbtnPoderNotarialCC
            // 
            this.rbtnPoderNotarialCC.AutoSize = true;
            this.rbtnPoderNotarialCC.Location = new System.Drawing.Point(168, 4);
            this.rbtnPoderNotarialCC.Name = "rbtnPoderNotarialCC";
            this.rbtnPoderNotarialCC.Size = new System.Drawing.Size(104, 17);
            this.rbtnPoderNotarialCC.TabIndex = 18;
            this.rbtnPoderNotarialCC.Text = "Copia certificada";
            this.rbtnPoderNotarialCC.UseVisualStyleBackColor = true;
            // 
            // txtPoderNotarialObs
            // 
            this.txtPoderNotarialObs.Location = new System.Drawing.Point(278, 3);
            this.txtPoderNotarialObs.Name = "txtPoderNotarialObs";
            this.txtPoderNotarialObs.Size = new System.Drawing.Size(231, 45);
            this.txtPoderNotarialObs.TabIndex = 31;
            this.txtPoderNotarialObs.Text = "";
            // 
            // rbtnPoderNotarialCS
            // 
            this.rbtnPoderNotarialCS.AutoSize = true;
            this.rbtnPoderNotarialCS.Location = new System.Drawing.Point(81, 4);
            this.rbtnPoderNotarialCS.Name = "rbtnPoderNotarialCS";
            this.rbtnPoderNotarialCS.Size = new System.Drawing.Size(84, 17);
            this.rbtnPoderNotarialCS.TabIndex = 17;
            this.rbtnPoderNotarialCS.Text = "Copia simple";
            this.rbtnPoderNotarialCS.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(205, 53);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(38, 13);
            this.label10.TabIndex = 33;
            this.label10.Text = "Hasta:";
            // 
            // cbxEstadoCuenta
            // 
            this.cbxEstadoCuenta.AutoSize = true;
            this.cbxEstadoCuenta.Location = new System.Drawing.Point(6, 27);
            this.cbxEstadoCuenta.Name = "cbxEstadoCuenta";
            this.cbxEstadoCuenta.Size = new System.Drawing.Size(115, 17);
            this.cbxEstadoCuenta.TabIndex = 2;
            this.cbxEstadoCuenta.Text = "Estados de cuenta";
            this.cbxEstadoCuenta.UseVisualStyleBackColor = true;
            this.cbxEstadoCuenta.CheckedChanged += new System.EventHandler(this.cbxEstadoCuenta_CheckedChanged);
            // 
            // pnlDocumentacion1
            // 
            this.pnlDocumentacion1.Controls.Add(this.cbxEstadoCuentaApl);
            this.pnlDocumentacion1.Controls.Add(this.rbtnEstadosCuentaCC);
            this.pnlDocumentacion1.Controls.Add(this.rbtnEstadoCuentaCS);
            this.pnlDocumentacion1.Controls.Add(this.txtEstadosCuentaObs);
            this.pnlDocumentacion1.Enabled = false;
            this.pnlDocumentacion1.Location = new System.Drawing.Point(148, 22);
            this.pnlDocumentacion1.Name = "pnlDocumentacion1";
            this.pnlDocumentacion1.Size = new System.Drawing.Size(516, 51);
            this.pnlDocumentacion1.TabIndex = 3;
            // 
            // cbxEstadoCuentaApl
            // 
            this.cbxEstadoCuentaApl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxEstadoCuentaApl.FormattingEnabled = true;
            this.cbxEstadoCuentaApl.Items.AddRange(new object[] {
            "Si",
            "No"});
            this.cbxEstadoCuentaApl.Location = new System.Drawing.Point(3, 3);
            this.cbxEstadoCuentaApl.Name = "cbxEstadoCuentaApl";
            this.cbxEstadoCuentaApl.Size = new System.Drawing.Size(68, 21);
            this.cbxEstadoCuentaApl.TabIndex = 51;
            this.cbxEstadoCuentaApl.SelectedIndexChanged += new System.EventHandler(this.cbxEstadoCuentaApl_SelectedIndexChanged);
            // 
            // rbtnEstadosCuentaCC
            // 
            this.rbtnEstadosCuentaCC.AutoSize = true;
            this.rbtnEstadosCuentaCC.Location = new System.Drawing.Point(170, 4);
            this.rbtnEstadosCuentaCC.Name = "rbtnEstadosCuentaCC";
            this.rbtnEstadosCuentaCC.Size = new System.Drawing.Size(104, 17);
            this.rbtnEstadosCuentaCC.TabIndex = 4;
            this.rbtnEstadosCuentaCC.Text = "Copia certificada";
            this.rbtnEstadosCuentaCC.UseVisualStyleBackColor = true;
            // 
            // rbtnEstadoCuentaCS
            // 
            this.rbtnEstadoCuentaCS.AutoSize = true;
            this.rbtnEstadoCuentaCS.Location = new System.Drawing.Point(83, 4);
            this.rbtnEstadoCuentaCS.Name = "rbtnEstadoCuentaCS";
            this.rbtnEstadoCuentaCS.Size = new System.Drawing.Size(84, 17);
            this.rbtnEstadoCuentaCS.TabIndex = 3;
            this.rbtnEstadoCuentaCS.Text = "Copia simple";
            this.rbtnEstadoCuentaCS.UseVisualStyleBackColor = true;
            // 
            // txtEstadosCuentaObs
            // 
            this.txtEstadosCuentaObs.Location = new System.Drawing.Point(280, 3);
            this.txtEstadosCuentaObs.Name = "txtEstadosCuentaObs";
            this.txtEstadosCuentaObs.Size = new System.Drawing.Size(231, 45);
            this.txtEstadosCuentaObs.TabIndex = 28;
            this.txtEstadosCuentaObs.Text = "";
            // 
            // pnlDocumentacion3
            // 
            this.pnlDocumentacion3.Controls.Add(this.cbContratoAperturaApl);
            this.pnlDocumentacion3.Controls.Add(this.rbtnContratoAperturaCS);
            this.pnlDocumentacion3.Controls.Add(this.rbtnContratoAperturaCC);
            this.pnlDocumentacion3.Controls.Add(this.txtContratoAperturaObs);
            this.pnlDocumentacion3.Enabled = false;
            this.pnlDocumentacion3.Location = new System.Drawing.Point(150, 130);
            this.pnlDocumentacion3.Name = "pnlDocumentacion3";
            this.pnlDocumentacion3.Size = new System.Drawing.Size(514, 51);
            this.pnlDocumentacion3.TabIndex = 45;
            // 
            // cbContratoAperturaApl
            // 
            this.cbContratoAperturaApl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbContratoAperturaApl.FormattingEnabled = true;
            this.cbContratoAperturaApl.Items.AddRange(new object[] {
            "Si",
            "No"});
            this.cbContratoAperturaApl.Location = new System.Drawing.Point(3, 3);
            this.cbContratoAperturaApl.Name = "cbContratoAperturaApl";
            this.cbContratoAperturaApl.Size = new System.Drawing.Size(68, 21);
            this.cbContratoAperturaApl.TabIndex = 53;
            this.cbContratoAperturaApl.SelectedIndexChanged += new System.EventHandler(this.cbContratoAperturaApl_SelectedIndexChanged);
            // 
            // rbtnContratoAperturaCS
            // 
            this.rbtnContratoAperturaCS.AutoSize = true;
            this.rbtnContratoAperturaCS.Location = new System.Drawing.Point(81, 4);
            this.rbtnContratoAperturaCS.Name = "rbtnContratoAperturaCS";
            this.rbtnContratoAperturaCS.Size = new System.Drawing.Size(84, 17);
            this.rbtnContratoAperturaCS.TabIndex = 13;
            this.rbtnContratoAperturaCS.Text = "Copia simple";
            this.rbtnContratoAperturaCS.UseVisualStyleBackColor = true;
            // 
            // rbtnContratoAperturaCC
            // 
            this.rbtnContratoAperturaCC.AutoSize = true;
            this.rbtnContratoAperturaCC.Location = new System.Drawing.Point(168, 4);
            this.rbtnContratoAperturaCC.Name = "rbtnContratoAperturaCC";
            this.rbtnContratoAperturaCC.Size = new System.Drawing.Size(104, 17);
            this.rbtnContratoAperturaCC.TabIndex = 14;
            this.rbtnContratoAperturaCC.Text = "Copia certificada";
            this.rbtnContratoAperturaCC.UseVisualStyleBackColor = true;
            // 
            // txtContratoAperturaObs
            // 
            this.txtContratoAperturaObs.Location = new System.Drawing.Point(278, 3);
            this.txtContratoAperturaObs.Name = "txtContratoAperturaObs";
            this.txtContratoAperturaObs.Size = new System.Drawing.Size(231, 45);
            this.txtContratoAperturaObs.TabIndex = 30;
            this.txtContratoAperturaObs.Text = "";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(425, 4);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(81, 13);
            this.label8.TabIndex = 37;
            this.label8.Text = "Observaciones:";
            // 
            // pnlDocumentacion2
            // 
            this.pnlDocumentacion2.Controls.Add(this.cbIdentificacionOficialApl);
            this.pnlDocumentacion2.Controls.Add(this.rbtnIdentificacionOficialCS);
            this.pnlDocumentacion2.Controls.Add(this.rbtnIdentificacionOficialCC);
            this.pnlDocumentacion2.Controls.Add(this.txtIdentificacionOficialObs);
            this.pnlDocumentacion2.Enabled = false;
            this.pnlDocumentacion2.Location = new System.Drawing.Point(150, 76);
            this.pnlDocumentacion2.Name = "pnlDocumentacion2";
            this.pnlDocumentacion2.Size = new System.Drawing.Size(514, 51);
            this.pnlDocumentacion2.TabIndex = 44;
            // 
            // cbIdentificacionOficialApl
            // 
            this.cbIdentificacionOficialApl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbIdentificacionOficialApl.FormattingEnabled = true;
            this.cbIdentificacionOficialApl.Items.AddRange(new object[] {
            "Si",
            "No"});
            this.cbIdentificacionOficialApl.Location = new System.Drawing.Point(3, 3);
            this.cbIdentificacionOficialApl.Name = "cbIdentificacionOficialApl";
            this.cbIdentificacionOficialApl.Size = new System.Drawing.Size(68, 21);
            this.cbIdentificacionOficialApl.TabIndex = 52;
            this.cbIdentificacionOficialApl.SelectedIndexChanged += new System.EventHandler(this.cbIdentificacionOficialApl_SelectedIndexChanged);
            // 
            // rbtnIdentificacionOficialCS
            // 
            this.rbtnIdentificacionOficialCS.AutoSize = true;
            this.rbtnIdentificacionOficialCS.Location = new System.Drawing.Point(81, 4);
            this.rbtnIdentificacionOficialCS.Name = "rbtnIdentificacionOficialCS";
            this.rbtnIdentificacionOficialCS.Size = new System.Drawing.Size(84, 17);
            this.rbtnIdentificacionOficialCS.TabIndex = 9;
            this.rbtnIdentificacionOficialCS.Text = "Copia simple";
            this.rbtnIdentificacionOficialCS.UseVisualStyleBackColor = true;
            // 
            // rbtnIdentificacionOficialCC
            // 
            this.rbtnIdentificacionOficialCC.AutoSize = true;
            this.rbtnIdentificacionOficialCC.Location = new System.Drawing.Point(168, 4);
            this.rbtnIdentificacionOficialCC.Name = "rbtnIdentificacionOficialCC";
            this.rbtnIdentificacionOficialCC.Size = new System.Drawing.Size(104, 17);
            this.rbtnIdentificacionOficialCC.TabIndex = 10;
            this.rbtnIdentificacionOficialCC.Text = "Copia certificada";
            this.rbtnIdentificacionOficialCC.UseVisualStyleBackColor = true;
            // 
            // txtIdentificacionOficialObs
            // 
            this.txtIdentificacionOficialObs.Location = new System.Drawing.Point(278, 3);
            this.txtIdentificacionOficialObs.Name = "txtIdentificacionOficialObs";
            this.txtIdentificacionOficialObs.Size = new System.Drawing.Size(231, 45);
            this.txtIdentificacionOficialObs.TabIndex = 29;
            this.txtIdentificacionOficialObs.Text = "";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightGray;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.cbDocumentacion);
            this.panel1.Controls.Add(this.label16);
            this.panel1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Location = new System.Drawing.Point(6, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(659, 31);
            this.panel1.TabIndex = 8;
            // 
            // cbDocumentacion
            // 
            this.cbDocumentacion.AutoSize = true;
            this.cbDocumentacion.Location = new System.Drawing.Point(7, 9);
            this.cbDocumentacion.Name = "cbDocumentacion";
            this.cbDocumentacion.Size = new System.Drawing.Size(15, 14);
            this.cbDocumentacion.TabIndex = 1;
            this.cbDocumentacion.UseVisualStyleBackColor = true;
            this.cbDocumentacion.CheckedChanged += new System.EventHandler(this.cbDocumentacion_CheckedChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(143, 9);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(349, 13);
            this.label16.TabIndex = 0;
            this.label16.Text = "Enlista la documentación relacionada a la cuenta ingresada previamente";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.pnlDocumentacionOper);
            this.tabPage2.Controls.Add(this.panel2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(673, 409);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Documentacion Operaciones";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // pnlDocumentacionOper
            // 
            this.pnlDocumentacionOper.Controls.Add(this.rbtnInfSolicitadaForPar);
            this.pnlDocumentacionOper.Controls.Add(this.rbtnInfSolicitadaAnex);
            this.pnlDocumentacionOper.Controls.Add(this.txtEspecifica);
            this.pnlDocumentacionOper.Controls.Add(this.cbOtro);
            this.pnlDocumentacionOper.Controls.Add(this.cbFichasRetiro);
            this.pnlDocumentacionOper.Controls.Add(this.label13);
            this.pnlDocumentacionOper.Controls.Add(this.cbFichasDeposito);
            this.pnlDocumentacionOper.Controls.Add(this.cbComprobantes);
            this.pnlDocumentacionOper.Controls.Add(this.cbCheques);
            this.pnlDocumentacionOper.Controls.Add(this.pnlDocumentacionOper5);
            this.pnlDocumentacionOper.Controls.Add(this.pnlDocumentacionOper1);
            this.pnlDocumentacionOper.Controls.Add(this.pnlDocumentacionOper4);
            this.pnlDocumentacionOper.Controls.Add(this.label12);
            this.pnlDocumentacionOper.Controls.Add(this.pnlDocumentacionOper3);
            this.pnlDocumentacionOper.Controls.Add(this.pnlDocumentacionOper2);
            this.pnlDocumentacionOper.Controls.Add(this.rbtnInfSolicitada);
            this.pnlDocumentacionOper.Controls.Add(this.rbtnInfSolicitadaExc);
            this.pnlDocumentacionOper.Controls.Add(this.label11);
            this.pnlDocumentacionOper.Controls.Add(this.txtAnexo);
            this.pnlDocumentacionOper.Enabled = false;
            this.pnlDocumentacionOper.Location = new System.Drawing.Point(6, 37);
            this.pnlDocumentacionOper.Name = "pnlDocumentacionOper";
            this.pnlDocumentacionOper.Size = new System.Drawing.Size(666, 369);
            this.pnlDocumentacionOper.TabIndex = 22;
            // 
            // rbtnInfSolicitadaForPar
            // 
            this.rbtnInfSolicitadaForPar.AutoSize = true;
            this.rbtnInfSolicitadaForPar.Location = new System.Drawing.Point(8, 295);
            this.rbtnInfSolicitadaForPar.Name = "rbtnInfSolicitadaForPar";
            this.rbtnInfSolicitadaForPar.Size = new System.Drawing.Size(441, 17);
            this.rbtnInfSolicitadaForPar.TabIndex = 62;
            this.rbtnInfSolicitadaForPar.TabStop = true;
            this.rbtnInfSolicitadaForPar.Text = "Se proporciona la documentación de forma parcial según lo señalado en el/los anex" +
                "o(s):";
            this.rbtnInfSolicitadaForPar.UseVisualStyleBackColor = true;
            this.rbtnInfSolicitadaForPar.CheckedChanged += new System.EventHandler(this.rbtnInfSolicitadaForPar_CheckedChanged);
            // 
            // rbtnInfSolicitadaAnex
            // 
            this.rbtnInfSolicitadaAnex.AutoSize = true;
            this.rbtnInfSolicitadaAnex.Location = new System.Drawing.Point(8, 312);
            this.rbtnInfSolicitadaAnex.Name = "rbtnInfSolicitadaAnex";
            this.rbtnInfSolicitadaAnex.Size = new System.Drawing.Size(340, 17);
            this.rbtnInfSolicitadaAnex.TabIndex = 63;
            this.rbtnInfSolicitadaAnex.TabStop = true;
            this.rbtnInfSolicitadaAnex.Text = "Se entrega última parcialidad según lo señalado en el/los anexo(s):";
            this.rbtnInfSolicitadaAnex.UseVisualStyleBackColor = true;
            this.rbtnInfSolicitadaAnex.CheckedChanged += new System.EventHandler(this.rbtnInfSolicitadaAnex_CheckedChanged);
            // 
            // txtEspecifica
            // 
            this.txtEspecifica.Enabled = false;
            this.txtEspecifica.Location = new System.Drawing.Point(126, 245);
            this.txtEspecifica.Name = "txtEspecifica";
            this.txtEspecifica.Size = new System.Drawing.Size(253, 20);
            this.txtEspecifica.TabIndex = 22;
            // 
            // cbOtro
            // 
            this.cbOtro.AutoSize = true;
            this.cbOtro.Location = new System.Drawing.Point(3, 221);
            this.cbOtro.Name = "cbOtro";
            this.cbOtro.Size = new System.Drawing.Size(46, 17);
            this.cbOtro.TabIndex = 18;
            this.cbOtro.Text = "Otro";
            this.cbOtro.UseVisualStyleBackColor = true;
            this.cbOtro.CheckedChanged += new System.EventHandler(this.cbOtro_CheckedChanged);
            // 
            // cbFichasRetiro
            // 
            this.cbFichasRetiro.AutoSize = true;
            this.cbFichasRetiro.Location = new System.Drawing.Point(3, 121);
            this.cbFichasRetiro.Name = "cbFichasRetiro";
            this.cbFichasRetiro.Size = new System.Drawing.Size(98, 17);
            this.cbFichasRetiro.TabIndex = 10;
            this.cbFichasRetiro.Text = "Fichas de retiro";
            this.cbFichasRetiro.UseVisualStyleBackColor = true;
            this.cbFichasRetiro.CheckedChanged += new System.EventHandler(this.cbFichasRetiro_CheckedChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(406, 3);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(81, 13);
            this.label13.TabIndex = 45;
            this.label13.Text = "Observaciones:";
            // 
            // cbFichasDeposito
            // 
            this.cbFichasDeposito.AutoSize = true;
            this.cbFichasDeposito.Location = new System.Drawing.Point(3, 73);
            this.cbFichasDeposito.Name = "cbFichasDeposito";
            this.cbFichasDeposito.Size = new System.Drawing.Size(115, 17);
            this.cbFichasDeposito.TabIndex = 6;
            this.cbFichasDeposito.Text = "Fichas de depósito";
            this.cbFichasDeposito.UseVisualStyleBackColor = true;
            this.cbFichasDeposito.CheckedChanged += new System.EventHandler(this.cbFichasDeposito_CheckedChanged);
            // 
            // cbComprobantes
            // 
            this.cbComprobantes.AutoSize = true;
            this.cbComprobantes.Location = new System.Drawing.Point(3, 170);
            this.cbComprobantes.Name = "cbComprobantes";
            this.cbComprobantes.Size = new System.Drawing.Size(94, 17);
            this.cbComprobantes.TabIndex = 14;
            this.cbComprobantes.Text = "Comprobantes";
            this.cbComprobantes.UseVisualStyleBackColor = true;
            this.cbComprobantes.CheckedChanged += new System.EventHandler(this.cbComprobantes_CheckedChanged);
            // 
            // cbCheques
            // 
            this.cbCheques.AutoSize = true;
            this.cbCheques.Location = new System.Drawing.Point(3, 23);
            this.cbCheques.Name = "cbCheques";
            this.cbCheques.Size = new System.Drawing.Size(68, 17);
            this.cbCheques.TabIndex = 2;
            this.cbCheques.Text = "Cheques";
            this.cbCheques.UseVisualStyleBackColor = true;
            this.cbCheques.CheckedChanged += new System.EventHandler(this.cbCheques_CheckedChanged);
            // 
            // pnlDocumentacionOper5
            // 
            this.pnlDocumentacionOper5.Controls.Add(this.txtOtroObs);
            this.pnlDocumentacionOper5.Controls.Add(this.cbOtroApl);
            this.pnlDocumentacionOper5.Controls.Add(this.rbtnOtroCS);
            this.pnlDocumentacionOper5.Controls.Add(this.rbtnOtroCC);
            this.pnlDocumentacionOper5.Enabled = false;
            this.pnlDocumentacionOper5.Location = new System.Drawing.Point(114, 216);
            this.pnlDocumentacionOper5.Name = "pnlDocumentacionOper5";
            this.pnlDocumentacionOper5.Size = new System.Drawing.Size(551, 51);
            this.pnlDocumentacionOper5.TabIndex = 61;
            // 
            // txtOtroObs
            // 
            this.txtOtroObs.Location = new System.Drawing.Point(295, 3);
            this.txtOtroObs.Name = "txtOtroObs";
            this.txtOtroObs.Size = new System.Drawing.Size(249, 45);
            this.txtOtroObs.TabIndex = 56;
            this.txtOtroObs.Text = "";
            // 
            // cbOtroApl
            // 
            this.cbOtroApl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbOtroApl.FormattingEnabled = true;
            this.cbOtroApl.Items.AddRange(new object[] {
            "Si",
            "No"});
            this.cbOtroApl.Location = new System.Drawing.Point(12, 3);
            this.cbOtroApl.Name = "cbOtroApl";
            this.cbOtroApl.Size = new System.Drawing.Size(68, 21);
            this.cbOtroApl.TabIndex = 31;
            this.cbOtroApl.SelectedIndexChanged += new System.EventHandler(this.cbOtroApl_SelectedIndexChanged);
            // 
            // rbtnOtroCS
            // 
            this.rbtnOtroCS.AutoSize = true;
            this.rbtnOtroCS.Location = new System.Drawing.Point(95, 4);
            this.rbtnOtroCS.Name = "rbtnOtroCS";
            this.rbtnOtroCS.Size = new System.Drawing.Size(84, 17);
            this.rbtnOtroCS.TabIndex = 19;
            this.rbtnOtroCS.Text = "Copia simple";
            this.rbtnOtroCS.UseVisualStyleBackColor = true;
            // 
            // rbtnOtroCC
            // 
            this.rbtnOtroCC.AutoSize = true;
            this.rbtnOtroCC.Location = new System.Drawing.Point(185, 4);
            this.rbtnOtroCC.Name = "rbtnOtroCC";
            this.rbtnOtroCC.Size = new System.Drawing.Size(104, 17);
            this.rbtnOtroCC.TabIndex = 20;
            this.rbtnOtroCC.Text = "Copia certificada";
            this.rbtnOtroCC.UseVisualStyleBackColor = true;
            // 
            // pnlDocumentacionOper1
            // 
            this.pnlDocumentacionOper1.Controls.Add(this.txtChequesObs);
            this.pnlDocumentacionOper1.Controls.Add(this.cbChequesApl);
            this.pnlDocumentacionOper1.Controls.Add(this.rbtnChequesCC);
            this.pnlDocumentacionOper1.Controls.Add(this.rbtnChequesCS);
            this.pnlDocumentacionOper1.Enabled = false;
            this.pnlDocumentacionOper1.Location = new System.Drawing.Point(114, 16);
            this.pnlDocumentacionOper1.Name = "pnlDocumentacionOper1";
            this.pnlDocumentacionOper1.Size = new System.Drawing.Size(551, 51);
            this.pnlDocumentacionOper1.TabIndex = 57;
            // 
            // txtChequesObs
            // 
            this.txtChequesObs.Location = new System.Drawing.Point(295, 3);
            this.txtChequesObs.Name = "txtChequesObs";
            this.txtChequesObs.Size = new System.Drawing.Size(249, 45);
            this.txtChequesObs.TabIndex = 52;
            this.txtChequesObs.Text = "";
            // 
            // cbChequesApl
            // 
            this.cbChequesApl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbChequesApl.FormattingEnabled = true;
            this.cbChequesApl.Items.AddRange(new object[] {
            "Si",
            "No"});
            this.cbChequesApl.Location = new System.Drawing.Point(12, 3);
            this.cbChequesApl.Name = "cbChequesApl";
            this.cbChequesApl.Size = new System.Drawing.Size(68, 21);
            this.cbChequesApl.TabIndex = 27;
            this.cbChequesApl.SelectedIndexChanged += new System.EventHandler(this.cbChequesApl_SelectedIndexChanged);
            // 
            // rbtnChequesCC
            // 
            this.rbtnChequesCC.AutoSize = true;
            this.rbtnChequesCC.Location = new System.Drawing.Point(185, 5);
            this.rbtnChequesCC.Name = "rbtnChequesCC";
            this.rbtnChequesCC.Size = new System.Drawing.Size(104, 17);
            this.rbtnChequesCC.TabIndex = 4;
            this.rbtnChequesCC.Text = "Copia certificada";
            this.rbtnChequesCC.UseVisualStyleBackColor = true;
            // 
            // rbtnChequesCS
            // 
            this.rbtnChequesCS.AutoSize = true;
            this.rbtnChequesCS.Location = new System.Drawing.Point(95, 5);
            this.rbtnChequesCS.Name = "rbtnChequesCS";
            this.rbtnChequesCS.Size = new System.Drawing.Size(84, 17);
            this.rbtnChequesCS.TabIndex = 3;
            this.rbtnChequesCS.Text = "Copia simple";
            this.rbtnChequesCS.UseVisualStyleBackColor = true;
            // 
            // pnlDocumentacionOper4
            // 
            this.pnlDocumentacionOper4.Controls.Add(this.cbComprobantesApl);
            this.pnlDocumentacionOper4.Controls.Add(this.txtComprobantesObs);
            this.pnlDocumentacionOper4.Controls.Add(this.rbtnComprobantesCC);
            this.pnlDocumentacionOper4.Controls.Add(this.rbtnComprobantesCS);
            this.pnlDocumentacionOper4.Enabled = false;
            this.pnlDocumentacionOper4.Location = new System.Drawing.Point(114, 166);
            this.pnlDocumentacionOper4.Name = "pnlDocumentacionOper4";
            this.pnlDocumentacionOper4.Size = new System.Drawing.Size(551, 51);
            this.pnlDocumentacionOper4.TabIndex = 60;
            // 
            // cbComprobantesApl
            // 
            this.cbComprobantesApl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbComprobantesApl.FormattingEnabled = true;
            this.cbComprobantesApl.Items.AddRange(new object[] {
            "Si",
            "No"});
            this.cbComprobantesApl.Location = new System.Drawing.Point(12, 3);
            this.cbComprobantesApl.Name = "cbComprobantesApl";
            this.cbComprobantesApl.Size = new System.Drawing.Size(68, 21);
            this.cbComprobantesApl.TabIndex = 30;
            this.cbComprobantesApl.SelectedIndexChanged += new System.EventHandler(this.cbComprobantesApl_SelectedIndexChanged);
            // 
            // txtComprobantesObs
            // 
            this.txtComprobantesObs.Location = new System.Drawing.Point(295, 3);
            this.txtComprobantesObs.Name = "txtComprobantesObs";
            this.txtComprobantesObs.Size = new System.Drawing.Size(249, 45);
            this.txtComprobantesObs.TabIndex = 55;
            this.txtComprobantesObs.Text = "";
            // 
            // rbtnComprobantesCC
            // 
            this.rbtnComprobantesCC.AutoSize = true;
            this.rbtnComprobantesCC.Location = new System.Drawing.Point(185, 4);
            this.rbtnComprobantesCC.Name = "rbtnComprobantesCC";
            this.rbtnComprobantesCC.Size = new System.Drawing.Size(104, 17);
            this.rbtnComprobantesCC.TabIndex = 16;
            this.rbtnComprobantesCC.Text = "Copia certificada";
            this.rbtnComprobantesCC.UseVisualStyleBackColor = true;
            // 
            // rbtnComprobantesCS
            // 
            this.rbtnComprobantesCS.AutoSize = true;
            this.rbtnComprobantesCS.Location = new System.Drawing.Point(95, 4);
            this.rbtnComprobantesCS.Name = "rbtnComprobantesCS";
            this.rbtnComprobantesCS.Size = new System.Drawing.Size(84, 17);
            this.rbtnComprobantesCS.TabIndex = 15;
            this.rbtnComprobantesCS.Text = "Copia simple";
            this.rbtnComprobantesCS.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(61, 248);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(59, 13);
            this.label12.TabIndex = 46;
            this.label12.Text = "Especifica:";
            // 
            // pnlDocumentacionOper3
            // 
            this.pnlDocumentacionOper3.Controls.Add(this.cbFichasRetiroApl);
            this.pnlDocumentacionOper3.Controls.Add(this.rbtnFichasRetiroCC);
            this.pnlDocumentacionOper3.Controls.Add(this.txtFichasRetiroObs);
            this.pnlDocumentacionOper3.Controls.Add(this.rbtnFichasRetiroCS);
            this.pnlDocumentacionOper3.Enabled = false;
            this.pnlDocumentacionOper3.Location = new System.Drawing.Point(114, 116);
            this.pnlDocumentacionOper3.Name = "pnlDocumentacionOper3";
            this.pnlDocumentacionOper3.Size = new System.Drawing.Size(551, 51);
            this.pnlDocumentacionOper3.TabIndex = 59;
            // 
            // cbFichasRetiroApl
            // 
            this.cbFichasRetiroApl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbFichasRetiroApl.FormattingEnabled = true;
            this.cbFichasRetiroApl.Items.AddRange(new object[] {
            "Si",
            "No"});
            this.cbFichasRetiroApl.Location = new System.Drawing.Point(12, 3);
            this.cbFichasRetiroApl.Name = "cbFichasRetiroApl";
            this.cbFichasRetiroApl.Size = new System.Drawing.Size(68, 21);
            this.cbFichasRetiroApl.TabIndex = 29;
            this.cbFichasRetiroApl.SelectedIndexChanged += new System.EventHandler(this.cbFichasRetiroApl_SelectedIndexChanged);
            // 
            // rbtnFichasRetiroCC
            // 
            this.rbtnFichasRetiroCC.AutoSize = true;
            this.rbtnFichasRetiroCC.Location = new System.Drawing.Point(185, 4);
            this.rbtnFichasRetiroCC.Name = "rbtnFichasRetiroCC";
            this.rbtnFichasRetiroCC.Size = new System.Drawing.Size(104, 17);
            this.rbtnFichasRetiroCC.TabIndex = 12;
            this.rbtnFichasRetiroCC.Text = "Copia certificada";
            this.rbtnFichasRetiroCC.UseVisualStyleBackColor = true;
            // 
            // txtFichasRetiroObs
            // 
            this.txtFichasRetiroObs.Location = new System.Drawing.Point(295, 3);
            this.txtFichasRetiroObs.Name = "txtFichasRetiroObs";
            this.txtFichasRetiroObs.Size = new System.Drawing.Size(249, 45);
            this.txtFichasRetiroObs.TabIndex = 54;
            this.txtFichasRetiroObs.Text = "";
            // 
            // rbtnFichasRetiroCS
            // 
            this.rbtnFichasRetiroCS.AutoSize = true;
            this.rbtnFichasRetiroCS.Location = new System.Drawing.Point(95, 4);
            this.rbtnFichasRetiroCS.Name = "rbtnFichasRetiroCS";
            this.rbtnFichasRetiroCS.Size = new System.Drawing.Size(84, 17);
            this.rbtnFichasRetiroCS.TabIndex = 11;
            this.rbtnFichasRetiroCS.Text = "Copia simple";
            this.rbtnFichasRetiroCS.UseVisualStyleBackColor = true;
            // 
            // pnlDocumentacionOper2
            // 
            this.pnlDocumentacionOper2.Controls.Add(this.cbFichasDepositoApl);
            this.pnlDocumentacionOper2.Controls.Add(this.rbtnFichasDepositoCC);
            this.pnlDocumentacionOper2.Controls.Add(this.rbtnFichasDepositoCS);
            this.pnlDocumentacionOper2.Controls.Add(this.txtFichasDepositoObs);
            this.pnlDocumentacionOper2.Enabled = false;
            this.pnlDocumentacionOper2.Location = new System.Drawing.Point(114, 66);
            this.pnlDocumentacionOper2.Name = "pnlDocumentacionOper2";
            this.pnlDocumentacionOper2.Size = new System.Drawing.Size(551, 51);
            this.pnlDocumentacionOper2.TabIndex = 58;
            // 
            // cbFichasDepositoApl
            // 
            this.cbFichasDepositoApl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbFichasDepositoApl.FormattingEnabled = true;
            this.cbFichasDepositoApl.Items.AddRange(new object[] {
            "Si",
            "No"});
            this.cbFichasDepositoApl.Location = new System.Drawing.Point(12, 3);
            this.cbFichasDepositoApl.Name = "cbFichasDepositoApl";
            this.cbFichasDepositoApl.Size = new System.Drawing.Size(68, 21);
            this.cbFichasDepositoApl.TabIndex = 28;
            this.cbFichasDepositoApl.SelectedIndexChanged += new System.EventHandler(this.cbFichasDepositoApl_SelectedIndexChanged);
            // 
            // rbtnFichasDepositoCC
            // 
            this.rbtnFichasDepositoCC.AutoSize = true;
            this.rbtnFichasDepositoCC.Location = new System.Drawing.Point(185, 4);
            this.rbtnFichasDepositoCC.Name = "rbtnFichasDepositoCC";
            this.rbtnFichasDepositoCC.Size = new System.Drawing.Size(104, 17);
            this.rbtnFichasDepositoCC.TabIndex = 8;
            this.rbtnFichasDepositoCC.Text = "Copia certificada";
            this.rbtnFichasDepositoCC.UseVisualStyleBackColor = true;
            // 
            // rbtnFichasDepositoCS
            // 
            this.rbtnFichasDepositoCS.AutoSize = true;
            this.rbtnFichasDepositoCS.Location = new System.Drawing.Point(95, 4);
            this.rbtnFichasDepositoCS.Name = "rbtnFichasDepositoCS";
            this.rbtnFichasDepositoCS.Size = new System.Drawing.Size(84, 17);
            this.rbtnFichasDepositoCS.TabIndex = 7;
            this.rbtnFichasDepositoCS.Text = "Copia simple";
            this.rbtnFichasDepositoCS.UseVisualStyleBackColor = true;
            // 
            // txtFichasDepositoObs
            // 
            this.txtFichasDepositoObs.Location = new System.Drawing.Point(295, 3);
            this.txtFichasDepositoObs.Name = "txtFichasDepositoObs";
            this.txtFichasDepositoObs.Size = new System.Drawing.Size(249, 45);
            this.txtFichasDepositoObs.TabIndex = 53;
            this.txtFichasDepositoObs.Text = "";
            // 
            // rbtnInfSolicitada
            // 
            this.rbtnInfSolicitada.AutoSize = true;
            this.rbtnInfSolicitada.Location = new System.Drawing.Point(8, 278);
            this.rbtnInfSolicitada.Name = "rbtnInfSolicitada";
            this.rbtnInfSolicitada.Size = new System.Drawing.Size(334, 17);
            this.rbtnInfSolicitada.TabIndex = 23;
            this.rbtnInfSolicitada.TabStop = true;
            this.rbtnInfSolicitada.Text = "Se proporciona toda la documentacion solicitada por la autoridad.";
            this.rbtnInfSolicitada.UseVisualStyleBackColor = true;
            this.rbtnInfSolicitada.CheckedChanged += new System.EventHandler(this.rbtnInfSolicitada_CheckedChanged);
            // 
            // rbtnInfSolicitadaExc
            // 
            this.rbtnInfSolicitadaExc.AutoSize = true;
            this.rbtnInfSolicitadaExc.Location = new System.Drawing.Point(8, 329);
            this.rbtnInfSolicitadaExc.Name = "rbtnInfSolicitadaExc";
            this.rbtnInfSolicitadaExc.Size = new System.Drawing.Size(495, 17);
            this.rbtnInfSolicitadaExc.TabIndex = 24;
            this.rbtnInfSolicitadaExc.TabStop = true;
            this.rbtnInfSolicitadaExc.Text = "Se proporciona la documentación solicitada por la autoridad excepto lo señalado e" +
                "n el/los anexo(s):";
            this.rbtnInfSolicitadaExc.UseVisualStyleBackColor = true;
            this.rbtnInfSolicitadaExc.CheckedChanged += new System.EventHandler(this.rbtnInfSolicitadaExc_CheckedChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(45, 352);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(40, 13);
            this.label11.TabIndex = 50;
            this.label11.Text = "Anexo:";
            // 
            // txtAnexo
            // 
            this.txtAnexo.Enabled = false;
            this.txtAnexo.Location = new System.Drawing.Point(91, 349);
            this.txtAnexo.Name = "txtAnexo";
            this.txtAnexo.Size = new System.Drawing.Size(253, 20);
            this.txtAnexo.TabIndex = 25;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightGray;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.cbDocumentacionOper);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Location = new System.Drawing.Point(6, 6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(658, 31);
            this.panel2.TabIndex = 56;
            // 
            // cbDocumentacionOper
            // 
            this.cbDocumentacionOper.AutoSize = true;
            this.cbDocumentacionOper.Location = new System.Drawing.Point(7, 9);
            this.cbDocumentacionOper.Name = "cbDocumentacionOper";
            this.cbDocumentacionOper.Size = new System.Drawing.Size(15, 14);
            this.cbDocumentacionOper.TabIndex = 1;
            this.cbDocumentacionOper.UseVisualStyleBackColor = true;
            this.cbDocumentacionOper.CheckedChanged += new System.EventHandler(this.cbDocumentacionOper_CheckedChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(109, 9);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(430, 13);
            this.label17.TabIndex = 0;
            this.label17.Text = "Enlista la documentación de operaciones relacionadas a la cuenta ingresada previa" +
                "mente";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.pnlMovimientoElec);
            this.tabPage3.Controls.Add(this.panel3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(673, 409);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Movimientos Electrónicos";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // pnlMovimientoElec
            // 
            this.pnlMovimientoElec.Controls.Add(this.txtDispersionNominaObs);
            this.pnlMovimientoElec.Controls.Add(this.txtMovElectronicosObs);
            this.pnlMovimientoElec.Controls.Add(this.cbDispersionNominaApl);
            this.pnlMovimientoElec.Controls.Add(this.cbMovElectronicosApl);
            this.pnlMovimientoElec.Controls.Add(this.cbMovElectronicos);
            this.pnlMovimientoElec.Controls.Add(this.txtMovEAnexo);
            this.pnlMovimientoElec.Controls.Add(this.cbDispersionNomina);
            this.pnlMovimientoElec.Controls.Add(this.label15);
            this.pnlMovimientoElec.Controls.Add(this.rbtnMovEInfSolicitada);
            this.pnlMovimientoElec.Controls.Add(this.label14);
            this.pnlMovimientoElec.Controls.Add(this.rbtnMovEInfSolicitadaExc);
            this.pnlMovimientoElec.Enabled = false;
            this.pnlMovimientoElec.Location = new System.Drawing.Point(6, 43);
            this.pnlMovimientoElec.Name = "pnlMovimientoElec";
            this.pnlMovimientoElec.Size = new System.Drawing.Size(661, 318);
            this.pnlMovimientoElec.TabIndex = 22;
            // 
            // txtDispersionNominaObs
            // 
            this.txtDispersionNominaObs.Location = new System.Drawing.Point(242, 71);
            this.txtDispersionNominaObs.Name = "txtDispersionNominaObs";
            this.txtDispersionNominaObs.Size = new System.Drawing.Size(397, 45);
            this.txtDispersionNominaObs.TabIndex = 58;
            this.txtDispersionNominaObs.Text = "";
            // 
            // txtMovElectronicosObs
            // 
            this.txtMovElectronicosObs.Location = new System.Drawing.Point(242, 20);
            this.txtMovElectronicosObs.Name = "txtMovElectronicosObs";
            this.txtMovElectronicosObs.Size = new System.Drawing.Size(397, 45);
            this.txtMovElectronicosObs.TabIndex = 57;
            this.txtMovElectronicosObs.Text = "";
            // 
            // cbDispersionNominaApl
            // 
            this.cbDispersionNominaApl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbDispersionNominaApl.FormattingEnabled = true;
            this.cbDispersionNominaApl.Items.AddRange(new object[] {
            "Si",
            "No"});
            this.cbDispersionNominaApl.Location = new System.Drawing.Point(168, 71);
            this.cbDispersionNominaApl.Name = "cbDispersionNominaApl";
            this.cbDispersionNominaApl.Size = new System.Drawing.Size(68, 21);
            this.cbDispersionNominaApl.TabIndex = 36;
            // 
            // cbMovElectronicosApl
            // 
            this.cbMovElectronicosApl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbMovElectronicosApl.FormattingEnabled = true;
            this.cbMovElectronicosApl.Items.AddRange(new object[] {
            "Si",
            "No"});
            this.cbMovElectronicosApl.Location = new System.Drawing.Point(168, 20);
            this.cbMovElectronicosApl.Name = "cbMovElectronicosApl";
            this.cbMovElectronicosApl.Size = new System.Drawing.Size(68, 21);
            this.cbMovElectronicosApl.TabIndex = 35;
            // 
            // cbMovElectronicos
            // 
            this.cbMovElectronicos.AutoSize = true;
            this.cbMovElectronicos.Location = new System.Drawing.Point(3, 22);
            this.cbMovElectronicos.Name = "cbMovElectronicos";
            this.cbMovElectronicos.Size = new System.Drawing.Size(145, 17);
            this.cbMovElectronicos.TabIndex = 2;
            this.cbMovElectronicos.Text = "Movimientos electrónicos";
            this.cbMovElectronicos.UseVisualStyleBackColor = true;
            this.cbMovElectronicos.CheckedChanged += new System.EventHandler(this.cbMovElectronicos_CheckedChanged);
            // 
            // txtMovEAnexo
            // 
            this.txtMovEAnexo.Enabled = false;
            this.txtMovEAnexo.Location = new System.Drawing.Point(86, 171);
            this.txtMovEAnexo.Name = "txtMovEAnexo";
            this.txtMovEAnexo.Size = new System.Drawing.Size(253, 20);
            this.txtMovEAnexo.TabIndex = 8;
            // 
            // cbDispersionNomina
            // 
            this.cbDispersionNomina.AutoSize = true;
            this.cbDispersionNomina.Location = new System.Drawing.Point(3, 73);
            this.cbDispersionNomina.Name = "cbDispersionNomina";
            this.cbDispersionNomina.Size = new System.Drawing.Size(127, 17);
            this.cbDispersionNomina.TabIndex = 4;
            this.cbDispersionNomina.Text = "Dispersión de nómina";
            this.cbDispersionNomina.UseVisualStyleBackColor = true;
            this.cbDispersionNomina.CheckedChanged += new System.EventHandler(this.cbDispersionNomina_CheckedChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(242, 4);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(81, 13);
            this.label15.TabIndex = 31;
            this.label15.Text = "Observaciones:";
            // 
            // rbtnMovEInfSolicitada
            // 
            this.rbtnMovEInfSolicitada.AutoSize = true;
            this.rbtnMovEInfSolicitada.Location = new System.Drawing.Point(3, 125);
            this.rbtnMovEInfSolicitada.Name = "rbtnMovEInfSolicitada";
            this.rbtnMovEInfSolicitada.Size = new System.Drawing.Size(318, 17);
            this.rbtnMovEInfSolicitada.TabIndex = 6;
            this.rbtnMovEInfSolicitada.TabStop = true;
            this.rbtnMovEInfSolicitada.Text = "Se proporciona toda  la información solicitada por la autoridad.";
            this.rbtnMovEInfSolicitada.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(29, 174);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(51, 13);
            this.label14.TabIndex = 34;
            this.label14.Text = "Anexo(s):";
            // 
            // rbtnMovEInfSolicitadaExc
            // 
            this.rbtnMovEInfSolicitadaExc.AutoSize = true;
            this.rbtnMovEInfSolicitadaExc.Location = new System.Drawing.Point(3, 148);
            this.rbtnMovEInfSolicitadaExc.Name = "rbtnMovEInfSolicitadaExc";
            this.rbtnMovEInfSolicitadaExc.Size = new System.Drawing.Size(467, 17);
            this.rbtnMovEInfSolicitadaExc.TabIndex = 7;
            this.rbtnMovEInfSolicitadaExc.TabStop = true;
            this.rbtnMovEInfSolicitadaExc.Text = "Se proporciona la información solicitada por la autoridad según lo señalado en el" +
                "/los anexo(s):";
            this.rbtnMovEInfSolicitadaExc.UseVisualStyleBackColor = true;
            this.rbtnMovEInfSolicitadaExc.CheckedChanged += new System.EventHandler(this.rbtnMovEInfSolicitadaExc_CheckedChanged);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.LightGray;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.cbMovimientosElec);
            this.panel3.Controls.Add(this.label18);
            this.panel3.Location = new System.Drawing.Point(6, 6);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(661, 31);
            this.panel3.TabIndex = 57;
            // 
            // cbMovimientosElec
            // 
            this.cbMovimientosElec.AutoSize = true;
            this.cbMovimientosElec.Location = new System.Drawing.Point(7, 9);
            this.cbMovimientosElec.Name = "cbMovimientosElec";
            this.cbMovimientosElec.Size = new System.Drawing.Size(15, 14);
            this.cbMovimientosElec.TabIndex = 1;
            this.cbMovimientosElec.UseVisualStyleBackColor = true;
            this.cbMovimientosElec.CheckedChanged += new System.EventHandler(this.cbMovimientosElec_CheckedChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(112, 9);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(388, 13);
            this.label18.TabIndex = 0;
            this.label18.Text = "Enlista movimientos electrónicos relacionados a la cuenta ingresada previamente";
            // 
            // cbxPersona
            // 
            this.cbxPersona.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxPersona.FormattingEnabled = true;
            this.cbxPersona.Items.AddRange(new object[] {
            "Cuenta de ahorro",
            "Cuenta de cheques",
            "Tarjeta de crédito"});
            this.cbxPersona.Location = new System.Drawing.Point(77, 12);
            this.cbxPersona.Name = "cbxPersona";
            this.cbxPersona.Size = new System.Drawing.Size(380, 21);
            this.cbxPersona.TabIndex = 0;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(11, 15);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(49, 13);
            this.label20.TabIndex = 23;
            this.label20.Text = "Persona:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.label21.Location = new System.Drawing.Point(10, 33);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(649, 13);
            this.label21.TabIndex = 24;
            this.label21.Text = "_________________________________________________________________________________" +
                "__________________________";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(340, 114);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(107, 13);
            this.label22.TabIndex = 25;
            this.label22.Text = "Ubicación/Surcursal:";
            // 
            // txtUbicacionOrSucursal
            // 
            this.txtUbicacionOrSucursal.Location = new System.Drawing.Point(453, 111);
            this.txtUbicacionOrSucursal.Name = "txtUbicacionOrSucursal";
            this.txtUbicacionOrSucursal.Size = new System.Drawing.Size(196, 20);
            this.txtUbicacionOrSucursal.TabIndex = 26;
            // 
            // taObservaciones
            // 
            this.taObservaciones.Location = new System.Drawing.Point(124, 168);
            this.taObservaciones.Name = "taObservaciones";
            this.taObservaciones.Size = new System.Drawing.Size(525, 42);
            this.taObservaciones.TabIndex = 27;
            this.taObservaciones.Text = "";
            // 
            // frmCuenta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(695, 698);
            this.Controls.Add(this.taObservaciones);
            this.Controls.Add(this.txtUbicacionOrSucursal);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.cbxPersona);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btnAceptar);
            this.Controls.Add(this.btnRegresar);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cbxMoneda);
            this.Controls.Add(this.cbxEstatus);
            this.Controls.Add(this.cbxCaracter);
            this.Controls.Add(this.cbxTipo);
            this.Controls.Add(this.txtSaldo);
            this.Controls.Add(this.txtCuenta);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmCuenta";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GERA - Cuenta";
            this.Load += new System.EventHandler(this.frmCuenta_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.pnlDocumentacion.ResumeLayout(false);
            this.pnlDocumentacion.PerformLayout();
            this.pnlDocumentacion6.ResumeLayout(false);
            this.pnlDocumentacion6.PerformLayout();
            this.pnlDocumentacion5.ResumeLayout(false);
            this.pnlDocumentacion5.PerformLayout();
            this.pnlDocumentacion4.ResumeLayout(false);
            this.pnlDocumentacion4.PerformLayout();
            this.pnlDocumentacion1.ResumeLayout(false);
            this.pnlDocumentacion1.PerformLayout();
            this.pnlDocumentacion3.ResumeLayout(false);
            this.pnlDocumentacion3.PerformLayout();
            this.pnlDocumentacion2.ResumeLayout(false);
            this.pnlDocumentacion2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.pnlDocumentacionOper.ResumeLayout(false);
            this.pnlDocumentacionOper.PerformLayout();
            this.pnlDocumentacionOper5.ResumeLayout(false);
            this.pnlDocumentacionOper5.PerformLayout();
            this.pnlDocumentacionOper1.ResumeLayout(false);
            this.pnlDocumentacionOper1.PerformLayout();
            this.pnlDocumentacionOper4.ResumeLayout(false);
            this.pnlDocumentacionOper4.PerformLayout();
            this.pnlDocumentacionOper3.ResumeLayout(false);
            this.pnlDocumentacionOper3.PerformLayout();
            this.pnlDocumentacionOper2.ResumeLayout(false);
            this.pnlDocumentacionOper2.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.pnlMovimientoElec.ResumeLayout(false);
            this.pnlMovimientoElec.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtCuenta;
        private System.Windows.Forms.TextBox txtSaldo;
        private System.Windows.Forms.ComboBox cbxTipo;
        private System.Windows.Forms.ComboBox cbxCaracter;
        private System.Windows.Forms.ComboBox cbxEstatus;
        private System.Windows.Forms.ComboBox cbxMoneda;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.Button btnRegresar;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox cbPoderNotarial;
        private System.Windows.Forms.CheckBox cbContratoApertura;
        private System.Windows.Forms.CheckBox cbIdentificacionOficial;
        private System.Windows.Forms.CheckBox cbxEstadoCuenta;
        private System.Windows.Forms.RadioButton rbtnChequesCS;
        private System.Windows.Forms.TextBox txtAnexo;
        private System.Windows.Forms.CheckBox cbCheques;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckBox cbFichasDeposito;
        private System.Windows.Forms.RadioButton rbtnInfSolicitadaExc;
        private System.Windows.Forms.CheckBox cbFichasRetiro;
        private System.Windows.Forms.RadioButton rbtnInfSolicitada;
        private System.Windows.Forms.TextBox txtEspecifica;
        private System.Windows.Forms.CheckBox cbOtro;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.RadioButton rbtnFichasDepositoCS;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.RadioButton rbtnFichasRetiroCS;
        private System.Windows.Forms.RadioButton rbtnOtroCC;
        private System.Windows.Forms.RadioButton rbtnOtroCS;
        private System.Windows.Forms.RadioButton rbtnChequesCC;
        private System.Windows.Forms.RadioButton rbtnFichasRetiroCC;
        private System.Windows.Forms.RadioButton rbtnFichasDepositoCC;
        private System.Windows.Forms.TextBox txtMovEAnexo;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.RadioButton rbtnMovEInfSolicitadaExc;
        private System.Windows.Forms.RadioButton rbtnMovEInfSolicitada;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.CheckBox cbDispersionNomina;
        private System.Windows.Forms.CheckBox cbMovElectronicos;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel pnlDocumentacion1;
        private System.Windows.Forms.Panel pnlDocumentacion2;
        private System.Windows.Forms.Panel pnlDocumentacion3;
        private System.Windows.Forms.Panel pnlDocumentacion4;
        private System.Windows.Forms.Panel pnlDocumentacionOper1;
        private System.Windows.Forms.Panel pnlDocumentacionOper2;
        private System.Windows.Forms.Panel pnlDocumentacionOper3;
        private System.Windows.Forms.Panel pnlDocumentacionOper5;
        private System.Windows.Forms.Panel pnlDocumentacionOper4;
        private System.Windows.Forms.RadioButton rbtnComprobantesCC;
        private System.Windows.Forms.RadioButton rbtnComprobantesCS;
        private System.Windows.Forms.CheckBox cbComprobantes;
        private System.Windows.Forms.ComboBox cbxPersona;
        private System.Windows.Forms.RadioButton rbtnPoderNotarialCC;
        private System.Windows.Forms.RadioButton rbtnPoderNotarialCS;
        private System.Windows.Forms.RadioButton rbtnContratoAperturaCS;
        private System.Windows.Forms.RadioButton rbtnContratoAperturaCC;
        private System.Windows.Forms.RadioButton rbtnIdentificacionOficialCS;
        private System.Windows.Forms.RadioButton rbtnIdentificacionOficialCC;
        private System.Windows.Forms.RadioButton rbtnEstadosCuentaCC;
        private System.Windows.Forms.RadioButton rbtnEstadoCuentaCS;
        private System.Windows.Forms.DateTimePicker dtpEDCHasta;
        private System.Windows.Forms.DateTimePicker dtpEDCDesde;
        private System.Windows.Forms.CheckBox cbDocumentacion;
        private System.Windows.Forms.CheckBox cbDocumentacionOper;
        private System.Windows.Forms.CheckBox cbMovimientosElec;
        private System.Windows.Forms.Panel pnlDocumentacion;
        private System.Windows.Forms.Panel pnlDocumentacionOper;
        private System.Windows.Forms.Panel pnlMovimientoElec;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.CheckBox cbTarjetaFirmas;
        private System.Windows.Forms.CheckBox cbComprobanteDomicilio;
        private System.Windows.Forms.Panel pnlDocumentacion6;
        private System.Windows.Forms.RadioButton rbtnTarjetaFirmasCc;
        private System.Windows.Forms.RadioButton rbtnTarjetaFirmasCs;
        private System.Windows.Forms.Panel pnlDocumentacion5;
        private System.Windows.Forms.RadioButton rbtnComprobanteDomicilioCc;
        private System.Windows.Forms.RadioButton rbtnComprobanteDomicilioCs;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtUbicacionOrSucursal;
        private System.Windows.Forms.ComboBox cbChequesApl;
        private System.Windows.Forms.ComboBox cbOtroApl;
        private System.Windows.Forms.ComboBox cbComprobantesApl;
        private System.Windows.Forms.ComboBox cbFichasRetiroApl;
        private System.Windows.Forms.ComboBox cbFichasDepositoApl;
        private System.Windows.Forms.ComboBox cbTarjetaFirmasApl;
        private System.Windows.Forms.ComboBox cbComprobanteDomicilioApl;
        private System.Windows.Forms.ComboBox cbPoderNotarialApl;
        private System.Windows.Forms.ComboBox cbxEstadoCuentaApl;
        private System.Windows.Forms.ComboBox cbContratoAperturaApl;
        private System.Windows.Forms.ComboBox cbIdentificacionOficialApl;
        private System.Windows.Forms.ComboBox cbDispersionNominaApl;
        private System.Windows.Forms.ComboBox cbMovElectronicosApl;
        private System.Windows.Forms.RichTextBox taObservaciones;
        private System.Windows.Forms.RichTextBox txtTarjetaFirmasObs;
        private System.Windows.Forms.RichTextBox txtComprobanteDomicilioObs;
        private System.Windows.Forms.RichTextBox txtPoderNotarialObs;
        private System.Windows.Forms.RichTextBox txtEstadosCuentaObs;
        private System.Windows.Forms.RichTextBox txtContratoAperturaObs;
        private System.Windows.Forms.RichTextBox txtIdentificacionOficialObs;
        private System.Windows.Forms.RichTextBox txtOtroObs;
        private System.Windows.Forms.RichTextBox txtChequesObs;
        private System.Windows.Forms.RichTextBox txtComprobantesObs;
        private System.Windows.Forms.RichTextBox txtFichasRetiroObs;
        private System.Windows.Forms.RichTextBox txtFichasDepositoObs;
        private System.Windows.Forms.RichTextBox txtDispersionNominaObs;
        private System.Windows.Forms.RichTextBox txtMovElectronicosObs;
        private System.Windows.Forms.RadioButton rbtnInfSolicitadaForPar;
        private System.Windows.Forms.RadioButton rbtnInfSolicitadaAnex;
    }
}