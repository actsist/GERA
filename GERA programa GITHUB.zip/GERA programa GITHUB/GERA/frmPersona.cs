﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using document_management.entidades;

namespace document_management
{
    public partial class frmPersona : Form
    {
        List<clsPersona> personaList;
        int index;
        public frmPersona(List<clsPersona> personaList, int index)
        {
            InitializeComponent();
            this.index = index;
            this.personaList = personaList;

            if (index != -1)
            {
                txtFirmante.Text = personaList[index].Nombre;
                txtRFC.Text = personaList[index].Rfc;
            }
        }


        // Evento - Aceptar
        private void btnAceptar_Click(object sender, EventArgs e)
        {
            if (index != -1)
            {
                personaList[index].Rfc = txtRFC.Text;
                personaList[index].Nombre = txtFirmante.Text;
            }
            else
            {
                clsPersona persona = new clsPersona();
                persona.Rfc = txtRFC.Text;
                persona.Nombre = txtFirmante.Text;
                personaList.Add(persona);
            }
            this.Close();
        }

        // Evento - Regresar
        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
