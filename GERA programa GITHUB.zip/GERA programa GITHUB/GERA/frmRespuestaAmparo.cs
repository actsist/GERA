﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using document_management.controller;
using document_management.entidades;
using System.Diagnostics;

namespace document_management
{
    public partial class frmAmparo : Form
    {
        frmTipoDocumento frmTipoDocumento;
        string rutaDocumento;
        public frmAmparo(frmTipoDocumento frmTipoDocumento)
        {
            InitializeComponent();
            this.frmTipoDocumento = frmTipoDocumento;
            rutaDocumento = "";
        }

        // Evento - Cerrar
        private void btnRegreso_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Evento - Aceptar
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Generar(false);
        }

        // Evento - Cerrar 
        private void frmRespuestaNegativa_FormClosing(object sender, FormClosingEventArgs e)
        {
            frmTipoDocumento.Show();
        }

        // Evento - Generar y Nuevo documento
        private void btnGenerarNuevo_Click(object sender, EventArgs e)
        {
            if (Generar(false))
            {
                Limpiar();
            }
        }

        // Evento - Vista previa
        private void btnVistaPrevia_Click(object sender, EventArgs e)
        {
            Generar(true);
        }


        // Metodo - Generar
        public bool Generar(bool vistaPrevia)
        {
            if (cbDirigido.SelectedIndex == -1)
            {
                MessageBox.Show("El valor de 'Dirigido a' es requerido.", "Notificación");
                return false;
            }
            clsDocumento documento = new clsDocumento();
            documento.Fecha = dtpDocumentoFecha.Value.ToLongDateString();
            documento.Fecha = documento.Fecha.Substring(0, 1).ToUpper() + documento.Fecha.Substring(1, documento.Fecha.Length - 1);
            documento.Oficio = txtOficio.Text;
            documento.Expediente = txtExpediente.Text;
            documento.Folio = txtFolio.Text;
            documento.DirigidoDGA = cbDirigido.Text;
            documento.AutoridadSolicitante = txtAutoridadSolicitante.Text;
            documento.Observaciones = taObservaciones.Text.Replace("\r", "");
                                  
            // firma
            documento.Firmante = txtFirmante.Text;
            documento.ControlInterno = txtControlInterno.Text;
            documento.Puesto = txtPuesto.Text;

            sfd.FileName = "";
            // set filters - this can be done in properties as well
            sfd.Filter = "Text files (*.rtf)|*.rtf|PDF file (*.pdf)|*.pdf";

            // Generando documento final
            try
            {
                if (!vistaPrevia)
                {
                     // Crear nuevo documento
                    if (rutaDocumento.Equals(""))
                    {
                        if (sfd.ShowDialog() == DialogResult.OK)
                        {
                            rutaDocumento = sfd.FileName;
                       
                            if (sfd.FileName.ToLower().Trim().EndsWith(".pdf"))
                                DocumentGeneratorPdf.CrearDocumentoRespuestaAmparo(documento, rutaDocumento);
                            else
                                DocumentGeneratorRtf.CrearDocumentoRespuestaAmparo(documento, rutaDocumento);

                            MessageBox.Show("Se ha generado el documento correctamente.", "Notificación");
                            if (cbAbrirDocumento.Checked)
                                Process.Start(rutaDocumento);
                        }
                    }
                    // Actualizar documento
                    else
                    {
                        if (sfd.FileName.ToLower().Trim().EndsWith(".pdf"))
                            DocumentGeneratorPdf.CrearDocumentoRespuestaAmparo(documento, rutaDocumento);
                        else
                            DocumentGeneratorRtf.CrearDocumentoRespuestaAmparo(documento, rutaDocumento);

                        MessageBox.Show("Se actualizado el documento correctamente.", "Notificación");
                        if (cbAbrirDocumento.Checked)
                            Process.Start(rutaDocumento);
                    }
                }
                // Generando vista previa
                else
                {
                    rutaDocumento = "vista_previa_amparo.rtf";
                    DocumentGeneratorRtf.CrearDocumentoRespuestaAmparo(documento, rutaDocumento);
                    Process.Start(rutaDocumento);
                    rutaDocumento = "";
                }
                return true;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error");
                return false;
            }
        }

        // Metodo - Limpiar pantalla
        public void Limpiar()
        {
            dtpDocumentoFecha.Value = DateTime.Today;
            txtOficio.Text = "";
            txtExpediente.Text = "";
            txtFolio.Text = "";
            cbDirigido.SelectedIndex = -1;
            txtAutoridadSolicitante.Text = "";
            
            taObservaciones.Text = "";

            txtFirmante.Text = "";
            txtControlInterno.Text = "";
            txtPuesto.Text = "";

            rutaDocumento = "";
        }

       
    }
}
