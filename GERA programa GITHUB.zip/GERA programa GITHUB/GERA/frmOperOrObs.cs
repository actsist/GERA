﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using document_management.entidades;

namespace document_management
{
    public partial class frmOperOrObs : Form
    {
        clsDocumento documento;
        public frmOperOrObs(clsDocumento documento)
        {
            InitializeComponent();
            this.documento = documento;
            this.taOperObs.Text = documento.Observaciones;
        }

        // Evento - Cerrar
        private void btnRegreso_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            documento.Observaciones = taOperObs.Text.Replace("\r", "");
            this.Close();
        }
    }
}
