﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using document_management.entidades;
using document_management.controller;
using System.IO;
using System.Diagnostics;

namespace document_management
{
    public partial class frmRespuestaPositiva : Form
    {
        List<clsPersona> personaList;
        frmTipoDocumento frmTipoDocumento;
        clsDocumento documento;
        string rutaDocumento;
        public frmRespuestaPositiva(frmTipoDocumento frmTipoDocumento)
        {
            InitializeComponent();

            documento = new clsDocumento();
            personaList = new List<clsPersona>();
            this.frmTipoDocumento = frmTipoDocumento;
            rutaDocumento = "";

            ActualizarPersonas();
        }
               
        // Evento - Adicionar Persona
        private void btnPersonaAdicionar_Click(object sender, EventArgs e)
        {
            new frmPersona(personaList, -1).ShowDialog();
            ActualizarPersonas();
            cbxPersona.SelectedIndex = cbxPersona.Items.Count - 1;
            
        }
        // Evento - Modificar Persona
        private void btnPersonaModificar_Click(object sender, EventArgs e)
        {
            if (cbxPersona.SelectedIndex != -1)
            {
                int index = cbxPersona.SelectedIndex;
                new frmPersona(personaList, cbxPersona.SelectedIndex -1).ShowDialog();
                ActualizarPersonas();
                cbxPersona.SelectedIndex = index;
            }
            else
            {
                MessageBox.Show("Debe seleccionar una persona", "Notificación");
            }
        }
        // Evento - Eliminar Persona
        private void btnPersonaEliminar_Click(object sender, EventArgs e)
        {
            if (cbxPersona.SelectedIndex > 0)
            {
                personaList.RemoveAt(cbxPersona.SelectedIndex - 1);
                ActualizarPersonas();
            }
        }

        // Evento - Adicionar cuenta
        private void btnCuentaAdicionar_Click(object sender, EventArgs e)
        {
            if (cbxPersona.SelectedIndex > 0)
            {
                new frmCuenta(personaList, cbxPersona.SelectedIndex - 1, -1).ShowDialog();
                ActualizarCuentas();
            } 
            else 
            {
                MessageBox.Show("Debe seleccionar una persona", "Notificación");
            }
        }
        // Evento - Modificar cuenta
        private void btnCuentaModificar_Click(object sender, EventArgs e)
        {
            if (cbxPersona.SelectedIndex > 0)
            {
                if (lvCuentas.SelectedIndices.Count != 0)
                {
                    new frmCuenta(personaList, cbxPersona.SelectedIndex - 1, lvCuentas.SelectedIndices[0]).ShowDialog();
                }
                else
                {
                    MessageBox.Show("Debe seleccionar una cuenta", "Notificación");
                }
                ActualizarCuentas();
            }
            else
            {
                MessageBox.Show("Debe seleccionar una persona", "Notificación");
            }
        }
        // Evento - Eliminar cuenta
        private void btnCuentaEliminar_Click(object sender, EventArgs e)
        {
            if (cbxPersona.SelectedIndex > 0)
            {
                if (lvCuentas.SelectedIndices.Count != 0)
                {
                    personaList[cbxPersona.SelectedIndex - 1].CuentaList.RemoveAt(lvCuentas.SelectedIndices[0]);
                    ActualizarCuentas();
                }
                else
                {
                    MessageBox.Show("Debe seleccionar una cuenta", "Notificación");
                }
            }
            else
            {
                MessageBox.Show("Debe seleccionar una persona", "Notificación");
            }
        }

        // Event - Select Person
        private void cbxPersona_SelectedIndexChanged(object sender, EventArgs e)
        {
            ActualizarCuentas();
        }

        // Evento - Cerrar
        private void frmRespuestaPositiva_FormClosing(object sender, FormClosingEventArgs e)
        {
            frmTipoDocumento.Show();
        }
        // Evento - Salir
        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        // Evento - Generar documento
        private void btnGenerar_Click(object sender, EventArgs e)
        {
            GenerarDocumento(false);
        }

        // Evento - Generar y nuevo documento
        private void btnGenerarNuevo_Click(object sender, EventArgs e)
        {
            if (GenerarDocumento(false))
            {
                Limpiar();
            }
            
        }

        // Evento - Vista previa
        private void btnVistaPrevia_Click(object sender, EventArgs e)
        {
            GenerarDocumento(true);            
        }
        
        // Metodo - Generar documento
        public bool GenerarDocumento(bool vistaPrevia)
        {
            // Validacion
            if (txtOficio.Text.Equals(""))
            {
                MessageBox.Show("El valor del Oficio es requerido.", "Notificación");
                return false;
            }
            if (txtAutoridadSolicitante.Text.Equals(""))
            {
                MessageBox.Show("El valor de Autoridad solicitante es requerido.", "Notificación");
                return false;
            }
            if (cbDirigido.SelectedIndex == -1)
            {
                MessageBox.Show("El valor de 'Dirigido a' es requerido.", "Notificación");
                return false;
            }
            if (!rbtnTotal.Checked && !rbtnAclaracion.Checked && !rbtnNegativa.Checked && !rbtnParcial.Checked && !rbtnComplementaria.Checked)
            {
                MessageBox.Show("Debe seleccionar la menos una Respuesta a Requerimiento.", "Notificación");
                return false;
            }
            if (!rbtnInformacion.Checked && !rbtnDesbloqueo.Checked && !rbtnAseguramiento.Checked && !rbtnSituacionFondos.Checked)
            {
                MessageBox.Show("Debe seleccionar la menos un Asunto.", "Notificación");
                return false;
            }

            if (txtExpediente.Text.Equals("") && txtFolio.Text.Equals(""))
            {
                MessageBox.Show("Los valores de Expediente y Folio no pueden estár vacío simultaneamente.", "Notificación");
                return false;
            }
            if (!rbtnAntencionEjecucion.Checked && !rbtnAtencionLocaliacion.Checked)
            {
                MessageBox.Show("Al menos debe seleccionar la opción \"Se ha procedido a ejecutar  la instrucción\" o \"Se localizó información\".", "Notificación");
                return false;
            }
            for (int i = 0; i < personaList.Count; i++)
            {
                if (personaList[i].CuentaList == null || personaList[i].CuentaList.Count == 0)
                {
                    MessageBox.Show("Todas las personas deben tener al menos una cuenta asignada.", "Notificación");
                    return false;
                }
            }

            // Conformacion del documento
            documento.Fecha = dtpDocumentoFecha.Value.ToLongDateString();
            documento.Fecha = documento.Fecha.Substring(0, 1).ToUpper() + documento.Fecha.Substring(1, documento.Fecha.Length - 1);
            documento.Oficio = txtOficio.Text;
            documento.Expediente = txtExpediente.Text;
            documento.Folio = txtFolio.Text;
            documento.DirigidoDGA = cbDirigido.Text;
            documento.AutoridadSolicitante = txtAutoridadSolicitante.Text;

            // Respuesta a requerimiento
            if (rbtnTotal.Checked)
                documento.RespuestaRequerimiento = "Total";
            else if (rbtnAclaracion.Checked)
                documento.RespuestaRequerimiento = "Aclaracion";
            else if (rbtnNegativa.Checked)
                documento.RespuestaRequerimiento = "Negativa a petición específica";
            else if (rbtnParcial.Checked)
                documento.RespuestaRequerimiento = "Parcial";
            else if (rbtnComplementaria.Checked)
                documento.RespuestaRequerimiento = "Complementaria";

            // Asunto
            if (rbtnInformacion.Checked)
                documento.Asunto = "Información";
            else if (rbtnDesbloqueo.Checked)
                documento.Asunto = "Desbloqueo";
            else if (rbtnAseguramiento.Checked)
                documento.Asunto = "Aseguramiento";
            else if (rbtnSituacionFondos.Checked)
                documento.Asunto = "Transferencia o situación de fondos";

            // Atencion
            if (rbtnAntencionEjecucion.Checked)
            {
                documento.Atencion = "En atención al oficio señalado al rubro, nos permitimos " +
                     "hacer de su conocimiento que se ha procedido a ejecutar la instrucción de " +
                     "la autoridad requirente respecto a la(s) persona(s) que abajo se indica(n):";
            }
            else if (rbtnAtencionLocaliacion.Checked)
            {
                documento.Atencion = "En atención al oficio señalado al rubro  nos permitimos " +
                     "hacer de su conocimiento que se localizó información a nombre de la(s) " +
                     "persona(s) que se señala(n):";
            }

            // personas
            documento.ListPersonas = personaList;

            // firma
            documento.Firmante = txtFirmante.Text;
            documento.ControlInterno = txtControlInterno.Text;
            documento.Puesto = txtPuesto.Text;

            sfd.FileName = "";
            // set filters - this can be done in properties as well
            sfd.Filter = "Text files (*.rtf)|*.rtf|PDF file (*.pdf)|*.pdf";

            // Generando documento final
            try
            {
                if (!vistaPrevia)
                {
                    // Crear nuevo documento
                    if (rutaDocumento.Equals(""))
                    {
                        if (sfd.ShowDialog() == DialogResult.OK)
                        {
                       
                                rutaDocumento = sfd.FileName;
                                if (rutaDocumento.ToLower().Trim().EndsWith(".pdf"))
                                    DocumentGeneratorPdf.CrearDocumentoRespuestaPositiva(documento, rutaDocumento);
                                else
                                    DocumentGeneratorRtf.CrearDocumentoRespuestaPositiva(documento, rutaDocumento);

                                MessageBox.Show("Se ha generado el documento correctamente.", "Notificación");
                                if (cbAbrirDocumento.Checked)
                                    Process.Start(rutaDocumento);
                        }
                    }
                    // Actualizar documento
                    else
                    {
                        if (rutaDocumento.ToLower().Trim().EndsWith(".pdf"))
                            DocumentGeneratorPdf.CrearDocumentoRespuestaPositiva(documento, rutaDocumento);
                        else
                            DocumentGeneratorRtf.CrearDocumentoRespuestaPositiva(documento, rutaDocumento);

                        MessageBox.Show("Se actualizado el documento correctamente.", "Notificación");
                        if (cbAbrirDocumento.Checked)
                            Process.Start(rutaDocumento);
                    }
                }
                // Generando vista previa
                else
                {
                    rutaDocumento = "vista_previa_respuesta_positiva.rtf";
                    DocumentGeneratorRtf.CrearDocumentoRespuestaPositiva(documento, rutaDocumento);
                    Process.Start(rutaDocumento);
                    rutaDocumento = "";
                }
                return true;
            }
            catch (Exception e)
            {
                //Logs.LogFile(e.Message, e.ToString(), e.StackTrace);
                MessageBox.Show(e.Message, "Error");
                return false;
            }
        }

        // Metodo - Reacargar listado de personas
        public void ActualizarPersonas()
        {
            cbxPersona.Items.Clear();
            cbxPersona.Items.Add("<Seleccione>");
            for (int i = 0; i < personaList.Count; i++)
            {
                cbxPersona.Items.Add(personaList[i].Rfc + " - " + personaList[i].Nombre);
            }
            cbxPersona.SelectedIndex = 0;
        }
        // Metodo - Actualizar cuenta
        public void ActualizarCuentas()
        {
            lvCuentas.Items.Clear();
            if (cbxPersona.SelectedIndex > 0)
            {
                List<clsCuenta> cuentaList = personaList[cbxPersona.SelectedIndex - 1].CuentaList;
                for (int i = 0; i < cuentaList.Count; i++)
                {
                    lvCuentas.Items.Add((i+1).ToString());
                    lvCuentas.Items[i].SubItems.Add(cuentaList[i].NoCuenta);
                    lvCuentas.Items[i].SubItems.Add(cuentaList[i].Tipo);
                    lvCuentas.Items[i].SubItems.Add(cuentaList[i].Estatus);
                    lvCuentas.Items[i].SubItems.Add(cuentaList[i].Saldo);
                    lvCuentas.Items[i].SubItems.Add(cuentaList[i].Moneda);
                }
            }
            


        }
        // Limpiar Pantalla
        public void Limpiar()
        {
            dtpDocumentoFecha.Value = DateTime.Today;
            txtOficio.Text = "";
            txtExpediente.Text = "";
            txtFolio.Text = "";
            cbDirigido.SelectedIndex = -1;
            txtAutoridadSolicitante.Text = "";

            rbtnTotal.Checked = false;
            rbtnNegativa.Checked = false;
            rbtnParcial.Checked = false;
            rbtnComplementaria.Checked = false;
            
            rbtnInformacion.Checked = false;
            rbtnDesbloqueo.Checked = false; 
            rbtnAseguramiento.Checked = false;
            rbtnSituacionFondos.Checked = false; 
            
            rbtnAntencionEjecucion.Checked = false;
            rbtnAtencionLocaliacion.Checked = false;
            personaList = new List<clsPersona>();

            txtFirmante.Text = "";
            txtControlInterno.Text = "";
            txtPuesto.Text = "";

            lbObservaciones.Text = "";

            ActualizarPersonas();
            ActualizarCuentas();

            rutaDocumento = "";
        }

        private void frmRespuestaPositiva_Load(object sender, EventArgs e)
        {

        }

        // Evento Modificar Observaciones
        private void btnObsModificar_Click(object sender, EventArgs e)
        {
            frmOperOrObs frm = new frmOperOrObs(documento);
            frm.ShowDialog();
            if (documento.Observaciones.Length != 0)
            {
                if (documento.Observaciones.Length > 70)
                {
                    lbObservaciones.Text = "" + documento.Observaciones.Substring(0, 70).Replace("\n", " ") + "...";
                }
                else
                {
                    lbObservaciones.Text = "" + documento.Observaciones.Substring(0, documento.Observaciones.Length - 1).Replace("\n", " ");
                }
            }
        }

        // Evento - Eliminar Observaciones
        private void btnObsEliminar_Click(object sender, EventArgs e)
        {
            documento.Observaciones = "";
            lbObservaciones.Text = "";
        }
       

    }
}
