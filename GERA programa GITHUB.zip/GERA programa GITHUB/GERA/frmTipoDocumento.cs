﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace document_management
{
    public partial class frmTipoDocumento : Form
    {
        
        public frmTipoDocumento()
        {
            InitializeComponent(); 
        }

        private void btnRespuestaPositiva_Click(object sender, EventArgs e)
        {
            frmRespuestaPositiva frm = new frmRespuestaPositiva(this);
            frm.Show();
            this.Hide();
        }

        private void btnRespuestaNegativa_Click(object sender, EventArgs e)
        {
            frmRespuestaNegativa frm = new frmRespuestaNegativa(this);
            frm.Show();
            this.Hide();
        }

        private void btnAmparo_Click(object sender, EventArgs e)
        {
            frmAmparo frm = new frmAmparo(this);
            frm.Show();
            this.Hide();
        }
    }
}
