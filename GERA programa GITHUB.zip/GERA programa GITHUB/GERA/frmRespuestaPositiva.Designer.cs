﻿namespace document_management
{
    partial class frmRespuestaPositiva
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRespuestaPositiva));
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbtnComplementaria = new System.Windows.Forms.RadioButton();
            this.rbtnNegativa = new System.Windows.Forms.RadioButton();
            this.rbtnParcial = new System.Windows.Forms.RadioButton();
            this.rbtnAclaracion = new System.Windows.Forms.RadioButton();
            this.rbtnTotal = new System.Windows.Forms.RadioButton();
            this.btnSalir = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtOficio = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtExpediente = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtFolio = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rbtnSituacionFondos = new System.Windows.Forms.RadioButton();
            this.rbtnAseguramiento = new System.Windows.Forms.RadioButton();
            this.rbtnDesbloqueo = new System.Windows.Forms.RadioButton();
            this.rbtnInformacion = new System.Windows.Forms.RadioButton();
            this.rbtnAtencionLocaliacion = new System.Windows.Forms.RadioButton();
            this.rbtnAntencionEjecucion = new System.Windows.Forms.RadioButton();
            this.btnGenerar = new System.Windows.Forms.Button();
            this.btnCuentaEliminar = new System.Windows.Forms.Button();
            this.btnCuentaModificar = new System.Windows.Forms.Button();
            this.btnCuentaAdicionar = new System.Windows.Forms.Button();
            this.lvCuentas = new System.Windows.Forms.ListView();
            this.colNumber = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colNoCuenta = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTipo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstatus = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colSaldo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colMoneda = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.dtpDocumentoFecha = new System.Windows.Forms.DateTimePicker();
            this.txtControlInterno = new System.Windows.Forms.TextBox();
            this.txtPuesto = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtFirmante = new System.Windows.Forms.TextBox();
            this.cbxPersona = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnPersonaAdicionar = new System.Windows.Forms.Button();
            this.btnPersonaModificar = new System.Windows.Forms.Button();
            this.btnPersonaEliminar = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtAutoridadSolicitante = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.sfd = new System.Windows.Forms.SaveFileDialog();
            this.btnGenerarNuevo = new System.Windows.Forms.Button();
            this.cbAbrirDocumento = new System.Windows.Forms.CheckBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btnVistaPrevia = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.lbObservaciones = new System.Windows.Forms.Label();
            this.btnObsEliminar = new System.Windows.Forms.Button();
            this.btnObsModificar = new System.Windows.Forms.Button();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 15);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Fecha:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbtnComplementaria);
            this.groupBox1.Controls.Add(this.rbtnNegativa);
            this.groupBox1.Controls.Add(this.rbtnParcial);
            this.groupBox1.Controls.Add(this.rbtnAclaracion);
            this.groupBox1.Controls.Add(this.rbtnTotal);
            this.groupBox1.Location = new System.Drawing.Point(419, 11);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(444, 89);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Respuesta a Requerimiento:";
            // 
            // rbtnComplementaria
            // 
            this.rbtnComplementaria.AutoSize = true;
            this.rbtnComplementaria.Location = new System.Drawing.Point(115, 55);
            this.rbtnComplementaria.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnComplementaria.Name = "rbtnComplementaria";
            this.rbtnComplementaria.Size = new System.Drawing.Size(131, 21);
            this.rbtnComplementaria.TabIndex = 5;
            this.rbtnComplementaria.TabStop = true;
            this.rbtnComplementaria.Text = "Complementaria";
            this.rbtnComplementaria.UseVisualStyleBackColor = true;
            // 
            // rbtnNegativa
            // 
            this.rbtnNegativa.AutoSize = true;
            this.rbtnNegativa.Location = new System.Drawing.Point(268, 15);
            this.rbtnNegativa.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnNegativa.Name = "rbtnNegativa";
            this.rbtnNegativa.Size = new System.Drawing.Size(154, 38);
            this.rbtnNegativa.TabIndex = 3;
            this.rbtnNegativa.TabStop = true;
            this.rbtnNegativa.Text = "Negativa a petición \r\nespecífica";
            this.rbtnNegativa.UseVisualStyleBackColor = true;
            this.rbtnNegativa.Visible = false;
            // 
            // rbtnParcial
            // 
            this.rbtnParcial.AutoSize = true;
            this.rbtnParcial.Location = new System.Drawing.Point(8, 55);
            this.rbtnParcial.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnParcial.Name = "rbtnParcial";
            this.rbtnParcial.Size = new System.Drawing.Size(72, 21);
            this.rbtnParcial.TabIndex = 4;
            this.rbtnParcial.TabStop = true;
            this.rbtnParcial.Text = "Parcial";
            this.rbtnParcial.UseVisualStyleBackColor = true;
            // 
            // rbtnAclaracion
            // 
            this.rbtnAclaracion.AutoSize = true;
            this.rbtnAclaracion.Location = new System.Drawing.Point(115, 23);
            this.rbtnAclaracion.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnAclaracion.Name = "rbtnAclaracion";
            this.rbtnAclaracion.Size = new System.Drawing.Size(95, 21);
            this.rbtnAclaracion.TabIndex = 2;
            this.rbtnAclaracion.TabStop = true;
            this.rbtnAclaracion.Text = "Aclaración";
            this.rbtnAclaracion.UseVisualStyleBackColor = true;
            // 
            // rbtnTotal
            // 
            this.rbtnTotal.AutoSize = true;
            this.rbtnTotal.Location = new System.Drawing.Point(8, 23);
            this.rbtnTotal.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnTotal.Name = "rbtnTotal";
            this.rbtnTotal.Size = new System.Drawing.Size(61, 21);
            this.rbtnTotal.TabIndex = 1;
            this.rbtnTotal.TabStop = true;
            this.rbtnTotal.Text = "Total";
            this.rbtnTotal.UseVisualStyleBackColor = true;
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(789, 807);
            this.btnSalir.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(100, 28);
            this.btnSalir.TabIndex = 23;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 47);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 17);
            this.label2.TabIndex = 7;
            this.label2.Text = "Oficio:";
            // 
            // txtOficio
            // 
            this.txtOficio.Location = new System.Drawing.Point(152, 43);
            this.txtOficio.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtOficio.Name = "txtOficio";
            this.txtOficio.Size = new System.Drawing.Size(257, 22);
            this.txtOficio.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 79);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 17);
            this.label3.TabIndex = 9;
            this.label3.Text = "Expediente:";
            // 
            // txtExpediente
            // 
            this.txtExpediente.Location = new System.Drawing.Point(152, 75);
            this.txtExpediente.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtExpediente.Name = "txtExpediente";
            this.txtExpediente.Size = new System.Drawing.Size(257, 22);
            this.txtExpediente.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(4, 111);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 17);
            this.label4.TabIndex = 11;
            this.label4.Text = "Folio:";
            // 
            // txtFolio
            // 
            this.txtFolio.Location = new System.Drawing.Point(152, 107);
            this.txtFolio.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtFolio.Name = "txtFolio";
            this.txtFolio.Size = new System.Drawing.Size(257, 22);
            this.txtFolio.TabIndex = 3;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rbtnSituacionFondos);
            this.groupBox2.Controls.Add(this.rbtnAseguramiento);
            this.groupBox2.Controls.Add(this.rbtnDesbloqueo);
            this.groupBox2.Controls.Add(this.rbtnInformacion);
            this.groupBox2.Location = new System.Drawing.Point(419, 111);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Size = new System.Drawing.Size(444, 89);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Asunto:";
            // 
            // rbtnSituacionFondos
            // 
            this.rbtnSituacionFondos.AutoSize = true;
            this.rbtnSituacionFondos.Location = new System.Drawing.Point(8, 57);
            this.rbtnSituacionFondos.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnSituacionFondos.Name = "rbtnSituacionFondos";
            this.rbtnSituacionFondos.Size = new System.Drawing.Size(256, 21);
            this.rbtnSituacionFondos.TabIndex = 4;
            this.rbtnSituacionFondos.TabStop = true;
            this.rbtnSituacionFondos.Text = "Transferencia o situación de fondos";
            this.rbtnSituacionFondos.UseVisualStyleBackColor = true;
            // 
            // rbtnAseguramiento
            // 
            this.rbtnAseguramiento.AutoSize = true;
            this.rbtnAseguramiento.Location = new System.Drawing.Point(317, 23);
            this.rbtnAseguramiento.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnAseguramiento.Name = "rbtnAseguramiento";
            this.rbtnAseguramiento.Size = new System.Drawing.Size(124, 21);
            this.rbtnAseguramiento.TabIndex = 3;
            this.rbtnAseguramiento.TabStop = true;
            this.rbtnAseguramiento.Text = "Aseguramiento";
            this.rbtnAseguramiento.UseVisualStyleBackColor = true;
            // 
            // rbtnDesbloqueo
            // 
            this.rbtnDesbloqueo.AutoSize = true;
            this.rbtnDesbloqueo.Location = new System.Drawing.Point(167, 23);
            this.rbtnDesbloqueo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnDesbloqueo.Name = "rbtnDesbloqueo";
            this.rbtnDesbloqueo.Size = new System.Drawing.Size(105, 21);
            this.rbtnDesbloqueo.TabIndex = 2;
            this.rbtnDesbloqueo.TabStop = true;
            this.rbtnDesbloqueo.Text = "Desbloqueo";
            this.rbtnDesbloqueo.UseVisualStyleBackColor = true;
            // 
            // rbtnInformacion
            // 
            this.rbtnInformacion.AutoSize = true;
            this.rbtnInformacion.Location = new System.Drawing.Point(8, 23);
            this.rbtnInformacion.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnInformacion.Name = "rbtnInformacion";
            this.rbtnInformacion.Size = new System.Drawing.Size(102, 21);
            this.rbtnInformacion.TabIndex = 1;
            this.rbtnInformacion.TabStop = true;
            this.rbtnInformacion.Text = "Información";
            this.rbtnInformacion.UseVisualStyleBackColor = true;
            // 
            // rbtnAtencionLocaliacion
            // 
            this.rbtnAtencionLocaliacion.AutoSize = true;
            this.rbtnAtencionLocaliacion.Location = new System.Drawing.Point(17, 42);
            this.rbtnAtencionLocaliacion.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnAtencionLocaliacion.Name = "rbtnAtencionLocaliacion";
            this.rbtnAtencionLocaliacion.Size = new System.Drawing.Size(831, 38);
            this.rbtnAtencionLocaliacion.TabIndex = 9;
            this.rbtnAtencionLocaliacion.TabStop = true;
            this.rbtnAtencionLocaliacion.Text = "En atención al oficio señalado al rubro  nos permitimos hacer de su conocimiento " +
    "que se localizó información a nombre de la(s)\r\n persona(s) que se señala(n):";
            this.rbtnAtencionLocaliacion.UseVisualStyleBackColor = true;
            // 
            // rbtnAntencionEjecucion
            // 
            this.rbtnAntencionEjecucion.AutoSize = true;
            this.rbtnAntencionEjecucion.Location = new System.Drawing.Point(17, 2);
            this.rbtnAntencionEjecucion.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnAntencionEjecucion.Name = "rbtnAntencionEjecucion";
            this.rbtnAntencionEjecucion.Size = new System.Drawing.Size(852, 38);
            this.rbtnAntencionEjecucion.TabIndex = 8;
            this.rbtnAntencionEjecucion.TabStop = true;
            this.rbtnAntencionEjecucion.Text = resources.GetString("rbtnAntencionEjecucion.Text");
            this.rbtnAntencionEjecucion.UseVisualStyleBackColor = true;
            // 
            // btnGenerar
            // 
            this.btnGenerar.Location = new System.Drawing.Point(524, 807);
            this.btnGenerar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnGenerar.Name = "btnGenerar";
            this.btnGenerar.Size = new System.Drawing.Size(115, 28);
            this.btnGenerar.TabIndex = 21;
            this.btnGenerar.Text = "Guardar";
            this.btnGenerar.UseVisualStyleBackColor = true;
            this.btnGenerar.Click += new System.EventHandler(this.btnGenerar_Click);
            // 
            // btnCuentaEliminar
            // 
            this.btnCuentaEliminar.Location = new System.Drawing.Point(764, 193);
            this.btnCuentaEliminar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCuentaEliminar.Name = "btnCuentaEliminar";
            this.btnCuentaEliminar.Size = new System.Drawing.Size(100, 28);
            this.btnCuentaEliminar.TabIndex = 16;
            this.btnCuentaEliminar.Text = "Eliminar";
            this.btnCuentaEliminar.UseVisualStyleBackColor = true;
            this.btnCuentaEliminar.Click += new System.EventHandler(this.btnCuentaEliminar_Click);
            // 
            // btnCuentaModificar
            // 
            this.btnCuentaModificar.Location = new System.Drawing.Point(656, 193);
            this.btnCuentaModificar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCuentaModificar.Name = "btnCuentaModificar";
            this.btnCuentaModificar.Size = new System.Drawing.Size(100, 28);
            this.btnCuentaModificar.TabIndex = 15;
            this.btnCuentaModificar.Text = "Modificar";
            this.btnCuentaModificar.UseVisualStyleBackColor = true;
            this.btnCuentaModificar.Click += new System.EventHandler(this.btnCuentaModificar_Click);
            // 
            // btnCuentaAdicionar
            // 
            this.btnCuentaAdicionar.Location = new System.Drawing.Point(548, 193);
            this.btnCuentaAdicionar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCuentaAdicionar.Name = "btnCuentaAdicionar";
            this.btnCuentaAdicionar.Size = new System.Drawing.Size(100, 28);
            this.btnCuentaAdicionar.TabIndex = 14;
            this.btnCuentaAdicionar.Text = "Añadir";
            this.btnCuentaAdicionar.UseVisualStyleBackColor = true;
            this.btnCuentaAdicionar.Click += new System.EventHandler(this.btnCuentaAdicionar_Click);
            // 
            // lvCuentas
            // 
            this.lvCuentas.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colNumber,
            this.colNoCuenta,
            this.colTipo,
            this.colEstatus,
            this.colSaldo,
            this.colMoneda});
            this.lvCuentas.HideSelection = false;
            this.lvCuentas.Location = new System.Drawing.Point(9, 62);
            this.lvCuentas.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lvCuentas.Name = "lvCuentas";
            this.lvCuentas.Size = new System.Drawing.Size(852, 123);
            this.lvCuentas.TabIndex = 20;
            this.lvCuentas.UseCompatibleStateImageBehavior = false;
            this.lvCuentas.View = System.Windows.Forms.View.Details;
            // 
            // colNumber
            // 
            this.colNumber.Text = "";
            this.colNumber.Width = 20;
            // 
            // colNoCuenta
            // 
            this.colNoCuenta.Text = "No. Cuenta";
            this.colNoCuenta.Width = 100;
            // 
            // colTipo
            // 
            this.colTipo.Text = "Tipo";
            this.colTipo.Width = 120;
            // 
            // colEstatus
            // 
            this.colEstatus.Text = "Estatus";
            this.colEstatus.Width = 80;
            // 
            // colSaldo
            // 
            this.colSaldo.Text = "Saldo";
            this.colSaldo.Width = 80;
            // 
            // colMoneda
            // 
            this.colMoneda.Text = "Moneda";
            this.colMoneda.Width = 191;
            // 
            // dtpDocumentoFecha
            // 
            this.dtpDocumentoFecha.CustomFormat = "";
            this.dtpDocumentoFecha.Location = new System.Drawing.Point(152, 11);
            this.dtpDocumentoFecha.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtpDocumentoFecha.Name = "dtpDocumentoFecha";
            this.dtpDocumentoFecha.Size = new System.Drawing.Size(257, 22);
            this.dtpDocumentoFecha.TabIndex = 0;
            // 
            // txtControlInterno
            // 
            this.txtControlInterno.Location = new System.Drawing.Point(584, 26);
            this.txtControlInterno.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtControlInterno.Name = "txtControlInterno";
            this.txtControlInterno.Size = new System.Drawing.Size(279, 22);
            this.txtControlInterno.TabIndex = 19;
            // 
            // txtPuesto
            // 
            this.txtPuesto.Location = new System.Drawing.Point(296, 26);
            this.txtPuesto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtPuesto.Name = "txtPuesto";
            this.txtPuesto.Size = new System.Drawing.Size(279, 22);
            this.txtPuesto.TabIndex = 18;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(580, 6);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 17);
            this.label6.TabIndex = 29;
            this.label6.Text = "Control interno:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(292, 6);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 17);
            this.label7.TabIndex = 28;
            this.label7.Text = "Puesto:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(4, 6);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 17);
            this.label8.TabIndex = 27;
            this.label8.Text = "Firmante:";
            // 
            // txtFirmante
            // 
            this.txtFirmante.Location = new System.Drawing.Point(8, 26);
            this.txtFirmante.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtFirmante.Name = "txtFirmante";
            this.txtFirmante.Size = new System.Drawing.Size(279, 22);
            this.txtFirmante.TabIndex = 17;
            // 
            // cbxPersona
            // 
            this.cbxPersona.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxPersona.FormattingEnabled = true;
            this.cbxPersona.Location = new System.Drawing.Point(121, 9);
            this.cbxPersona.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbxPersona.Name = "cbxPersona";
            this.cbxPersona.Size = new System.Drawing.Size(500, 24);
            this.cbxPersona.TabIndex = 10;
            this.cbxPersona.SelectedIndexChanged += new System.EventHandler(this.cbxPersona_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(11, 12);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(102, 17);
            this.label9.TabIndex = 34;
            this.label9.Text = "RFC - Nombre:";
            // 
            // btnPersonaAdicionar
            // 
            this.btnPersonaAdicionar.Location = new System.Drawing.Point(631, 9);
            this.btnPersonaAdicionar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnPersonaAdicionar.Name = "btnPersonaAdicionar";
            this.btnPersonaAdicionar.Size = new System.Drawing.Size(69, 28);
            this.btnPersonaAdicionar.TabIndex = 11;
            this.btnPersonaAdicionar.Text = "Añadir";
            this.btnPersonaAdicionar.UseVisualStyleBackColor = true;
            this.btnPersonaAdicionar.Click += new System.EventHandler(this.btnPersonaAdicionar_Click);
            // 
            // btnPersonaModificar
            // 
            this.btnPersonaModificar.Location = new System.Drawing.Point(708, 9);
            this.btnPersonaModificar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnPersonaModificar.Name = "btnPersonaModificar";
            this.btnPersonaModificar.Size = new System.Drawing.Size(77, 28);
            this.btnPersonaModificar.TabIndex = 12;
            this.btnPersonaModificar.Text = "Modificar";
            this.btnPersonaModificar.UseVisualStyleBackColor = true;
            this.btnPersonaModificar.Click += new System.EventHandler(this.btnPersonaModificar_Click);
            // 
            // btnPersonaEliminar
            // 
            this.btnPersonaEliminar.Location = new System.Drawing.Point(793, 9);
            this.btnPersonaEliminar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnPersonaEliminar.Name = "btnPersonaEliminar";
            this.btnPersonaEliminar.Size = new System.Drawing.Size(69, 28);
            this.btnPersonaEliminar.TabIndex = 13;
            this.btnPersonaEliminar.Text = "Eliminar";
            this.btnPersonaEliminar.UseVisualStyleBackColor = true;
            this.btnPersonaEliminar.Click += new System.EventHandler(this.btnPersonaEliminar_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.txtAutoridadSolicitante);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.dtpDocumentoFecha);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtFolio);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.txtExpediente);
            this.panel1.Controls.Add(this.txtOficio);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Location = new System.Drawing.Point(16, 39);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(874, 217);
            this.panel1.TabIndex = 37;
            // 
            // txtAutoridadSolicitante
            // 
            this.txtAutoridadSolicitante.Location = new System.Drawing.Point(152, 139);
            this.txtAutoridadSolicitante.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtAutoridadSolicitante.Name = "txtAutoridadSolicitante";
            this.txtAutoridadSolicitante.Size = new System.Drawing.Size(257, 22);
            this.txtAutoridadSolicitante.TabIndex = 4;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(4, 143);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(140, 17);
            this.label14.TabIndex = 17;
            this.label14.Text = "Autoridad solicitante:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightGray;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label11);
            this.panel2.Location = new System.Drawing.Point(16, 10);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(874, 30);
            this.panel2.TabIndex = 38;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(343, 7);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(174, 20);
            this.label11.TabIndex = 0;
            this.label11.Text = "DATOS GENERALES";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.panel7);
            this.panel3.Controls.Add(this.lvCuentas);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.btnCuentaEliminar);
            this.panel3.Controls.Add(this.btnPersonaAdicionar);
            this.panel3.Controls.Add(this.cbxPersona);
            this.panel3.Controls.Add(this.btnPersonaEliminar);
            this.panel3.Controls.Add(this.btnCuentaModificar);
            this.panel3.Controls.Add(this.btnCuentaAdicionar);
            this.panel3.Controls.Add(this.btnPersonaModificar);
            this.panel3.Location = new System.Drawing.Point(16, 388);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(874, 232);
            this.panel3.TabIndex = 39;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.LightGray;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.label10);
            this.panel7.Location = new System.Drawing.Point(9, 44);
            this.panel7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(853, 18);
            this.panel7.TabIndex = 40;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(3, 0);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(130, 17);
            this.label10.TabIndex = 0;
            this.label10.Text = "Listado de Cuentas";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.LightGray;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label12);
            this.panel4.Location = new System.Drawing.Point(16, 358);
            this.panel4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(874, 30);
            this.panel4.TabIndex = 39;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(375, 6);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(101, 20);
            this.label12.TabIndex = 0;
            this.label12.Text = "PERSONAS";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.LightGray;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.label13);
            this.panel5.Location = new System.Drawing.Point(15, 711);
            this.panel5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(874, 30);
            this.panel5.TabIndex = 40;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(393, 6);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 20);
            this.label13.TabIndex = 0;
            this.label13.Text = "FIRMA";
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.label8);
            this.panel6.Controls.Add(this.txtControlInterno);
            this.panel6.Controls.Add(this.label6);
            this.panel6.Controls.Add(this.txtFirmante);
            this.panel6.Controls.Add(this.label7);
            this.panel6.Controls.Add(this.txtPuesto);
            this.panel6.Location = new System.Drawing.Point(15, 741);
            this.panel6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(874, 59);
            this.panel6.TabIndex = 41;
            // 
            // btnGenerarNuevo
            // 
            this.btnGenerarNuevo.Location = new System.Drawing.Point(647, 807);
            this.btnGenerarNuevo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnGenerarNuevo.Name = "btnGenerarNuevo";
            this.btnGenerarNuevo.Size = new System.Drawing.Size(135, 28);
            this.btnGenerarNuevo.TabIndex = 22;
            this.btnGenerarNuevo.Text = "Guardar y nuevo";
            this.btnGenerarNuevo.UseVisualStyleBackColor = true;
            this.btnGenerarNuevo.Click += new System.EventHandler(this.btnGenerarNuevo_Click);
            // 
            // cbAbrirDocumento
            // 
            this.cbAbrirDocumento.AutoSize = true;
            this.cbAbrirDocumento.Location = new System.Drawing.Point(15, 807);
            this.cbAbrirDocumento.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbAbrirDocumento.Name = "cbAbrirDocumento";
            this.cbAbrirDocumento.Size = new System.Drawing.Size(203, 21);
            this.cbAbrirDocumento.TabIndex = 20;
            this.cbAbrirDocumento.Text = "Abrir documento al generar";
            this.cbAbrirDocumento.UseVisualStyleBackColor = true;
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.rbtnAntencionEjecucion);
            this.panel8.Controls.Add(this.rbtnAtencionLocaliacion);
            this.panel8.Location = new System.Drawing.Point(16, 265);
            this.panel8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(874, 86);
            this.panel8.TabIndex = 42;
            // 
            // btnVistaPrevia
            // 
            this.btnVistaPrevia.Location = new System.Drawing.Point(363, 807);
            this.btnVistaPrevia.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnVistaPrevia.Name = "btnVistaPrevia";
            this.btnVistaPrevia.Size = new System.Drawing.Size(115, 28);
            this.btnVistaPrevia.TabIndex = 47;
            this.btnVistaPrevia.Text = "Vista Previa";
            this.btnVistaPrevia.UseVisualStyleBackColor = true;
            this.btnVistaPrevia.Click += new System.EventHandler(this.btnVistaPrevia_Click);
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.lbObservaciones);
            this.panel9.Controls.Add(this.btnObsEliminar);
            this.panel9.Controls.Add(this.btnObsModificar);
            this.panel9.Location = new System.Drawing.Point(15, 657);
            this.panel9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(874, 46);
            this.panel9.TabIndex = 43;
            // 
            // lbObservaciones
            // 
            this.lbObservaciones.AutoSize = true;
            this.lbObservaciones.Location = new System.Drawing.Point(15, 14);
            this.lbObservaciones.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbObservaciones.Name = "lbObservaciones";
            this.lbObservaciones.Size = new System.Drawing.Size(0, 17);
            this.lbObservaciones.TabIndex = 18;
            // 
            // btnObsEliminar
            // 
            this.btnObsEliminar.Location = new System.Drawing.Point(768, 7);
            this.btnObsEliminar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnObsEliminar.Name = "btnObsEliminar";
            this.btnObsEliminar.Size = new System.Drawing.Size(100, 28);
            this.btnObsEliminar.TabIndex = 49;
            this.btnObsEliminar.Text = "Eliminar";
            this.btnObsEliminar.UseVisualStyleBackColor = true;
            this.btnObsEliminar.Click += new System.EventHandler(this.btnObsEliminar_Click);
            // 
            // btnObsModificar
            // 
            this.btnObsModificar.Location = new System.Drawing.Point(660, 7);
            this.btnObsModificar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnObsModificar.Name = "btnObsModificar";
            this.btnObsModificar.Size = new System.Drawing.Size(100, 28);
            this.btnObsModificar.TabIndex = 48;
            this.btnObsModificar.Text = "Añadir";
            this.btnObsModificar.UseVisualStyleBackColor = true;
            this.btnObsModificar.Click += new System.EventHandler(this.btnObsModificar_Click);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.LightGray;
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.label18);
            this.panel10.Location = new System.Drawing.Point(15, 628);
            this.panel10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(874, 30);
            this.panel10.TabIndex = 42;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(393, 6);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(153, 20);
            this.label18.TabIndex = 0;
            this.label18.Text = "OBSERVACIONES";
            // 
            // frmRespuestaPositiva
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(905, 848);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.btnVistaPrevia);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.cbAbrirDocumento);
            this.Controls.Add(this.btnGenerarNuevo);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnGenerar);
            this.Controls.Add(this.btnSalir);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmRespuestaPositiva";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GERA - Documento";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmRespuestaPositiva_FormClosing);
            this.Load += new System.EventHandler(this.frmRespuestaPositiva_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtOficio;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtExpediente;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtFolio;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rbtnAtencionLocaliacion;
        private System.Windows.Forms.RadioButton rbtnAntencionEjecucion;
        private System.Windows.Forms.Button btnGenerar;
        private System.Windows.Forms.Button btnCuentaEliminar;
        private System.Windows.Forms.Button btnCuentaModificar;
        private System.Windows.Forms.Button btnCuentaAdicionar;
        private System.Windows.Forms.ListView lvCuentas;
        private System.Windows.Forms.ColumnHeader colNoCuenta;
        private System.Windows.Forms.ColumnHeader colTipo;
        private System.Windows.Forms.ColumnHeader colEstatus;
        private System.Windows.Forms.ColumnHeader colSaldo;
        private System.Windows.Forms.ColumnHeader colMoneda;
        private System.Windows.Forms.TextBox txtControlInterno;
        private System.Windows.Forms.TextBox txtPuesto;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtFirmante;
        private System.Windows.Forms.ComboBox cbxPersona;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnPersonaAdicionar;
        private System.Windows.Forms.Button btnPersonaModificar;
        private System.Windows.Forms.Button btnPersonaEliminar;
        private System.Windows.Forms.ColumnHeader colNumber;
        private System.Windows.Forms.DateTimePicker dtpDocumentoFecha;
        private System.Windows.Forms.RadioButton rbtnComplementaria;
        private System.Windows.Forms.RadioButton rbtnNegativa;
        private System.Windows.Forms.RadioButton rbtnParcial;
        private System.Windows.Forms.RadioButton rbtnAclaracion;
        private System.Windows.Forms.RadioButton rbtnTotal;
        private System.Windows.Forms.RadioButton rbtnSituacionFondos;
        private System.Windows.Forms.RadioButton rbtnAseguramiento;
        private System.Windows.Forms.RadioButton rbtnDesbloqueo;
        private System.Windows.Forms.RadioButton rbtnInformacion;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.SaveFileDialog sfd;
        private System.Windows.Forms.Button btnGenerarNuevo;
        private System.Windows.Forms.CheckBox cbAbrirDocumento;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button btnVistaPrevia;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label lbObservaciones;
        private System.Windows.Forms.Button btnObsEliminar;
        private System.Windows.Forms.Button btnObsModificar;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtAutoridadSolicitante;
        private System.Windows.Forms.Label label14;
    }
}

