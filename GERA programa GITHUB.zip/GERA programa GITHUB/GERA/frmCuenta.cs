﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using document_management.entidades;
using System.Globalization;

namespace document_management
{
    public partial class frmCuenta : Form
    {
        List<clsPersona> personaList;
        int personIndex;
        int index;

        public frmCuenta(List<clsPersona> personaList, int personIndex, int index)
        {
            InitializeComponent();
            this.index = index;
            this.personIndex = personIndex;
            this.personaList = personaList;
            
            CargarCuenta();
        }

        // Evento - Habilitar y Deshabilitar panel de Documentacion
        private void cbDocumentacion_CheckedChanged(object sender, EventArgs e)
        {
            pnlDocumentacion.Enabled = cbDocumentacion.Checked;
        }
        // Evento - Habilitar y Deshabilitar panel de Documentacion y Operaciones
        private void cbDocumentacionOper_CheckedChanged(object sender, EventArgs e)
        {
            pnlDocumentacionOper.Enabled = cbDocumentacionOper.Checked;
        }
        // Evento - Habilitar y Deshabilitar panel de Movimientos Electronicos
        private void cbMovimientosElec_CheckedChanged(object sender, EventArgs e)
        {
            pnlMovimientoElec.Enabled = cbMovimientosElec.Checked;
        }

        // Evento - Dar formato al valor del saldo
        private void txtSaldo_Leave(object sender, EventArgs e)
        {
            string initText = txtSaldo.Text;

            if (txtSaldo.Text != "")
            {
                try
                {
                    txtSaldo.Text = Double.Parse(txtSaldo.Text).ToString("C", CultureInfo.CurrentCulture);
                }
                catch (Exception)
                {
                    //MessageBox.Show("El valor especificado para el campo no es válido.", "Notificación");
                }
            }
        }

        // Evneto - Aceptar
        private void btnAceptar_Click(object sender, EventArgs e)
        {
            if (GuardarCuenta())
            {
                this.Close();
            }
        }
        // Evento - Cerrar
        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Metodo - Guardar cuenta
        public bool GuardarCuenta()
        {
            // VALIDACION ---------------------------------------
            if (!Validacion())
                return false;
            
            // DATOS DE LA CUENTA -------------------------------
            clsCuenta cuenta = new clsCuenta();
            cuenta.NoCuenta = txtCuenta.Text;
            
            if (cbxTipo.SelectedIndex > 0)
                cuenta.Tipo = cbxTipo.SelectedItem.ToString();

            if (cbxEstatus.SelectedIndex > 0)
                cuenta.Estatus = cbxEstatus.SelectedItem.ToString();

            if (cbxCaracter.SelectedIndex > 0)
                cuenta.Catacter = cbxCaracter.SelectedItem.ToString();
            
            cuenta.Saldo = txtSaldo.Text;

            if (cbxMoneda.SelectedIndex > 0)
                cuenta.Moneda = cbxMoneda.SelectedItem.ToString();

            cuenta.UbicacionSucursal = txtUbicacionOrSucursal.Text;
            cuenta.Observaciones = taObservaciones.Text.Replace("\r", "");

            // DOCUMENTACION ------------------------------------
             clsDocumentacion documentacion = null;
            if (cbDocumentacion.Checked)
            {
                documentacion = new clsDocumentacion();
                documentacion.EstadoCuenta = cbxEstadoCuenta.Checked;
                documentacion.EstadoCuentaApl = cbxEstadoCuentaApl.Text;
                documentacion.EstadoCuentaDesde = dtpEDCDesde.Value;
                documentacion.EstadoCuentaHasta = dtpEDCHasta.Value;
                if (cbxEstadoCuenta.Checked)
                {
                    documentacion.EstadoCuentaCs = rbtnEstadoCuentaCS.Checked;
                    documentacion.EstadoCuentaCc = rbtnEstadosCuentaCC.Checked;
                    documentacion.EstadoCuentaObs = txtEstadosCuentaObs.Text;
                }

                documentacion.IdentificacionOficial = cbIdentificacionOficial.Checked;
                documentacion.IdentificacionOficialApl = cbIdentificacionOficialApl.Text;
                if (cbIdentificacionOficial.Checked)
                {
                    documentacion.IdentificacionOficialCs = rbtnIdentificacionOficialCS.Checked;
                    documentacion.IdentificacionOficialCc = rbtnIdentificacionOficialCC.Checked;
                    documentacion.IdentificacionOficialObs = txtIdentificacionOficialObs.Text;
                }

                documentacion.ContratoApertura = cbContratoApertura.Checked;
                documentacion.ContratoAperturaApl = cbContratoAperturaApl.Text;
                if (cbContratoApertura.Checked)
                {
                    documentacion.ContratoAperturaCs = rbtnContratoAperturaCS.Checked;
                    documentacion.ContratoAperturaCc = rbtnContratoAperturaCC.Checked;
                    documentacion.ContratoAperturaObs = txtContratoAperturaObs.Text;
                }

                documentacion.PoderNotarial = cbPoderNotarial.Checked;
                documentacion.PoderNotarialApl = cbPoderNotarialApl.Text;
                if (cbPoderNotarial.Checked)
                {
                    documentacion.PoderNotarialCs = rbtnPoderNotarialCS.Checked;
                    documentacion.PoderNotarialCc = rbtnPoderNotarialCC.Checked;
                    documentacion.PoderNotarialObs = txtPoderNotarialObs.Text;
                }

                documentacion.ComprobanteDomicilio = cbComprobanteDomicilio.Checked;
                documentacion.ComprobanteDomicilioApl = cbComprobanteDomicilioApl.Text;
                if (cbComprobanteDomicilio.Checked)
                {
                    documentacion.ComprobanteDomicilioCs = rbtnComprobanteDomicilioCs.Checked;
                    documentacion.ComprobanteDomicilioCc = rbtnComprobanteDomicilioCc.Checked;
                    documentacion.ComprobanteDomicilioObs = txtComprobanteDomicilioObs.Text;
                }

                documentacion.TarjetaFirmas = cbTarjetaFirmas.Checked;
                documentacion.TarjetaFirmasApl = cbTarjetaFirmasApl.Text;
                if (cbTarjetaFirmas.Checked)
                {
                    documentacion.TarjetaFirmasCs = rbtnTarjetaFirmasCs.Checked;
                    documentacion.TarjetaFirmasCc = rbtnTarjetaFirmasCc.Checked;
                    documentacion.TarjetaFirmasObs = txtTarjetaFirmasObs.Text;
                }

                cuenta.Documentacion = documentacion;

                
            }

            // OPERACIONES --------------------------------------
            clsOperaciones operaciones = null;
            if (cbDocumentacionOper.Checked)
            {
                operaciones = new clsOperaciones();
                operaciones.Cheques = cbCheques.Checked;
                operaciones.ChequesApl = cbChequesApl.Text;
                if (cbCheques.Checked)
                {
                    operaciones.ChequesCs = rbtnChequesCS.Checked;
                    operaciones.ChequesCc = rbtnChequesCC.Checked;
                    operaciones.ChequesObs = txtChequesObs.Text;
                }

                operaciones.FichaDeposito = cbFichasDeposito.Checked;
                operaciones.FichaDepositoApl = cbFichasDepositoApl.Text;
                if (cbFichasDeposito.Checked)
                {
                    operaciones.FichaDepositoCs = rbtnFichasDepositoCS.Checked;
                    operaciones.FichaDepositoCc = rbtnFichasDepositoCC.Checked;
                    operaciones.FichaDepositoObs = txtFichasDepositoObs.Text;
                }

                operaciones.FichaRetiro = cbFichasRetiro.Checked;
                operaciones.FichaRetiroApl = cbFichasRetiroApl.Text;
                if (cbFichasRetiro.Checked)
                {
                    operaciones.FichaRetiroCs = rbtnFichasRetiroCS.Checked;
                    operaciones.FichaRetiroCc = rbtnFichasRetiroCC.Checked;
                    operaciones.FichaRetiroObs = txtFichasRetiroObs.Text;
                }

                operaciones.Comprobantes = cbComprobantes.Checked;
                operaciones.ComprobantesApl = cbComprobantesApl.Text;
                if (cbComprobantes.Checked)
                {
                    operaciones.ComprobantesCs = rbtnComprobantesCS.Checked;
                    operaciones.ComprobantesCc = rbtnComprobantesCC.Checked;
                    operaciones.ComprobantesObs = txtComprobantesObs.Text;
                }

                operaciones.Otros = cbOtro.Checked;
                operaciones.OtrosApl = cbOtroApl.Text;
                if (cbOtro.Checked)
                {
                    operaciones.OtrosCs = rbtnOtroCS.Checked;
                    operaciones.OtrosCc = rbtnOtroCC.Checked;
                    operaciones.OtrosObs = txtOtroObs.Text;
                    operaciones.OtrosEspecifica = txtEspecifica.Text;
                }

                operaciones.InfSolicitada = rbtnInfSolicitada.Checked;
                operaciones.InfSolicitadaExc = rbtnInfSolicitadaExc.Checked;
                operaciones.InfSolicitadaAnex = rbtnInfSolicitadaAnex.Checked;
                operaciones.InfSolicitadaForPar = rbtnInfSolicitadaForPar.Checked;
                if (rbtnInfSolicitadaExc.Checked | rbtnInfSolicitadaAnex.Checked || rbtnInfSolicitadaForPar.Checked)
                {                    
                    operaciones.InfSolicitadaAnexo = txtAnexo.Text;
                }
                cuenta.Operaciones = operaciones;
            }

            // MOVIMIENTOS ------------------------
            clsMovimientosElectronicos movimientos = null;
            if (cbMovimientosElec.Checked)
            {
                movimientos = new clsMovimientosElectronicos();
                movimientos.MovimientosElectronicos = cbMovElectronicos.Checked;
                movimientos.MovimientosElectronicosApl = cbMovElectronicosApl.Text;
                if (cbMovElectronicos.Checked) 
                    movimientos.MovimientosElectronicosObs = txtMovElectronicosObs.Text;

                movimientos.DispersionNomina = cbDispersionNomina.Checked;
                movimientos.DispersionNominaApl = cbDispersionNominaApl.Text;
                if (cbDispersionNomina.Checked)
                    movimientos.DispersionNominaObs = txtDispersionNominaObs.Text;

                movimientos.MovEInfSolicitada = rbtnMovEInfSolicitada.Checked;
                if (rbtnMovEInfSolicitadaExc.Checked)
                {
                    movimientos.MovEInfSolicitadaExc = rbtnMovEInfSolicitadaExc.Checked;
                    movimientos.MovEAnexo = txtMovEAnexo.Text;
                }
                cuenta.MovimientosElectronicos = movimientos;
            }


            if (index != -1) // Editando cuenta
            {
                // Validando se se cambio la persona inicial
                if (personIndex != cbxPersona.SelectedIndex)
                {
                    personaList[personIndex].CuentaList.RemoveAt(index);
                    personaList[cbxPersona.SelectedIndex].CuentaList.Add(cuenta);
                }
                else
                {
                    personaList[personIndex].CuentaList[index] = cuenta;
                }
            }
            else // Adicionando cuenta
            {
                personaList[cbxPersona.SelectedIndex].CuentaList.Add(cuenta);
            }

            return true;
        }
        // Metodo - Cargar cuenta
        public void CargarCuenta()
        {
            cbxTipo.SelectedIndex = 0;
            cbxEstatus.SelectedIndex = 0;
            cbxCaracter.SelectedIndex = 0;
            cbxMoneda.SelectedIndex = 0;

            // CARGANDO PERSONA
            cbxPersona.Items.Clear();
            for (int i = 0; i < personaList.Count; i++)
            {
                cbxPersona.Items.Add(personaList[i].Rfc + " - " + personaList[i].Nombre);
            }
            cbxPersona.SelectedIndex = personIndex;

            // CARGANDO CUENTA
            if (index != -1)
            {
                // DATOS DE LA CUENTA -------------------------------
                clsCuenta cuenta = personaList[personIndex].CuentaList[index];
                txtCuenta.Text = cuenta.NoCuenta;
                cbxTipo.SelectedItem = cuenta.Tipo;
                cbxEstatus.SelectedItem = cuenta.Estatus;
                cbxCaracter.SelectedItem = cuenta.Catacter;
                txtSaldo.Text = cuenta.Saldo;
                cbxMoneda.SelectedItem = cuenta.Moneda;
                taObservaciones.Text = cuenta.Observaciones;
                txtUbicacionOrSucursal.Text = cuenta.UbicacionSucursal;

                // DOCUMENTACION ------------------------------------
                if (cuenta.Documentacion != null)
                {
                    pnlDocumentacion.Enabled = true;
                    cbDocumentacion.Checked = true;
                    clsDocumentacion documentacion = cuenta.Documentacion;
                    cbxEstadoCuenta.Checked = documentacion.EstadoCuenta;
                    cbxEstadoCuentaApl.SelectedItem = documentacion.EstadoCuentaApl;
                    rbtnEstadoCuentaCS.Checked = documentacion.EstadoCuentaCs;
                    rbtnEstadosCuentaCC.Checked = documentacion.EstadoCuentaCc;
                    dtpEDCDesde.Value = documentacion.EstadoCuentaDesde;
                    dtpEDCHasta.Value = documentacion.EstadoCuentaHasta;
                    txtEstadosCuentaObs.Text = documentacion.EstadoCuentaObs;

                    cbIdentificacionOficial.Checked = documentacion.IdentificacionOficial;
                    cbIdentificacionOficialApl.SelectedItem = documentacion.IdentificacionOficialApl;
                    rbtnIdentificacionOficialCS.Checked = documentacion.IdentificacionOficialCs;
                    rbtnIdentificacionOficialCC.Checked = documentacion.IdentificacionOficialCc;
                    txtIdentificacionOficialObs.Text = documentacion.IdentificacionOficialObs;

                    cbContratoApertura.Checked = documentacion.ContratoApertura;
                    cbContratoAperturaApl.SelectedItem = documentacion.ContratoAperturaApl;
                    rbtnContratoAperturaCS.Checked = documentacion.ContratoAperturaCs;
                    rbtnContratoAperturaCC.Checked = documentacion.ContratoAperturaCc;
                    txtContratoAperturaObs.Text = documentacion.ContratoAperturaObs;

                    cbPoderNotarial.Checked = documentacion.PoderNotarial;
                    cbPoderNotarialApl.SelectedItem = documentacion.PoderNotarialApl;
                    rbtnPoderNotarialCS.Checked = documentacion.PoderNotarialCs;
                    rbtnPoderNotarialCC.Checked = documentacion.PoderNotarialCc;
                    txtPoderNotarialObs.Text = documentacion.PoderNotarialObs;

                    cbComprobanteDomicilio.Checked = documentacion.ComprobanteDomicilio;
                    cbComprobanteDomicilioApl.SelectedItem = documentacion.ComprobanteDomicilioApl;
                    rbtnComprobanteDomicilioCs.Checked = documentacion.ComprobanteDomicilioCs;
                    rbtnComprobanteDomicilioCc.Checked = documentacion.ComprobanteDomicilioCc;
                    txtComprobanteDomicilioObs.Text = documentacion.ComprobanteDomicilioObs;

                    cbTarjetaFirmas.Checked = documentacion.TarjetaFirmas;
                    cbTarjetaFirmasApl.SelectedItem = documentacion.TarjetaFirmasApl;
                    rbtnTarjetaFirmasCs.Checked = documentacion.TarjetaFirmasCs;
                    rbtnTarjetaFirmasCc.Checked = documentacion.TarjetaFirmasCc;
                    txtTarjetaFirmasObs.Text = documentacion.TarjetaFirmasObs;
                }

                // OPERACIONES --------------------------------------
                if (cuenta.Operaciones != null)
                {
                    pnlDocumentacionOper.Enabled = true;
                    cbDocumentacionOper.Checked = true;
                    clsOperaciones operaciones = cuenta.Operaciones;
                    cbCheques.Checked = operaciones.Cheques;
                    cbChequesApl.SelectedItem = operaciones.ChequesApl;
                    rbtnChequesCS.Checked = operaciones.ChequesCs;
                    rbtnChequesCC.Checked = operaciones.ChequesCc;
                    txtChequesObs.Text = operaciones.ChequesObs;

                    cbFichasDeposito.Checked = operaciones.FichaDeposito;
                    cbFichasDepositoApl.SelectedItem = operaciones.FichaDepositoApl;
                    rbtnFichasDepositoCS.Checked = operaciones.FichaDepositoCs;
                    rbtnFichasDepositoCC.Checked = operaciones.FichaDepositoCc;
                    txtFichasDepositoObs.Text = operaciones.FichaDepositoObs;

                    cbFichasRetiro.Checked = operaciones.FichaRetiro;
                    cbFichasRetiroApl.SelectedItem = operaciones.FichaRetiroApl;
                    rbtnFichasRetiroCS.Checked = operaciones.FichaRetiroCs;
                    rbtnFichasRetiroCC.Checked = operaciones.FichaRetiroCc;
                    txtFichasRetiroObs.Text = operaciones.FichaRetiroObs;

                    cbComprobantes.Checked = operaciones.Comprobantes;
                    cbComprobantesApl.SelectedItem = operaciones.ComprobantesApl;
                    rbtnComprobantesCS.Checked = operaciones.ComprobantesCs;
                    rbtnComprobantesCC.Checked = operaciones.ComprobantesCc;
                    txtComprobantesObs.Text = operaciones.ComprobantesObs;

                    cbOtro.Checked = operaciones.Otros;
                    cbOtroApl.SelectedItem = operaciones.OtrosApl;
                    rbtnOtroCS.Checked = operaciones.OtrosCs;
                    rbtnOtroCC.Checked = operaciones.OtrosCc;
                    txtOtroObs.Text = operaciones.OtrosObs;
                    txtEspecifica.Text = operaciones.OtrosEspecifica;

                    rbtnInfSolicitada.Checked = operaciones.InfSolicitada;
                    rbtnInfSolicitadaExc.Checked = operaciones.InfSolicitadaExc;
                    rbtnInfSolicitada.Checked = operaciones.InfSolicitada;
                    rbtnInfSolicitadaAnex.Checked = operaciones.InfSolicitadaAnex;
                    rbtnInfSolicitadaForPar.Checked = operaciones.InfSolicitadaForPar;
                    txtAnexo.Text = operaciones.InfSolicitadaAnexo;
                }

                // MOVIMIENTOS ------------------------
                if (cuenta.MovimientosElectronicos != null)
                {
                    pnlMovimientoElec.Enabled = true;
                    cbMovimientosElec.Checked = true;
                    clsMovimientosElectronicos movimientos = cuenta.MovimientosElectronicos;
                    cbMovElectronicos.Checked = movimientos.MovimientosElectronicos;
                    cbMovElectronicosApl.SelectedItem = movimientos.MovimientosElectronicosApl;
                    txtMovElectronicosObs.Text = movimientos.MovimientosElectronicosObs;

                    cbDispersionNomina.Checked = movimientos.DispersionNomina;
                    cbDispersionNominaApl.SelectedItem = movimientos.DispersionNominaApl;
                    txtDispersionNominaObs.Text = movimientos.DispersionNominaObs;

                    rbtnMovEInfSolicitada.Checked = movimientos.MovEInfSolicitada;
                    rbtnMovEInfSolicitadaExc.Checked = movimientos.MovEInfSolicitadaExc;
                    txtMovEAnexo.Text = movimientos.MovEAnexo;
                }
            }
            else
            {
                cbxEstadoCuentaApl.SelectedIndex = 1;
                cbIdentificacionOficialApl.SelectedIndex = 1;
                cbContratoAperturaApl.SelectedIndex = 1;
                cbPoderNotarialApl.SelectedIndex = 1;
                cbComprobanteDomicilioApl.SelectedIndex = 1;
                cbTarjetaFirmasApl.SelectedIndex = 1;

                cbChequesApl.SelectedIndex = 1;
                cbFichasDepositoApl.SelectedIndex = 1;
                cbFichasRetiroApl.SelectedIndex = 1;
                cbComprobantesApl.SelectedIndex = 1;
                cbOtroApl.SelectedIndex = 1;

                cbMovElectronicosApl.SelectedIndex = 1;
                cbDispersionNominaApl.SelectedIndex = 1;
            }
        }

        public bool Validacion()
        {
            if (txtCuenta.Text.Equals(""))
            {
                MessageBox.Show("El valor Cuenta es requerido.", "Notificación");
                return false;
            }

            // Documentacion
            if (cbxEstadoCuentaApl.SelectedIndex == 0 && !rbtnEstadoCuentaCS.Checked && !rbtnEstadosCuentaCC.Checked)
            {
                tabControl1.SelectedIndex = 0;
                MessageBox.Show("Debe seleccionar un tipo de Copia para Estado Cuenta.", "Notificación");
                return false;
            }
            if (cbIdentificacionOficialApl.SelectedIndex == 0 && !rbtnIdentificacionOficialCS.Checked && !rbtnIdentificacionOficialCC.Checked)
            {
                tabControl1.SelectedIndex = 0;
                MessageBox.Show("Debe seleccionar un tipo de Copia para Identificación Oficial.", "Notificación");
                return false;
            }
            if (cbContratoAperturaApl.SelectedIndex == 0 && !rbtnContratoAperturaCS.Checked && !rbtnContratoAperturaCC.Checked)
            {
                tabControl1.SelectedIndex = 0;
                MessageBox.Show("Debe seleccionar un tipo de Copia para Contrato Apertura.", "Notificación");
                return false;
            }
            if (cbPoderNotarialApl.SelectedIndex == 0 && !rbtnPoderNotarialCS.Checked && !rbtnPoderNotarialCC.Checked)
            {
                tabControl1.SelectedIndex = 0;
                MessageBox.Show("Debe seleccionar un tipo de Copia para Poder Notarial.", "Notificación");
                return false;
            }
            if (cbComprobanteDomicilioApl.SelectedIndex == 0 && !rbtnComprobanteDomicilioCs.Checked && !rbtnComprobanteDomicilioCc.Checked)
            {
                tabControl1.SelectedIndex = 0;
                MessageBox.Show("Debe seleccionar un tipo de Copia para Comprobante Domicilio.", "Notificación");
                return false;
            }
            if (cbTarjetaFirmasApl.SelectedIndex == 0 && !rbtnTarjetaFirmasCs.Checked && !rbtnTarjetaFirmasCc.Checked)
            {
                tabControl1.SelectedIndex = 0;
                MessageBox.Show("Debe seleccionar un tipo de Copia para Tarjeta Firmas.", "Notificación");
                return false;
            }

            // Documentacion Operaciones
            if (cbChequesApl.SelectedIndex == 0 && !rbtnChequesCS.Checked && !rbtnChequesCC.Checked)
            {
                tabControl1.SelectedIndex = 1;
                MessageBox.Show("Debe seleccionar un tipo de Copia para Cheques.", "Notificación");
                return false;
            }
            if (cbFichasDepositoApl.SelectedIndex == 0 && !rbtnFichasDepositoCS.Checked && !rbtnFichasDepositoCC.Checked)
            {
                tabControl1.SelectedIndex = 1;
                MessageBox.Show("Debe seleccionar un tipo de Copia para Fichas Deposito.", "Notificación");
                return false;
            }
            if (cbFichasRetiroApl.SelectedIndex == 0 && !rbtnFichasRetiroCS.Checked && !rbtnFichasRetiroCC.Checked)
            {
                tabControl1.SelectedIndex = 1;
                MessageBox.Show("Debe seleccionar un tipo de Copia para Fichas Retiro.", "Notificación");
                return false;
            }
            if (cbComprobantesApl.SelectedIndex == 0 && !rbtnComprobantesCS.Checked && !rbtnComprobantesCC.Checked)
            {
                tabControl1.SelectedIndex = 1;
                MessageBox.Show("Debe seleccionar un tipo de Copia para Comprobantes.", "Notificación");
                return false;
            }
            if (cbOtroApl.SelectedIndex == 0 && !rbtnOtroCS.Checked && !rbtnOtroCC.Checked)
            {
                tabControl1.SelectedIndex = 1;
                MessageBox.Show("Debe seleccionar un tipo de Copia para Otro.", "Notificación");
                return false;
            }

            return true;
        }

        // Evento - ACtivar-Desactivar Docunentacion / Estado de Cuenta
        private void cbxEstadoCuenta_CheckedChanged(object sender, EventArgs e)
        {
            pnlDocumentacion1.Enabled = cbxEstadoCuenta.Checked;
            dtpEDCDesde.Enabled = cbxEstadoCuenta.Checked;
            dtpEDCHasta.Enabled = cbxEstadoCuenta.Checked;
        }

        // Evento - ACtivar-Desactivar Docunentacion / Identificacion oficial
        private void cbIdentificacionOficial_CheckedChanged(object sender, EventArgs e)
        {
            pnlDocumentacion2.Enabled = cbIdentificacionOficial.Checked;
        }

        private void pnlDocumentacion_Paint(object sender, PaintEventArgs e)
        {

        }

        // Evento - ACtivar-Desactivar Docunentacion / Contrato de apertura
        private void cbContratoApertura_CheckedChanged(object sender, EventArgs e)
        {
            pnlDocumentacion3.Enabled = cbContratoApertura.Checked;
        }

        // Evento - ACtivar-Desactivar Docunentacion / Poder Notarial
        private void cbPoderNotarial_CheckedChanged(object sender, EventArgs e)
        {
            pnlDocumentacion4.Enabled = cbPoderNotarial.Checked;
        }




        // Evento - Activar-Desactivar Cheques
        private void cbCheques_CheckedChanged(object sender, EventArgs e)
        {
            pnlDocumentacionOper1.Enabled = cbCheques.Checked;
        }

        private void cbFichasDeposito_CheckedChanged(object sender, EventArgs e)
        {
            pnlDocumentacionOper2.Enabled = cbFichasDeposito.Checked;
        }

        private void cbFichasRetiro_CheckedChanged(object sender, EventArgs e)
        {
            pnlDocumentacionOper3.Enabled = cbFichasRetiro.Checked;
        }

        private void cbComprobantes_CheckedChanged(object sender, EventArgs e)
        {
            pnlDocumentacionOper4.Enabled = cbComprobantes.Checked;
        }

        private void cbOtro_CheckedChanged(object sender, EventArgs e)
        {
            pnlDocumentacionOper5.Enabled = cbOtro.Checked;
            txtEspecifica.Enabled = cbOtro.Checked;
        }

        private void rbtnInfSolicitadaExc_CheckedChanged(object sender, EventArgs e)
        {
            txtAnexo.Enabled = rbtnInfSolicitadaExc.Checked;
        }





        private void cbMovElectronicos_CheckedChanged(object sender, EventArgs e)
        {
            txtMovElectronicosObs.Enabled = cbMovElectronicos.Checked;
        }

        private void cbDispersionNomina_CheckedChanged(object sender, EventArgs e)
        {
            txtDispersionNominaObs.Enabled = cbDispersionNomina.Checked;
        }

        private void rbtnMovEInfSolicitadaExc_CheckedChanged(object sender, EventArgs e)
        {
            txtMovEAnexo.Enabled = rbtnMovEInfSolicitadaExc.Checked;
        }

        private void cbComprobanteDomicilio_CheckedChanged(object sender, EventArgs e)
        {
            pnlDocumentacion5.Enabled = cbComprobanteDomicilio.Checked;
        }

        private void cbTarjetaFirmas_CheckedChanged(object sender, EventArgs e)
        {
            pnlDocumentacion6.Enabled = cbTarjetaFirmas.Checked;
        }


        // Evento - Estado Cuenta - Aplica
        private void cbxEstadoCuentaApl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbxEstadoCuentaApl.SelectedIndex != 0)
            {
                rbtnEstadoCuentaCS.Enabled = false;
                rbtnEstadosCuentaCC.Enabled = false;
                rbtnEstadoCuentaCS.Checked = false;
                rbtnEstadosCuentaCC.Checked = false;
            }
            else
            {
                rbtnEstadoCuentaCS.Enabled = true;
                rbtnEstadosCuentaCC.Enabled = true;
            }
        }

        // Evento - Identificación Oficial - Aplica
        private void cbIdentificacionOficialApl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbIdentificacionOficialApl.SelectedIndex != 0)
            {
                rbtnIdentificacionOficialCS.Enabled = false;
                rbtnIdentificacionOficialCC.Enabled = false;
                rbtnIdentificacionOficialCS.Checked = false;
                rbtnIdentificacionOficialCC.Checked = false;
            }
            else
            {
                rbtnIdentificacionOficialCS.Enabled = true;
                rbtnIdentificacionOficialCC.Enabled = true;
            }
        }

        // Evento - Contrato Apertura - Aplica
        private void cbContratoAperturaApl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbContratoAperturaApl.SelectedIndex != 0)
            {
                rbtnContratoAperturaCS.Enabled = false;
                rbtnContratoAperturaCC.Enabled = false;
                rbtnContratoAperturaCS.Checked = false;
                rbtnContratoAperturaCC.Checked = false;
            }
            else
            {
                rbtnContratoAperturaCS.Enabled = true;
                rbtnContratoAperturaCC.Enabled = true;
            }
        }

        // Evento - Poder Notarial - Aplica
        private void cbPoderNotarialApl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbPoderNotarialApl.SelectedIndex != 0)
            {
                rbtnPoderNotarialCS.Enabled = false;
                rbtnPoderNotarialCC.Enabled = false;
                rbtnPoderNotarialCS.Checked = false;
                rbtnPoderNotarialCC.Checked = false;
            }
            else
            {
                rbtnPoderNotarialCS.Enabled = true;
                rbtnPoderNotarialCC.Enabled = true;
            }
        }

        // Evento - Comprobante Domicilio - Aplica
        private void cbComprobanteDomicilioApl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbComprobanteDomicilioApl.SelectedIndex != 0)
            {
                rbtnComprobanteDomicilioCs.Enabled = false;
                rbtnComprobanteDomicilioCc.Enabled = false;
                rbtnComprobanteDomicilioCs.Checked = false;
                rbtnComprobanteDomicilioCc.Checked = false;
            }
            else
            {
                rbtnComprobanteDomicilioCs.Enabled = true;
                rbtnComprobanteDomicilioCc.Enabled = true;
            }
        }
        
        // Evento - Tarjeta Firmas - Aplica
        private void cbTarjetaFirmasApl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbTarjetaFirmasApl.SelectedIndex != 0)
            {
                rbtnTarjetaFirmasCs.Enabled = false;
                rbtnTarjetaFirmasCc.Enabled = false;
                rbtnTarjetaFirmasCs.Checked = false;
                rbtnTarjetaFirmasCc.Checked = false;
            }
            else
            {
                rbtnTarjetaFirmasCs.Enabled = true;
                rbtnTarjetaFirmasCc.Enabled = true;
            }
        }

        // Evento - Cheques - Aplica
        private void cbChequesApl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbChequesApl.SelectedIndex != 0)
            {
                rbtnChequesCS.Enabled = false;
                rbtnChequesCC.Enabled = false;
                rbtnChequesCS.Checked = false;
                rbtnChequesCC.Checked = false;
            }
            else
            {
                rbtnChequesCS.Enabled = true;
                rbtnChequesCC.Enabled = true;
            }
        }

        // Evento - Fichas Deposito - Aplica
        private void cbFichasDepositoApl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbFichasDepositoApl.SelectedIndex != 0)
            {
                rbtnFichasDepositoCS.Enabled = false;
                rbtnFichasDepositoCC.Enabled = false;
                rbtnFichasDepositoCS.Checked = false;
                rbtnFichasDepositoCC.Checked = false;
            }
            else
            {
                rbtnFichasDepositoCS.Enabled = true;
                rbtnFichasDepositoCC.Enabled = true;
            }
        }

        // Evento - Fichas Retiro - Aplica
        private void cbFichasRetiroApl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbFichasRetiroApl.SelectedIndex != 0)
            {
                rbtnFichasRetiroCS.Enabled = false;
                rbtnFichasRetiroCC.Enabled = false;
                rbtnFichasRetiroCS.Checked = false;
                rbtnFichasRetiroCC.Checked = false;
            }
            else
            {
                rbtnFichasRetiroCS.Enabled = true;
                rbtnFichasRetiroCC.Enabled = true;
            }
        }

        // Evento - Comprobantes - Aplica
        private void cbComprobantesApl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbComprobantesApl.SelectedIndex != 0)
            {
                rbtnComprobantesCS.Enabled = false;
                rbtnComprobantesCC.Enabled = false;
                rbtnComprobantesCS.Checked = false;
                rbtnComprobantesCC.Checked = false;
            }
            else
            {
                rbtnComprobantesCS.Enabled = true;
                rbtnComprobantesCC.Enabled = true;
            }
        }

        // Evento - Otro - Aplica
        private void cbOtroApl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbOtroApl.SelectedIndex != 0)
            {
                rbtnOtroCS.Enabled = false;
                rbtnOtroCC.Enabled = false;
                rbtnOtroCS.Checked = false;
                rbtnOtroCC.Checked = false;
            }
            else
            {
                rbtnOtroCS.Enabled = true;
                rbtnOtroCC.Enabled = true;
            }
        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void frmCuenta_Load(object sender, EventArgs e)
        {

        }

        private void rbtnInfSolicitada_CheckedChanged(object sender, EventArgs e)
        {
            txtAnexo.Enabled = !rbtnInfSolicitada.Checked;
        }

        private void rbtnInfSolicitadaForPar_CheckedChanged(object sender, EventArgs e)
        {
            txtAnexo.Enabled = rbtnInfSolicitadaForPar.Checked;
        }

        private void rbtnInfSolicitadaAnex_CheckedChanged(object sender, EventArgs e)
        {
            txtAnexo.Enabled = rbtnInfSolicitadaAnex.Checked;
        }


       
    }
}
