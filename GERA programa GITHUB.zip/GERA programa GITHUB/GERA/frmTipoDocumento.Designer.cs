﻿namespace document_management
{
    partial class frmTipoDocumento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTipoDocumento));
            this.btnRespuestaAmparo = new System.Windows.Forms.Button();
            this.btnRespuestaNegativa = new System.Windows.Forms.Button();
            this.btnRespuestaPositiva = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnRespuestaAmparo
            // 
            this.btnRespuestaAmparo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRespuestaAmparo.Image = global::document_management.Properties.Resources.News_Amparo;
            this.btnRespuestaAmparo.Location = new System.Drawing.Point(445, 15);
            this.btnRespuestaAmparo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRespuestaAmparo.Name = "btnRespuestaAmparo";
            this.btnRespuestaAmparo.Size = new System.Drawing.Size(193, 156);
            this.btnRespuestaAmparo.TabIndex = 2;
            this.btnRespuestaAmparo.Text = "\r\n\r\n\r\n\r\n\r\n\r\nRespuesta Amparo";
            this.btnRespuestaAmparo.UseVisualStyleBackColor = true;
            this.btnRespuestaAmparo.Click += new System.EventHandler(this.btnAmparo_Click);
            // 
            // btnRespuestaNegativa
            // 
            this.btnRespuestaNegativa.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRespuestaNegativa.Image = global::document_management.Properties.Resources.News_Delete;
            this.btnRespuestaNegativa.Location = new System.Drawing.Point(229, 15);
            this.btnRespuestaNegativa.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRespuestaNegativa.Name = "btnRespuestaNegativa";
            this.btnRespuestaNegativa.Size = new System.Drawing.Size(193, 156);
            this.btnRespuestaNegativa.TabIndex = 1;
            this.btnRespuestaNegativa.Text = "\r\n\r\n\r\n\r\n\r\n\r\nRespuesta Negativa";
            this.btnRespuestaNegativa.UseVisualStyleBackColor = true;
            this.btnRespuestaNegativa.Click += new System.EventHandler(this.btnRespuestaNegativa_Click);
            // 
            // btnRespuestaPositiva
            // 
            this.btnRespuestaPositiva.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRespuestaPositiva.Image = global::document_management.Properties.Resources.News_Add;
            this.btnRespuestaPositiva.Location = new System.Drawing.Point(16, 15);
            this.btnRespuestaPositiva.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRespuestaPositiva.Name = "btnRespuestaPositiva";
            this.btnRespuestaPositiva.Size = new System.Drawing.Size(191, 156);
            this.btnRespuestaPositiva.TabIndex = 0;
            this.btnRespuestaPositiva.Text = "\r\n\r\n\r\n\r\n\r\n\r\nRespuesta Positiva";
            this.btnRespuestaPositiva.UseVisualStyleBackColor = true;
            this.btnRespuestaPositiva.Click += new System.EventHandler(this.btnRespuestaPositiva_Click);
            // 
            // frmTipoDocumento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(656, 186);
            this.Controls.Add(this.btnRespuestaAmparo);
            this.Controls.Add(this.btnRespuestaNegativa);
            this.Controls.Add(this.btnRespuestaPositiva);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmTipoDocumento";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GERA - TIPO DE RESPUESTA 3.0";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnRespuestaPositiva;
        private System.Windows.Forms.Button btnRespuestaNegativa;
        private System.Windows.Forms.Button btnRespuestaAmparo;
    }
}